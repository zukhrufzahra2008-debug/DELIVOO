import { eq, and, ne } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  users,
  verificationApplications,
  verificationDocuments,
  shopProfiles,
  notifications,
  auditLogs,
  platformSettings,
} from '../../db/schema.ts';
import { calculateAgeFromDob, isValidCnicFormat, maskCnic } from '../security.ts';
import { emitToRole, emitToUser } from '../ws.ts';

const DISPOSABLE_DOMAINS = new Set([
  'mailinator.com',
  'tempmail.com',
  '10minutemail.com',
  'guerrillamail.com',
  'yopmail.com',
]);

async function verifyCnicWithAuthorizedProvider(cnic: string, fullName: string): Promise<{
  configured: boolean;
  verified: boolean;
  providerStatus: string;
  detail: string;
}> {
  const apiUrl = process.env.IDENTITY_VERIFIER_API_URL;
  const apiKey = process.env.IDENTITY_VERIFIER_API_KEY;

  if (!apiUrl || !apiKey) {
    return {
      configured: false,
      verified: false,
      providerStatus: 'provider_not_configured',
      detail: 'Authorized identity verification provider is not configured; queued for Admin verification.',
    };
  }

  try {
    const resp = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ cnic, fullName }),
      signal: AbortSignal.timeout(8000),
    });
    if (!resp.ok) {
      return {
        configured: true,
        verified: false,
        providerStatus: 'provider_error',
        detail: `Identity provider returned HTTP ${resp.status}`,
      };
    }
    const json = (await resp.json()) as { verified?: boolean; reason?: string };
    return {
      configured: true,
      verified: Boolean(json.verified),
      providerStatus: json.verified ? 'verified' : 'failed',
      detail: json.reason || (json.verified ? 'CNIC matched authorized registry' : 'Identity mismatch'),
    };
  } catch (err) {
    return {
      configured: true,
      verified: false,
      providerStatus: 'provider_timeout',
      detail: err instanceof Error ? err.message : 'Identity provider timeout',
    };
  }
}

class VerificationJobQueue {
  private queue: number[] = [];
  private processing = false;

  enqueue(applicationId: number) {
    if (!this.queue.includes(applicationId)) {
      this.queue.push(applicationId);
    }
    if (!this.processing) {
      void this.drain();
    }
  }

  private async drain() {
    this.processing = true;
    while (this.queue.length > 0) {
      const appId = this.queue.shift();
      if (appId !== undefined) {
        try {
          await runVerificationPipeline(appId);
        } catch (error) {
          console.error('Verification pipeline error for app', appId, error);
        }
      }
    }
    this.processing = false;
  }
}

export const verificationQueue = new VerificationJobQueue();

export async function runVerificationPipeline(applicationId: number) {
  const [app] = await db
    .select()
    .from(verificationApplications)
    .where(eq(verificationApplications.id, applicationId));

  if (!app) return;

  const [user] = await db.select().from(users).where(eq(users.id, app.userId));
  if (!user) return;

  const docs = await db
    .select()
    .from(verificationDocuments)
    .where(eq(verificationDocuments.applicationId, applicationId));

  const riskFlags: string[] = [];
  let riskScore = 0;

  // 1. Age eligibility check
  if (user.dob) {
    const age = calculateAgeFromDob(user.dob);
    if (age === null || age < 18) {
      riskFlags.push('Applicant does not meet minimum age requirement (18+)');
      riskScore += 50;
    }
  } else if (user.role === 'customer' || user.role === 'rider') {
    riskFlags.push('Missing date of birth');
    riskScore += 30;
  }

  // 2. CNIC format check
  if (!user.cnicNumber || !isValidCnicFormat(user.cnicNumber)) {
    riskFlags.push('Invalid CNIC format (expected XXXXX-XXXXXXX-X)');
    riskScore += 40;
  }

  // 3. Duplicate CNIC / phone checks across other accounts
  if (user.cnicNumber) {
    const dupCnic = await db
      .select({ id: users.id })
      .from(users)
      .where(and(eq(users.cnicNumber, user.cnicNumber), ne(users.id, user.id)));
    if (dupCnic.length > 0) {
      riskFlags.push('Duplicate CNIC detected on another account');
      riskScore += 80;
    }
  }

  const dupPhone = await db
    .select({ id: users.id })
    .from(users)
    .where(and(eq(users.phone, user.phone), ne(users.id, user.id)));
  if (dupPhone.length > 0) {
    riskFlags.push('Duplicate phone number detected on another account');
    riskScore += 60;
  }

  // 4. Disposable email domain check
  const emailDomain = user.email.split('@')[1]?.toLowerCase() || '';
  if (DISPOSABLE_DOMAINS.has(emailDomain)) {
    riskFlags.push('Disposable email domain detected');
    riskScore += 40;
  }

  // 5. Role-specific document checks & expiry check
  if (user.role === 'rider') {
    const requiredDocs = ['profile_photo', 'cnic_front', 'cnic_back'];
    for (const reqDoc of requiredDocs) {
      if (!docs.some((d) => d.docType === reqDoc)) {
        riskFlags.push(`Missing required rider document: ${reqDoc}`);
        riskScore += 25;
      }
    }
    const licenseDoc = docs.find((d) => d.docType === 'driving_license');
    if (licenseDoc?.expiryDate) {
      const exp = new Date(licenseDoc.expiryDate);
      if (Number.isNaN(exp.getTime()) || exp < new Date()) {
        riskFlags.push('Driving license is expired or has invalid expiry date');
        riskScore += 45;
      }
    }
  } else if (user.role === 'shopkeeper') {
    const requiredDocs = ['cnic_front', 'shop_photo', 'logo'];
    for (const reqDoc of requiredDocs) {
      if (!docs.some((d) => d.docType === reqDoc)) {
        riskFlags.push(`Missing shop onboarding asset: ${reqDoc}`);
        riskScore += 20;
      }
    }
  }

  // 6. OTP verification check
  if (!user.emailVerified || !user.phoneVerified) {
    riskFlags.push('Email or Phone OTP verification still pending');
  }

  // 7. Identity provider authenticity check
  const idCheck = user.cnicNumber
    ? await verifyCnicWithAuthorizedProvider(user.cnicNumber, user.fullName)
    : {
        configured: false,
        verified: false,
        providerStatus: 'missing_cnic',
        detail: 'No CNIC provided',
      };

  if (idCheck.configured && !idCheck.verified) {
    riskFlags.push(`Identity provider verification failed: ${idCheck.detail}`);
    riskScore += 70;
  }

  // Load policy setting
  const [policyRow] = await db
    .select()
    .from(platformSettings)
    .where(eq(platformSettings.key, 'verification_policy'));
  const policy = (policyRow?.value || {}) as {
    autoApproveVerifiedCustomers?: boolean;
    requireIdentityProviderForRiders?: boolean;
  };

  const otpComplete = user.emailVerified && user.phoneVerified;
  const formatAndDupPassed = riskScore === 0;

  let nextStatus = 'pending_verification';
  let reviewNotes = '';

  if (!otpComplete) {
    nextStatus = 'pending_verification';
    reviewNotes = 'Waiting for Email and Phone OTP verification.';
  } else if (!formatAndDupPassed) {
    nextStatus = 'under_review';
    reviewNotes = `Flagged for Admin Review: ${riskFlags.join('; ')}`;
  } else if (user.role === 'customer') {
    if (idCheck.verified || (policy.autoApproveVerifiedCustomers !== false && !idCheck.configured)) {
      nextStatus = 'approved';
      reviewNotes = idCheck.verified
        ? 'All automated checks & authorized CNIC verification passed.'
        : 'Email/Phone OTPs, age eligibility, CNIC format & duplicate checks passed. Auto-approved under customer onboarding policy (external CNIC registry provider not configured).';
    } else {
      nextStatus = 'under_review';
      reviewNotes = idCheck.detail;
    }
  } else {
    // Riders & Shopkeepers require either confirmed external ID provider + docs or Admin review
    if (idCheck.configured && idCheck.verified && docs.length >= 2) {
      nextStatus = 'approved';
      reviewNotes = 'Automated identity, document, and OTP checks passed.';
    } else {
      nextStatus = 'under_review';
      reviewNotes = idCheck.configured
        ? idCheck.detail
        : 'OTP & duplicate checks passed. Routed to Admin Review to inspect documents and confirm identity (authorized CNIC API not configured).';
    }
  }

  await db
    .update(verificationApplications)
    .set({
      status: nextStatus,
      autoChecksPassed: formatAndDupPassed && otpComplete,
      identityProviderStatus: idCheck.providerStatus,
      riskScore,
      riskFlags,
      reviewNotes,
      updatedAt: new Date(),
    })
    .where(eq(verificationApplications.id, applicationId));

  await db
    .update(users)
    .set({
      accountStatus: nextStatus,
      cnicMasked: maskCnic(user.cnicNumber),
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));

  if (user.role === 'shopkeeper') {
    await db
      .update(shopProfiles)
      .set({ approvalStatus: nextStatus })
      .where(eq(shopProfiles.ownerId, user.id));
  }

  await db.insert(auditLogs).values({
    actorId: null,
    actorRole: 'system',
    action: 'verification_pipeline_evaluated',
    targetType: 'verification_application',
    targetId: String(applicationId),
    details: {
      userId: user.id,
      role: user.role,
      nextStatus,
      riskScore,
      riskFlags,
      identityProviderStatus: idCheck.providerStatus,
    },
  });

  if (nextStatus === 'approved') {
    const [notif] = await db
      .insert(notifications)
      .values({
        userId: user.id,
        title: 'Account Approved',
        message: 'Your DELIVOO account verification is complete and approved.',
        type: 'verification',
        referenceId: String(applicationId),
      })
      .returning();
    emitToUser(user.id, 'notification:new', notif);
    emitToUser(user.id, 'account:status', { accountStatus: 'approved' });
  } else if (nextStatus === 'under_review') {
    emitToRole('admin', 'admin:verification_needed', {
      applicationId,
      userId: user.id,
      fullName: user.fullName,
      role: user.role,
      riskScore,
      reviewNotes,
    });
  }
}
