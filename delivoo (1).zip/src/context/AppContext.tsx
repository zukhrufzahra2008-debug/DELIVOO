import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';

export interface UserProfile {
  id: number;
  uid: string;
  email: string;
  fullName: string;
  phone: string;
  dob?: string | null;
  cnicMasked?: string | null;
  role: 'customer' | 'shopkeeper' | 'rider' | 'admin';
  adminTier?: 'main' | 'sub' | null;
  accountStatus: string;
  emailVerified: boolean;
  phoneVerified: boolean;
  rejectionReason?: string | null;
  privacySettings?: {
    shareLiveLocation: boolean;
    marketingEmails: boolean;
    smsAlerts: boolean;
    dataAnalyticsConsent: boolean;
  };
}

export interface NotificationItem {
  id: number;
  title: string;
  message: string;
  type: string;
  referenceId?: string | null;
  isRead: boolean;
  createdAt: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

interface AppContextValue {
  token: string | null;
  user: UserProfile | null;
  authLoading: boolean;
  roleProfile: Record<string, unknown> | null;
  verificationApplication: Record<string, unknown> | null;
  notifications: NotificationItem[];
  unreadCount: number;
  wsConnected: boolean;
  lastWsEvent: { type: string; data: unknown; ts: number } | null;
  toasts: ToastMessage[];
  setSession: (token: string, user: UserProfile) => Promise<void>;
  refreshSession: () => Promise<void>;
  logout: () => void;
  apiFetch: <T = unknown>(path: string, options?: RequestInit) => Promise<T>;
  pushToast: (type: ToastMessage['type'], text: string) => void;
  dismissToast: (id: string) => void;
  markNotificationsRead: () => Promise<void>;
}

const STORAGE_TOKEN_KEY = 'delivoo_auth_token';

function readStoredToken(): string | null {
  try {
    return window.localStorage.getItem(STORAGE_TOKEN_KEY);
  } catch {
    return null;
  }
}

function writeStoredToken(token: string | null): void {
  try {
    if (token) {
      window.localStorage.setItem(STORAGE_TOKEN_KEY, token);
    } else {
      window.localStorage.removeItem(STORAGE_TOKEN_KEY);
    }
  } catch {
    // Ignore storage errors in restricted contexts
  }
}

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initialToken = typeof window !== 'undefined' ? readStoredToken() : null;
  const [token, setToken] = useState<string | null>(initialToken);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [roleProfile, setRoleProfile] = useState<Record<string, unknown> | null>(null);
  const [verificationApplication, setVerificationApplication] = useState<Record<string, unknown> | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [wsConnected, setWsConnected] = useState(false);
  const [lastWsEvent, setLastWsEvent] = useState<{ type: string; data: unknown; ts: number } | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const tokenRef = useRef<string | null>(initialToken);
  tokenRef.current = token;

  const pushToast = useCallback((type: ToastMessage['type'], text: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const apiFetch = useCallback(async <T = unknown>(path: string, options: RequestInit = {}): Promise<T> => {
    const headers = new Headers(options.headers);
    if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
      headers.set('Content-Type', 'application/json');
    }
    if (tokenRef.current && !headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${tokenRef.current}`);
    }
    const res = await fetch(path, {
      ...options,
      credentials: 'include',
      headers,
    });
    const text = await res.text();
    let parsed: Record<string, unknown> = {};
    try {
      parsed = text ? JSON.parse(text) : {};
    } catch {
      parsed = { error: text || `HTTP ${res.status}` };
    }
    if (!res.ok) {
      const errMsg = typeof parsed.error === 'string' ? parsed.error : `Request failed (${res.status})`;
      const err = new Error(errMsg) as Error & { code?: string; status?: number };
      err.code = typeof parsed.code === 'string' ? parsed.code : undefined;
      err.status = res.status;
      throw err;
    }
    return parsed as T;
  }, []);

  const refreshSession = useCallback(async () => {
    try {
      const me = await apiFetch<{
        wsToken?: string;
        user: UserProfile;
        roleProfile: Record<string, unknown> | null;
        verificationApplication: Record<string, unknown> | null;
      }>('/api/auth/me');

      if (me.wsToken && me.wsToken !== tokenRef.current) {
        tokenRef.current = me.wsToken;
        setToken(me.wsToken);
        writeStoredToken(me.wsToken);
      }

      setUser(me.user);
      setRoleProfile(me.roleProfile);
      setVerificationApplication(me.verificationApplication);

      const notifResp = await apiFetch<{ notifications: NotificationItem[] }>('/api/notifications');
      setNotifications(notifResp.notifications || []);
    } catch (err) {
      const status = (err as { status?: number })?.status;
      if (status === 401 || status === 403) {
        tokenRef.current = null;
        setToken(null);
        setUser(null);
        setRoleProfile(null);
        setVerificationApplication(null);
        writeStoredToken(null);
      } else {
        console.error('Refresh session error:', err);
      }
    }
  }, [apiFetch]);

  // Restore active session on first load / browser reload (from HttpOnly cookie or stored session token)
  useEffect(() => {
    let active = true;
    const bootstrapSession = async () => {
      try {
        const me = await apiFetch<{
          wsToken?: string;
          user: UserProfile;
          roleProfile: Record<string, unknown> | null;
          verificationApplication: Record<string, unknown> | null;
        }>('/api/auth/me');
        if (!active) return;

        const restoredToken = me.wsToken || tokenRef.current;
        if (restoredToken) {
          tokenRef.current = restoredToken;
          setToken(restoredToken);
          writeStoredToken(restoredToken);
        }
        setUser(me.user);
        setRoleProfile(me.roleProfile);
        setVerificationApplication(me.verificationApplication);

        apiFetch<{ notifications: NotificationItem[] }>('/api/notifications')
          .then((notifResp) => {
            if (active) setNotifications(notifResp.notifications || []);
          })
          .catch(() => {});
      } catch {
        if (!active) return;
        tokenRef.current = null;
        setToken(null);
        setUser(null);
        writeStoredToken(null);
      } finally {
        if (active) setAuthLoading(false);
      }
    };

    void bootstrapSession();
    return () => {
      active = false;
    };
  }, [apiFetch]);

  const setSession = useCallback(
    async (newToken: string, nextUser: UserProfile) => {
      tokenRef.current = newToken;
      setToken(newToken);
      writeStoredToken(newToken);
      setUser(nextUser);
      setAuthLoading(false);
      await refreshSession();
    },
    [refreshSession]
  );

  const logout = useCallback(() => {
    tokenRef.current = null;
    setToken(null);
    writeStoredToken(null);
    setUser(null);
    setRoleProfile(null);
    setVerificationApplication(null);
    setNotifications([]);
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setWsConnected(false);
    void fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
    pushToast('info', 'Signed out safely.');
  }, [pushToast]);

  const markNotificationsRead = useCallback(async () => {
    if (!tokenRef.current && !user) return;
    try {
      await apiFetch('/api/notifications/read-all', { method: 'PATCH' });
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch {
      // Ignore
    }
  }, [apiFetch, user]);

  // Real-time WebSocket connection for authenticated users
  useEffect(() => {
    if (!user) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      setWsConnected(false);
      return;
    }

    let closedByEffect = false;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        if (tokenRef.current) {
          ws.send(JSON.stringify({ type: 'auth', token: tokenRef.current }));
        }
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'auth:ok') {
            setWsConnected(true);
            return;
          }
          if (msg.type === 'notification:new' && msg.data) {
            const incoming = msg.data as NotificationItem;
            setNotifications((prev) => {
              if (prev.some((n) => n.id === incoming.id)) return prev;
              return [incoming, ...prev];
            });
            pushToast('info', `${incoming.title}: ${incoming.message}`);
          }
          if (msg.type === 'account:status') {
            void refreshSession();
          }
          setLastWsEvent(msg);
        } catch {
          // Ignore invalid socket frame
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!closedByEffect && user) {
          reconnectTimer = setTimeout(connect, 3500);
        }
      };
    };

    connect();
    return () => {
      closedByEffect = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [user, pushToast, refreshSession]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <AppContext.Provider
      value={{
        token,
        user,
        authLoading,
        roleProfile,
        verificationApplication,
        notifications,
        unreadCount,
        wsConnected,
        lastWsEvent,
        toasts,
        setSession,
        refreshSession,
        logout,
        apiFetch,
        pushToast,
        dismissToast,
        markNotificationsRead,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
