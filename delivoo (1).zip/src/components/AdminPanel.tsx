import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  BarChart3,
  Users,
  ShieldCheck,
  Store,
  Bike,
  ClipboardList,
  Wallet,
  Settings,
  LifeBuoy,
  Shield,
  LogOut,
  Eye,
  CheckCircle2,
  XCircle,
  UserCog,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DelivooLogo } from './DelivooLogo';
import { DeliveryMap } from './DeliveryMap';
import { PrivacySafetyPanel } from './PrivacySafetyPanel';

interface AnalyticsPayload {
  kpis: {
    totalCustomers: number;
    totalShopkeepers: number;
    totalRiders: number;
    activeShops: number;
    pendingRegistrations: number;
    totalOrders: number;
    completedOrders: number;
    cancelledOrders: number;
    grossOrderValue: number;
    platformRevenue: number;
    totalCommission: number;
  };
  dailySeries: Array<{ label: string; orders: number; gmv: number; revenue: number }>;
}

interface VerificationApp {
  id: number;
  userId: number;
  targetRole: string;
  status: string;
  autoChecksPassed: boolean;
  identityProviderStatus: string;
  riskScore: number;
  riskFlags: string[];
  reviewNotes: string | null;
  user: {
    id: number;
    fullName: string;
    email: string;
    phone: string;
    cnicMasked: string | null;
    accountStatus: string;
  } | null;
  documents: Array<{ id: number; docType: string; fileName: string; storageDataUrl: string; expiryDate: string | null }>;
}

export const AdminPanel: React.FC = () => {
  const { user, lastWsEvent, apiFetch, logout, pushToast } = useApp();
  const isMainAdmin = user?.adminTier !== 'sub';
  const [tab, setTab] = useState<'analytics' | 'verifications' | 'users' | 'sub_admins' | 'shops' | 'riders' | 'orders' | 'finance' | 'settings' | 'support' | 'privacy'>('analytics');

  const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);
  const [verifications, setVerifications] = useState<VerificationApp[]>([]);
  const [unmaskedCnic, setUnmaskedCnic] = useState<Record<number, string>>({});
  const [usersList, setUsersList] = useState<Array<{ id: number; fullName: string; email: string; phone: string; role: string; adminTier?: string | null; accountStatus: string; cnicMasked: string | null }>>([]);
  const [subAdminData, setSubAdminData] = useState<{
    mainAdmin: { id: number; fullName: string; email: string; phone: string; accountStatus: string; adminTier: string | null } | null;
    subAdmins: Array<{ id: number; fullName: string; email: string; phone: string; accountStatus: string; adminTier: string | null; createdAt: string }>;
    maxSubAdmins: number;
    remainingSlots: number;
  } | null>(null);
  const [subAdminForm, setSubAdminForm] = useState({ fullName: '', email: '', phone: '+923001119900', password: '' });
  const [subAdminBusy, setSubAdminBusy] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [shopsList, setShopsList] = useState<Array<{ id: number; name: string; categoryName: string; approvalStatus: string; commissionRate: string; lat: number; lng: number; rating: number }>>([]);
  const [ridersList, setRidersList] = useState<Array<{ userId: number; fullName: string; phone: string; accountStatus: string; vehicleType: string; isOnline: boolean; currentLat: number; currentLng: number; activeOrdersCount: number; totalDeliveries: number }>>([]);
  const [ordersList, setOrdersList] = useState<Array<{ id: number; orderNumber: string; shopName: string; customerName: string; riderName: string | null; riderId: number | null; status: string; totalAmount: string; paymentStatus: string }>>([]);
  const [finance, setFinance] = useState<{
    payments: Array<{ id: number; orderId: number; provider: string; transactionRef: string; amount: string; status: string }>;
    refunds: Array<{ id: number; orderId: number; amount: string; reason: string; status: string }>;
    settlements: Array<{ id: number; shopId: number; periodLabel: string; netAmount: string; status: string; referenceNo: string | null }>;
  } | null>(null);
  const [settingsData, setSettingsData] = useState<{
    categories: Array<{ id: number; name: string; isActive: boolean }>;
    coupons: Array<{ id: number; code: string; title: string; discountType: string; discountValue: string }>;
    zones: Array<{ id: number; name: string; city: string; baseDeliveryFee: string }>;
    settings: Array<{ key: string; value: Record<string, unknown> }>;
  } | null>(null);
  const [auditData, setAuditData] = useState<{
    auditLogs: Array<{ id: number; actorRole: string; action: string; targetType: string; targetId: string | null; createdAt: string }>;
    supportTickets: Array<{ id: number; userRole: string; subject: string; description: string; status: string; resolutionNotes: string | null }>;
  } | null>(null);

  // Inputs
  const [newCatName, setNewCatName] = useState('');
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponTitle, setNewCouponTitle] = useState('');
  const [newCouponVal, setNewCouponVal] = useState('15');
  const [commRateInput, setCommRateInput] = useState('15');
  const [baseFeeInput, setBaseFeeInput] = useState('120');
  const [platformFeeInput, setPlatformFeeInput] = useState('25');
  const [settleShopId, setSettleShopId] = useState('');
  const [settleAmount, setSettleAmount] = useState('');
  const [assignRiderByOrder, setAssignRiderByOrder] = useState<Record<number, number>>({});
  const [rejectModalAppId, setRejectModalAppId] = useState<number | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState('');
  const [resolveTicketId, setResolveTicketId] = useState<number | null>(null);
  const [resolveNoteInput, setResolveNoteInput] = useState('');

  const loadAll = useCallback(async () => {
    try {
      const [a, v, u, s, r, o, f, cfg, aud, sa] = await Promise.all([
        apiFetch<AnalyticsPayload>('/api/admin/analytics'),
        apiFetch<{ applications: VerificationApp[] }>('/api/admin/verifications'),
        apiFetch<{ users: typeof usersList }>('/api/admin/users'),
        apiFetch<{ shops: typeof shopsList }>('/api/admin/shops'),
        apiFetch<{ riders: typeof ridersList }>('/api/admin/riders'),
        apiFetch<{ orders: typeof ordersList }>('/api/admin/orders'),
        apiFetch<NonNullable<typeof finance>>('/api/admin/finance'),
        apiFetch<NonNullable<typeof settingsData>>('/api/admin/settings'),
        apiFetch<NonNullable<typeof auditData>>('/api/admin/audit-logs'),
        apiFetch<NonNullable<typeof subAdminData>>('/api/admin/sub-admins'),
      ]);
      setAnalytics(a);
      setVerifications(v.applications || []);
      setUsersList(u.users || []);
      setShopsList(s.shops || []);
      setRidersList(r.riders || []);
      setOrdersList(o.orders || []);
      setFinance(f);
      setSettingsData(cfg);
      setAuditData(aud);
      setSubAdminData(sa);

      const fees = cfg.settings?.find((x) => x.key === 'fees_and_commissions')?.value;
      if (fees) {
        setCommRateInput(String(fees.defaultCommissionRate ?? 15));
        setBaseFeeInput(String(fees.baseDeliveryFee ?? 120));
        setPlatformFeeInput(String(fees.platformFee ?? 25));
      }
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to load admin console');
    }
  }, [apiFetch, pushToast]);

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    if (!q) return usersList;
    return usersList.filter(
      (u) =>
        u.fullName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q) ||
        u.role.toLowerCase().includes(q)
    );
  }, [usersList, userSearch]);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  useEffect(() => {
    if (!lastWsEvent) return;
    if (lastWsEvent.type.startsWith('admin:') || lastWsEvent.type.startsWith('order:') || lastWsEvent.type.startsWith('rider:')) {
      void loadAll();
    }
  }, [lastWsEvent, loadAll]);

  const navItems: Array<{ id: typeof tab; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'verifications', label: 'Verifications', icon: ShieldCheck },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'sub_admins', label: 'Admin Team', icon: UserCog },
    { id: 'shops', label: 'Shops & Categories', icon: Store },
    { id: 'riders', label: 'Riders & Fleet', icon: Bike },
    { id: 'orders', label: 'Orders', icon: ClipboardList },
    { id: 'finance', label: 'Finance', icon: Wallet },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'support', label: 'Support & Audit', icon: LifeBuoy },
    { id: 'privacy', label: 'Privacy & Safety', icon: Shield },
  ];

  const maxOrdersChart = Math.max(1, ...(analytics?.dailySeries.map((d) => d.orders) || [1]));

  return (
    <div className="min-h-screen bg-[#FAFAFA] flex flex-col lg:flex-row">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col bg-white border-r border-slate-200 sticky top-0 h-screen">
        <div className="px-6 h-16 flex items-center justify-between border-b border-slate-200">
          <DelivooLogo />
          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-900 text-white">
            {isMainAdmin ? 'Main' : 'Sub'}
          </span>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((n) => {
            const Icon = n.icon;
            return (
              <button
                key={n.id}
                type="button"
                onClick={() => setTab(n.id)}
                className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  tab === n.id
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{n.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="p-3 border-t border-slate-200 space-y-2">
          <p className="text-[11px] text-slate-500 px-1 truncate">
            {user?.fullName} &middot; {isMainAdmin ? 'Main Admin' : 'Sub-Admin'}
          </p>
          <button
            type="button"
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 bg-white border-b border-slate-200 px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="lg:hidden">
              <DelivooLogo size="sm" />
            </div>
            <h1 className="font-display text-base sm:text-lg font-bold text-slate-900 capitalize">
              Admin Command &middot; {tab.replace(/_/g, ' ')}
            </h1>
            <span className="hidden sm:inline-block text-[11px] font-semibold px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700">
              {isMainAdmin ? 'Main Admin' : 'Sub-Admin'}
            </span>
          </div>
          <button
            type="button"
            onClick={logout}
            className="lg:hidden px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold"
          >
            Sign Out
          </button>
        </header>

        {/* Mobile Tab Strip */}
        <div className="lg:hidden flex items-center gap-1.5 overflow-x-auto px-4 py-2 bg-white border-b border-slate-200">
          {navItems.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => setTab(n.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 ${
                tab === n.id ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {n.label}
            </button>
          ))}
        </div>

        <main className="p-4 sm:p-6 max-w-7xl w-full mx-auto space-y-6">
          {/* ANALYTICS */}
          {tab === 'analytics' && analytics && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Customers', value: analytics.kpis.totalCustomers },
                  { label: 'Total Shopkeepers', value: analytics.kpis.totalShopkeepers },
                  { label: 'Total Riders', value: analytics.kpis.totalRiders },
                  { label: 'Active Shops', value: analytics.kpis.activeShops },
                  { label: 'Pending Reviews', value: analytics.kpis.pendingRegistrations },
                  { label: 'Total Orders', value: analytics.kpis.totalOrders },
                  { label: 'Gross Order Value', value: `Rs ${analytics.kpis.grossOrderValue.toFixed(0)}` },
                  { label: 'Platform Revenue', value: `Rs ${analytics.kpis.platformRevenue.toFixed(0)}` },
                ].map((k) => (
                  <div key={k.label} className="rounded-2xl border border-slate-200 bg-white p-4">
                    <p className="text-xs text-slate-500">{k.label}</p>
                    <p className="font-display text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                      {k.value}
                    </p>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
                <h2 className="font-display text-base font-bold text-slate-900">
                  7-Day Order Volume &amp; Revenue
                </h2>
                <div className="grid grid-cols-7 gap-3 items-end h-44 pt-4">
                  {analytics.dailySeries.map((day) => {
                    const heightPct = Math.max(8, Math.round((day.orders / maxOrdersChart) * 100));
                    return (
                      <div key={day.label} className="flex flex-col items-center justify-end h-full gap-2">
                        <span className="text-[11px] font-mono text-slate-600 tabular-nums">{day.orders}</span>
                        <div
                          style={{ height: `${heightPct}%` }}
                          className="w-full max-w-[44px] rounded-t-lg bg-rose-600 transition-all"
                          title={`${day.label}: ${day.orders} orders · Rs ${day.gmv.toFixed(0)} GMV`}
                        />
                        <span className="text-xs font-medium text-slate-500">{day.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* VERIFICATIONS */}
          {tab === 'verifications' && (
            <div className="space-y-4">
              <h2 className="font-display text-xl font-bold text-slate-900">
                Verification Queue ({verifications.length})
              </h2>
              {verifications.length === 0 ? (
                <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
                  No verification applications submitted yet.
                </div>
              ) : (
                verifications.map((app) => (
                  <div key={app.id} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="text-xs text-slate-500 capitalize">
                          Role: {app.targetRole} &middot; Identity Provider: {app.identityProviderStatus} &middot; Risk Score: {app.riskScore}
                        </p>
                        <h3 className="font-display text-base font-bold text-slate-900">
                          {app.user?.fullName || `User #${app.userId}`} ({app.user?.email})
                        </h3>
                        <p className="text-xs text-slate-600 font-mono mt-0.5">
                          CNIC: {unmaskedCnic[app.id] || app.user?.cnicMasked || 'N/A'}
                          <button
                            type="button"
                            onClick={async () => {
                              const r = await apiFetch<{ cnicNumber: string }>(
                                `/api/admin/verifications/${app.id}/unmask-cnic`,
                                { method: 'POST' }
                              );
                              setUnmaskedCnic((prev) => ({ ...prev, [app.id]: r.cnicNumber }));
                            }}
                            className="ml-2 text-rose-600 hover:underline inline-flex items-center gap-1 font-sans font-semibold"
                          >
                            <Eye className="w-3 h-3" /> Reveal (Audited)
                          </button>
                        </p>
                      </div>
                      <span className="text-xs font-bold uppercase text-slate-700">
                        {app.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    {app.reviewNotes && (
                      <p className="text-xs text-slate-700 bg-slate-50 rounded-lg p-2.5">{app.reviewNotes}</p>
                    )}

                    {app.documents.length > 0 && (
                      <div className="flex flex-wrap gap-3">
                        {app.documents.map((doc) => (
                          <div key={doc.id} className="rounded-xl border border-slate-200 p-2 w-36 text-xs">
                            <img
                              src={doc.storageDataUrl}
                              alt={doc.docType}
                              className="w-full h-20 object-cover rounded-lg mb-1 bg-slate-100"
                            />
                            <p className="font-semibold text-slate-800 truncate">{doc.docType}</p>
                            {doc.expiryDate && <p className="text-[10px] text-slate-500">Exp: {doc.expiryDate}</p>}
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/verifications/${app.id}/decide`, {
                            method: 'POST',
                            body: JSON.stringify({ decision: 'approved', notes: 'Approved after compliance inspection' }),
                          });
                          await loadAll();
                          pushToast('success', 'Application approved.');
                        }}
                        className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold inline-flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setRejectModalAppId(app.id);
                          setRejectReasonInput('');
                        }}
                        className="px-4 py-2 rounded-xl border border-rose-200 text-rose-700 text-xs font-semibold inline-flex items-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Reject
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* USERS */}
          {tab === 'users' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="font-display text-xl font-bold text-slate-900">All Accounts</h2>
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search name, email, or phone..."
                  className="rounded-xl border border-slate-200 px-3.5 py-2 text-sm bg-white w-64"
                />
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600">
                    <tr>
                      <th className="py-3 px-4">Name</th>
                      <th className="py-3 px-4">Role</th>
                      <th className="py-3 px-4">Contact</th>
                      <th className="py-3 px-4">Masked CNIC</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/60">
                        <td className="py-3 px-4 font-semibold text-slate-900">{u.fullName}</td>
                        <td className="py-3 px-4 capitalize text-slate-600">
                          {u.role === 'admin'
                            ? u.adminTier === 'sub'
                              ? 'Sub-Admin'
                              : 'Main Admin'
                            : u.role}
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          {u.email} &middot; <span className="font-mono">{u.phone}</span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-500">{u.cnicMasked || '—'}</td>
                        <td className="py-3 px-4 font-semibold capitalize">{u.accountStatus.replace(/_/g, ' ')}</td>
                        <td className="py-3 px-4 text-right space-x-2">
                          {u.accountStatus !== 'approved' && (u.role !== 'admin' || (isMainAdmin && u.adminTier === 'sub')) && (
                            <button
                              type="button"
                              onClick={async () => {
                                await apiFetch(`/api/admin/users/${u.id}/status`, {
                                  method: 'PATCH',
                                  body: JSON.stringify({ accountStatus: 'approved' }),
                                });
                                await loadAll();
                              }}
                              className="text-emerald-700 font-semibold hover:underline"
                            >
                              Approve
                            </button>
                          )}
                          {(u.role !== 'admin' || (isMainAdmin && u.adminTier === 'sub')) && u.accountStatus !== 'suspended' && (
                            <button
                              type="button"
                              onClick={async () => {
                                await apiFetch(`/api/admin/users/${u.id}/status`, {
                                  method: 'PATCH',
                                  body: JSON.stringify({ accountStatus: 'suspended', reason: 'Suspended by Admin' }),
                                });
                                await loadAll();
                              }}
                              className="text-rose-700 font-semibold hover:underline"
                            >
                              Suspend
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ADMIN HIERARCHY: 1 MAIN ADMIN + UP TO 3 SUB-ADMINS */}
          {tab === 'sub_admins' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="font-display text-xl font-bold text-slate-900">
                    Admin Hierarchy &amp; Sub-Admins
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    DELIVOO enforces 1 Main Administrator at the top with up to {subAdminData?.maxSubAdmins ?? 3} Sub-Admins beneath them.
                  </p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-800 tabular-nums">
                  Sub-Admin Slots Used: {subAdminData?.subAdmins.length ?? 0} / {subAdminData?.maxSubAdmins ?? 3}
                </div>
              </div>

              {subAdminData?.mainAdmin && (
                <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="inline-block text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded bg-slate-900 text-white">
                      Main Admin (Top Authority)
                    </span>
                    <h3 className="font-display text-base font-bold text-slate-900 pt-1">
                      {subAdminData.mainAdmin.fullName}
                    </h3>
                    <p className="text-xs text-slate-600">
                      {subAdminData.mainAdmin.email} &middot; <span className="font-mono">{subAdminData.mainAdmin.phone}</span>
                    </p>
                  </div>
                  <span className="text-xs font-semibold text-emerald-700 capitalize">
                    {subAdminData.mainAdmin.accountStatus}
                  </span>
                </div>
              )}

              {isMainAdmin ? (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    setSubAdminBusy(true);
                    try {
                      await apiFetch('/api/admin/sub-admins', {
                        method: 'POST',
                        body: JSON.stringify(subAdminForm),
                      });
                      setSubAdminForm({ fullName: '', email: '', phone: '+923001119900', password: '' });
                      await loadAll();
                      pushToast('success', 'Sub-Admin account created and ready.');
                    } catch (err) {
                      pushToast('error', err instanceof Error ? err.message : 'Unable to create Sub-Admin');
                    } finally {
                      setSubAdminBusy(false);
                    }
                  }}
                  className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-base font-bold text-slate-900">
                      Create Sub-Admin ({subAdminData?.remainingSlots ?? 3} slot(s) remaining)
                    </h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    <input
                      type="text"
                      required
                      disabled={(subAdminData?.remainingSlots ?? 3) <= 0}
                      value={subAdminForm.fullName}
                      onChange={(e) => setSubAdminForm((f) => ({ ...f, fullName: e.target.value }))}
                      placeholder="Full Name *"
                      className="rounded-xl border border-slate-200 px-3 py-2 text-sm disabled:bg-slate-50"
                    />
                    <input
                      type="email"
                      required
                      disabled={(subAdminData?.remainingSlots ?? 3) <= 0}
                      value={subAdminForm.email}
                      onChange={(e) => setSubAdminForm((f) => ({ ...f, email: e.target.value }))}
                      placeholder="Email Address *"
                      className="rounded-xl border border-slate-200 px-3 py-2 text-sm disabled:bg-slate-50"
                    />
                    <input
                      type="tel"
                      required
                      disabled={(subAdminData?.remainingSlots ?? 3) <= 0}
                      value={subAdminForm.phone}
                      onChange={(e) => setSubAdminForm((f) => ({ ...f, phone: e.target.value }))}
                      placeholder="Phone (+92300...)"
                      className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono disabled:bg-slate-50"
                    />
                    <input
                      type="password"
                      required
                      minLength={8}
                      disabled={(subAdminData?.remainingSlots ?? 3) <= 0}
                      value={subAdminForm.password}
                      onChange={(e) => setSubAdminForm((f) => ({ ...f, password: e.target.value }))}
                      placeholder="Password (min 8 chars)"
                      className="rounded-xl border border-slate-200 px-3 py-2 text-sm disabled:bg-slate-50"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={subAdminBusy || (subAdminData?.remainingSlots ?? 3) <= 0}
                    className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold disabled:opacity-50"
                  >
                    {(subAdminData?.remainingSlots ?? 3) <= 0
                      ? 'Maximum 3 Sub-Admins Reached'
                      : subAdminBusy
                      ? 'Creating Sub-Admin...'
                      : 'Add Sub-Admin'}
                  </button>
                </form>
              ) : (
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600">
                  Signed in as a Sub-Admin. Only the Main Admin can create, suspend, or remove Sub-Admin accounts.
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {(subAdminData?.subAdmins || []).length === 0 ? (
                  <div className="md:col-span-3 rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
                    No Sub-Admins added yet. Up to 3 Sub-Admins can operate under the Main Admin.
                  </div>
                ) : (
                  (subAdminData?.subAdmins || []).map((sa, index) => (
                    <div key={sa.id} className="rounded-2xl border border-slate-200 bg-white p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase text-rose-700">
                          Sub-Admin #{index + 1}
                        </span>
                        <span className="text-xs font-semibold capitalize text-slate-600">
                          {sa.accountStatus}
                        </span>
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900">{sa.fullName}</h4>
                        <p className="text-xs text-slate-600 truncate">{sa.email}</p>
                        <p className="text-xs font-mono text-slate-500 mt-0.5">{sa.phone}</p>
                      </div>
                      {isMainAdmin && (
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                          <button
                            type="button"
                            onClick={async () => {
                              const nextStatus = sa.accountStatus === 'approved' ? 'suspended' : 'approved';
                              await apiFetch(`/api/admin/sub-admins/${sa.id}`, {
                                method: 'PATCH',
                                body: JSON.stringify({ accountStatus: nextStatus }),
                              });
                              await loadAll();
                              pushToast('success', `Sub-Admin ${nextStatus === 'approved' ? 'activated' : 'suspended'}.`);
                            }}
                            className="flex-1 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                          >
                            {sa.accountStatus === 'approved' ? 'Suspend' : 'Activate'}
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await apiFetch(`/api/admin/sub-admins/${sa.id}`, { method: 'DELETE' });
                              await loadAll();
                              pushToast('info', 'Sub-Admin removed.');
                            }}
                            aria-label={`Remove ${sa.fullName}`}
                            className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* SHOPS & CATEGORIES */}
          {tab === 'shops' && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                <h3 className="font-display text-base font-bold text-slate-900">Marketplace Categories</h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="New category name..."
                    className="rounded-xl border border-slate-200 px-3 py-2 text-sm flex-1 max-w-xs"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      if (!newCatName.trim()) return;
                      await apiFetch('/api/admin/categories', {
                        method: 'POST',
                        body: JSON.stringify({ name: newCatName }),
                      });
                      setNewCatName('');
                      await loadAll();
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                  >
                    Add Category
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 text-xs">
                  {settingsData?.categories.filter((c) => c.isActive).map((c) => (
                    <span key={c.id} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-1.5 bg-slate-50">
                      {c.name}
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/categories/${c.id}`, { method: 'DELETE' });
                          await loadAll();
                        }}
                        className="text-rose-600 font-bold"
                      >
                        &times;
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {shopsList.map((s) => (
                  <div key={s.id} className="rounded-2xl border border-slate-200 bg-white p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900">{s.name}</h4>
                      <span className="text-xs font-semibold capitalize text-slate-600">{s.approvalStatus}</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      {s.categoryName} &middot; Commission {s.commissionRate}% &middot; Rating {s.rating}
                    </p>
                    <div className="flex gap-2 pt-2">
                      {s.approvalStatus !== 'approved' && (
                        <button
                          type="button"
                          onClick={async () => {
                            await apiFetch(`/api/admin/shops/${s.id}/status`, {
                              method: 'PATCH',
                              body: JSON.stringify({ approvalStatus: 'approved' }),
                            });
                            await loadAll();
                          }}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
                        >
                          Approve Shop
                        </button>
                      )}
                      {s.approvalStatus !== 'suspended' && (
                        <button
                          type="button"
                          onClick={async () => {
                            await apiFetch(`/api/admin/shops/${s.id}/status`, {
                              method: 'PATCH',
                              body: JSON.stringify({ approvalStatus: 'suspended' }),
                            });
                            await loadAll();
                          }}
                          className="px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 text-xs font-semibold"
                        >
                          Suspend
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* RIDERS & LIVE FLEET MAP */}
          {tab === 'riders' && (
            <div className="space-y-6">
              <DeliveryMap
                markers={[
                  ...shopsList.map((s) => ({ lat: s.lat, lng: s.lng, label: `Shop: ${s.name}`, kind: 'shop' as const })),
                  ...ridersList.map((r) => ({
                    lat: r.currentLat || 24.8607,
                    lng: r.currentLng || 67.0011,
                    label: `Rider: ${r.fullName} (${r.isOnline ? 'Online' : 'Offline'})`,
                    kind: 'rider' as const,
                  })),
                ]}
                heightClass="h-72"
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {ridersList.map((r) => (
                  <div key={r.userId} className="rounded-2xl border border-slate-200 bg-white p-4 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-sm text-slate-900">{r.fullName}</p>
                      <p className="text-xs text-slate-500">
                        {r.vehicleType} &middot; {r.isOnline ? 'Online' : 'Offline'} &middot; {r.totalDeliveries} drops &middot; Active: {r.activeOrdersCount}
                      </p>
                    </div>
                    <span className="text-xs font-semibold capitalize text-emerald-700">{r.accountStatus}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ORDERS & MANUAL RIDER ASSIGNMENT */}
          {tab === 'orders' && (
            <div className="space-y-3">
              <h2 className="font-display text-xl font-bold text-slate-900">All Platform Orders</h2>
              {ordersList.map((o) => (
                <div key={o.id} className="rounded-2xl border border-slate-200 bg-white p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div>
                    <p className="font-mono font-bold text-slate-900">
                      {o.orderNumber} &middot; Rs {Number(o.totalAmount).toFixed(0)} ({o.paymentStatus})
                    </p>
                    <p className="text-slate-600 mt-0.5">
                      {o.customerName} &rarr; {o.shopName} &middot; Status: <strong>{o.status.replace(/_/g, ' ')}</strong>
                      {o.riderName ? ` · Rider: ${o.riderName}` : ' · Unassigned'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={assignRiderByOrder[o.id] || ''}
                      onChange={(e) =>
                        setAssignRiderByOrder((prev) => ({ ...prev, [o.id]: Number(e.target.value) }))
                      }
                      className="rounded-lg border border-slate-200 px-2.5 py-1.5 bg-white"
                    >
                      <option value="">Assign / Reassign Rider</option>
                      {ridersList
                        .filter((r) => r.accountStatus === 'approved')
                        .map((r) => (
                          <option key={r.userId} value={r.userId}>
                            {r.fullName} ({r.isOnline ? 'Online' : 'Offline'})
                          </option>
                        ))}
                    </select>
                    <button
                      type="button"
                      disabled={!assignRiderByOrder[o.id]}
                      onClick={async () => {
                        await apiFetch(`/api/admin/orders/${o.id}/assign-rider`, {
                          method: 'POST',
                          body: JSON.stringify({ riderId: assignRiderByOrder[o.id] }),
                        });
                        await loadAll();
                        pushToast('success', 'Rider assigned manually.');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 text-white font-semibold disabled:opacity-40"
                    >
                      Assign
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* FINANCE */}
          {tab === 'finance' && finance && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-slate-900">Record Shop Settlement Payout</h3>
                <div className="flex flex-wrap gap-2">
                  <select
                    value={settleShopId}
                    onChange={(e) => setSettleShopId(e.target.value)}
                    className="rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white"
                  >
                    <option value="">Select Shop</option>
                    {shopsList.map((s) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={settleAmount}
                    onChange={(e) => setSettleAmount(e.target.value)}
                    placeholder="Net Payout Amount (Rs)"
                    className="rounded-xl border border-slate-200 px-3 py-2 text-sm"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      if (!settleShopId || !settleAmount) return;
                      await apiFetch('/api/admin/settlements', {
                        method: 'POST',
                        body: JSON.stringify({
                          shopId: Number(settleShopId),
                          periodLabel: `Settlement ${new Date().toLocaleDateString()}`,
                          netAmount: Number(settleAmount),
                        }),
                      });
                      setSettleAmount('');
                      await loadAll();
                      pushToast('success', 'Settlement recorded.');
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
                  >
                    Process Payout
                  </button>
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-slate-900">
                  Refund Requests ({finance.refunds.length})
                </h3>
                {finance.refunds.map((ref) => (
                  <div key={ref.id} className="flex items-center justify-between border-b border-slate-100 py-2 text-xs">
                    <div>
                      <p className="font-bold text-slate-900">Order #{ref.orderId} &middot; Rs {ref.amount}</p>
                      <p className="text-slate-500">{ref.reason} &middot; Status: {ref.status}</p>
                    </div>
                    {ref.status === 'pending' && (
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            await apiFetch(`/api/admin/refunds/${ref.id}/process`, {
                              method: 'POST',
                              body: JSON.stringify({ action: 'processed' }),
                            });
                            await loadAll();
                          }}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold"
                        >
                          Approve Refund
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* PLATFORM SETTINGS */}
          {tab === 'settings' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
                <h3 className="font-display text-base font-bold text-slate-900">
                  Commission, Delivery &amp; Platform Fees
                </h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Default Commission (%)</label>
                    <input
                      type="number"
                      value={commRateInput}
                      onChange={(e) => setCommRateInput(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Base Delivery Fee (Rs)</label>
                    <input
                      type="number"
                      value={baseFeeInput}
                      onChange={(e) => setBaseFeeInput(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Platform Service Fee (Rs)</label>
                    <input
                      type="number"
                      value={platformFeeInput}
                      onChange={(e) => setPlatformFeeInput(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 px-3 py-2"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      await apiFetch('/api/admin/settings', {
                        method: 'PATCH',
                        body: JSON.stringify({
                          key: 'fees_and_commissions',
                          value: {
                            defaultCommissionRate: Number(commRateInput),
                            baseDeliveryFee: Number(baseFeeInput),
                            platformFee: Number(platformFeeInput),
                            taxRatePercent: 5,
                            riderBaseDropEarning: 110,
                          },
                        }),
                      });
                      pushToast('success', 'Platform financial rates updated.');
                    }}
                    className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold"
                  >
                    Save Rates
                  </button>
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
                <h3 className="font-display text-base font-bold text-slate-900">Promotions &amp; Coupons</h3>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={newCouponCode}
                    onChange={(e) => setNewCouponCode(e.target.value)}
                    placeholder="CODE"
                    className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-mono uppercase"
                  />
                  <input
                    type="text"
                    value={newCouponTitle}
                    onChange={(e) => setNewCouponTitle(e.target.value)}
                    placeholder="Title"
                    className="rounded-xl border border-slate-200 px-3 py-2 text-xs"
                  />
                  <input
                    type="number"
                    value={newCouponVal}
                    onChange={(e) => setNewCouponVal(e.target.value)}
                    placeholder="% off"
                    className="rounded-xl border border-slate-200 px-3 py-2 text-xs"
                  />
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    await apiFetch('/api/admin/coupons', {
                      method: 'POST',
                      body: JSON.stringify({
                        code: newCouponCode,
                        title: newCouponTitle,
                        discountType: 'percent',
                        discountValue: Number(newCouponVal),
                      }),
                    });
                    setNewCouponCode('');
                    setNewCouponTitle('');
                    await loadAll();
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                >
                  Create Coupon
                </button>

                <div className="divide-y divide-slate-100 text-xs">
                  {settingsData?.coupons.map((c) => (
                    <div key={c.id} className="py-2 flex items-center justify-between">
                      <span>
                        <strong className="font-mono">{c.code}</strong> &middot; {c.title}
                      </span>
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/coupons/${c.id}`, { method: 'DELETE' });
                          await loadAll();
                        }}
                        className="text-rose-600 font-semibold"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SUPPORT & AUDIT LOGS */}
          {tab === 'support' && auditData && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-slate-900">Support Tickets</h3>
                {auditData.supportTickets.map((t) => (
                  <div key={t.id} className="rounded-xl border border-slate-200 p-3 text-xs space-y-2">
                    <div className="flex justify-between font-bold text-slate-900">
                      <span>{t.subject} ({t.userRole})</span>
                      <span className="capitalize">{t.status}</span>
                    </div>
                    <p className="text-slate-600">{t.description}</p>
                    {t.status !== 'resolved' && (
                      <button
                        type="button"
                        onClick={() => {
                          setResolveTicketId(t.id);
                          setResolveNoteInput('');
                        }}
                        className="px-3 py-1 rounded-lg bg-emerald-600 text-white font-semibold"
                      >
                        Mark Resolved
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3 max-h-[500px] overflow-y-auto">
                <h3 className="font-display text-base font-bold text-slate-900">Security Audit Trail</h3>
                {auditData.auditLogs.map((l) => (
                  <div key={l.id} className="text-xs border-b border-slate-100 pb-2">
                    <p className="font-semibold text-slate-900">
                      {l.action} <span className="text-slate-400 font-normal">&middot; {l.actorRole}</span>
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono">
                      {l.targetType} #{l.targetId || '—'} &middot; {new Date(l.createdAt).toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'privacy' && <PrivacySafetyPanel />}
        </main>
      </div>

      {/* Verification Rejection Reason Modal */}
      {rejectModalAppId !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-200 p-6 space-y-4 shadow-2xl">
            <h3 className="font-display text-lg font-bold text-slate-900">Reject Verification Application</h3>
            <p className="text-xs text-slate-600">
              Provide a clear reason so the applicant can fix and resubmit their documents.
            </p>
            <textarea
              rows={3}
              value={rejectReasonInput}
              onChange={(e) => setRejectReasonInput(e.target.value)}
              placeholder="e.g. CNIC front image is blurry or driving licence is expired..."
              className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setRejectModalAppId(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  const targetId = rejectModalAppId;
                  const reason = rejectReasonInput.trim() || 'Documents could not be verified';
                  setRejectModalAppId(null);
                  await apiFetch(`/api/admin/verifications/${targetId}/decide`, {
                    method: 'POST',
                    body: JSON.stringify({ decision: 'rejected', notes: reason }),
                  });
                  await loadAll();
                  pushToast('info', 'Application rejected with feedback.');
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support Ticket Resolution Modal */}
      {resolveTicketId !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-200 p-6 space-y-4 shadow-2xl">
            <h3 className="font-display text-lg font-bold text-slate-900">Resolve Support Ticket</h3>
            <textarea
              rows={3}
              value={resolveNoteInput}
              onChange={(e) => setResolveNoteInput(e.target.value)}
              placeholder="Enter resolution details for the customer or partner..."
              className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setResolveTicketId(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  const targetId = resolveTicketId;
                  const notes = resolveNoteInput.trim() || 'Resolved by Support Admin';
                  setResolveTicketId(null);
                  await apiFetch(`/api/support/tickets/${targetId}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ status: 'resolved', resolutionNotes: notes }),
                  });
                  await loadAll();
                  pushToast('success', 'Support ticket resolved.');
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
              >
                Mark Resolved
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
