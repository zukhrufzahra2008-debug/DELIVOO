import { Router, type Request, type Response } from 'express';
import crypto from 'node:crypto';
import { eq, and, desc, inArray, ne } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  users,
  otpVerifications,
  customerProfiles,
  riderProfiles,
  shopProfiles,
  verificationApplications,
  verificationDocuments,
  addresses,
  orders,
  notifications,
  auditLogs,
} from '../../db/schema.ts';
import { adminAuth } from '../../lib/firebase-admin.ts';
import {
  calculateAgeFromDob,
  createRateLimiter,
  generateSixDigitOtp,
  hashOtp,
  hashPassword,
  isValidCnicFormat,
  maskCnic,
  sanitizePublicUser,
  signAuthToken,
  verifyPassword,
} from '../security.ts';
import { requireAuth, type AuthedRequest } from '../middleware/auth.ts';
import { verificationQueue } from '../services/verification.ts';
import { dispatchExternalOtp } from '../services/otpDelivery.ts';
import { emitToRole } from '../ws.ts';

const router = Router();
const authRateLimiter = createRateLimiter(30, 60_000);

function isHttpsRequest(req: Request): boolean {
  const fwdProto = req.headers['x-forwarded-proto'];
  const protoStr = Array.isArray(fwdProto) ? fwdProto[0] : fwdProto;
  return Boolean(req.secure || (protoStr && protoStr.includes('https')));
}

function setSessionCookie(res: Response, req: Request, token: string): void {
  const encoded = encodeURIComponent(token);
  if (isHttpsRequest(req)) {
    res.setHeader(
      'Set-Cookie',
      `delivoo_session=${encoded}; Path=/; HttpOnly; Max-Age=604800; SameSite=None; Secure; Partitioned`
    );
  } else {
    res.setHeader(
      'Set-Cookie',
      `delivoo_session=${encoded}; Path=/; HttpOnly; Max-Age=604800; SameSite=Lax`
    );
  }
}

function clearSessionCookie(res: Response, req: Request): void {
  if (isHttpsRequest(req)) {
    res.setHeader(
      'Set-Cookie',
      'delivoo_session=; Path=/; HttpOnly; Max-Age=0; SameSite=None; Secure; Partitioned'
    );
  } else {
    res.setHeader(
      'Set-Cookie',
      'delivoo_session=; Path=/; HttpOnly; Max-Age=0; SameSite=Lax'
    );
  }
}

async function issueOtp(userId: number | null, target: string, channel: 'email' | 'phone' | 'password_reset') {
  const code = generateSixDigitOtp();
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await db.insert(otpVerifications).values({
    userId,
    target: target.toLowerCase(),
    channel,
    codeHash: hashOtp(code),
    expiresAt,
  });

  // Dispatch strictly to the user's external email or phone/contact — never return raw code to client UI
  return dispatchExternalOtp(target, channel, code);
}

// Check if initial admin exists (for first-run admin claim flow)
router.get('/admin-bootstrap-status', async (_req, res) => {
  try {
    const admins = await db
      .select({ id: users.id })
      .from(users)
      .where(and(eq(users.role, 'admin'), ne(users.accountStatus, 'deleted')));
    res.json({
      hasAdmin: admins.length > 0,
      hasEnvPasscode: Boolean(process.env.ADMIN_INITIAL_PASSWORD && process.env.ADMIN_INITIAL_PASSWORD.trim()),
    });
  } catch (error) {
    console.error('Admin bootstrap status error:', error);
    res.status(500).json({ error: 'Unable to check admin setup status' });
  }
});

// One-time atomic first-run admin setup
router.post('/admin-bootstrap', authRateLimiter, async (req, res) => {
  try {
    const { email, fullName, phone, password, envPasscode } = req.body as {
      email?: string;
      fullName?: string;
      phone?: string;
      password?: string;
      envPasscode?: string;
    };

    const admins = await db
      .select({ id: users.id })
      .from(users)
      .where(and(eq(users.role, 'admin'), ne(users.accountStatus, 'deleted')));
    if (admins.length > 0) {
      return res.status(403).json({ error: 'Main Admin account is already claimed. Please sign in.' });
    }

    const configuredPasscode = process.env.ADMIN_INITIAL_PASSWORD?.trim();
    if (configuredPasscode && envPasscode !== configuredPasscode) {
      return res.status(403).json({ error: 'Invalid administrator setup passcode' });
    }

    if (!email || !fullName || !password || password.length < 8) {
      return res.status(400).json({ error: 'Valid email, full name, and password (min 8 chars) are required' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, normalizedEmail));
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Email is already registered' });
    }

    const [created] = await db
      .insert(users)
      .values({
        uid: `admin-${crypto.randomUUID()}`,
        email: normalizedEmail,
        passwordHash: hashPassword(password),
        fullName: fullName.trim(),
        phone: (phone || '+923000000000').trim(),
        role: 'admin',
        adminTier: 'main',
        accountStatus: 'approved',
        emailVerified: true,
        phoneVerified: true,
      })
      .returning();

    await db.insert(auditLogs).values({
      actorId: created.id,
      actorRole: 'admin',
      action: 'admin_bootstrap_claimed',
      targetType: 'user',
      targetId: String(created.id),
      ipAddress: req.ip,
    });

    const token = signAuthToken({
      userId: created.id,
      uid: created.uid,
      email: created.email,
      role: created.role,
    });
    setSessionCookie(res, req, token);

    res.status(201).json({
      token,
      user: sanitizePublicUser(created),
    });
  } catch (error) {
    console.error('Admin bootstrap error:', error);
    res.status(500).json({ error: 'Failed to set up administrator account' });
  }
});

// Unified Login (detects role automatically from DB)
router.post('/login', authRateLimiter, async (req, res) => {
  try {
    const { email, password } = req.body as { email?: string; password?: string };
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const [user] = await db.select().from(users).where(eq(users.email, normalizedEmail));
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email address or password' });
    }

    if (user.accountStatus === 'deleted') {
      return res.status(403).json({ error: 'This account has been permanently deleted' });
    }
    if (user.accountStatus === 'suspended') {
      return res.status(403).json({ error: 'Your account is suspended. Please contact DELIVOO support.' });
    }

    await db.insert(auditLogs).values({
      actorId: user.id,
      actorRole: user.role,
      action: 'user_login',
      targetType: 'user',
      targetId: String(user.id),
      ipAddress: req.ip,
    });

    const token = signAuthToken({
      userId: user.id,
      uid: user.uid,
      email: user.email,
      role: user.role,
    });
    setSessionCookie(res, req, token);

    res.json({
      token,
      user: sanitizePublicUser(user),
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// Firebase Google Sign-In session exchange
router.post('/firebase-session', authRateLimiter, async (req, res) => {
  try {
    const { idToken } = req.body as { idToken?: string };
    if (!idToken) {
      return res.status(400).json({ error: 'Firebase ID token is required' });
    }

    const decoded = await adminAuth.verifyIdToken(idToken);
    if (!decoded.email) {
      return res.status(400).json({ error: 'Google account email is required' });
    }

    const normalizedEmail = decoded.email.toLowerCase();
    let [user] = await db.select().from(users).where(eq(users.email, normalizedEmail));

    if (!user) {
      // Check if no admin exists yet and this is the owner's email or create standard customer
      const admins = await db
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.role, 'admin'), ne(users.accountStatus, 'deleted')));
      const isInitialOwner = admins.length === 0 && normalizedEmail === 'zukhrufzahra2008@gmail.com';
      const role = isInitialOwner ? 'admin' : 'customer';

      const [created] = await db
        .insert(users)
        .values({
          uid: decoded.uid,
          email: normalizedEmail,
          fullName: decoded.name || normalizedEmail.split('@')[0],
          phone: decoded.phone_number || '+923000000000',
          role,
          adminTier: isInitialOwner ? 'main' : null,
          accountStatus: 'approved',
          emailVerified: Boolean(decoded.email_verified),
          phoneVerified: false,
        })
        .returning();

      if (role === 'customer') {
        await db.insert(customerProfiles).values({ userId: created.id, ageVerified: false }).onConflictDoNothing();
      }
      user = created;
    }

    if (user.accountStatus === 'deleted' || user.accountStatus === 'suspended') {
      return res.status(403).json({ error: `Account is ${user.accountStatus}` });
    }

    const token = signAuthToken({
      userId: user.id,
      uid: user.uid,
      email: user.email,
      role: user.role,
    });
    setSessionCookie(res, req, token);

    res.json({ token, user: sanitizePublicUser(user) });
  } catch (error) {
    console.error('Firebase session error:', error);
    res.status(401).json({ error: 'Could not verify Google sign-in session' });
  }
});

// Sign out & clear session cookie
router.post('/logout', (req, res) => {
  clearSessionCookie(res, req);
  res.json({ ok: true });
});

// Get current session profile + role details
router.get('/me', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const [[user], [latestApp]] = await Promise.all([
      db.select().from(users).where(eq(users.id, authUser.id)),
      db
        .select()
        .from(verificationApplications)
        .where(eq(verificationApplications.userId, authUser.id))
        .orderBy(desc(verificationApplications.id))
        .limit(1),
    ]);
    if (!user) return res.status(404).json({ error: 'User not found' });

    let roleProfile: Record<string, unknown> | null = null;
    if (user.role === 'rider') {
      const [rp] = await db.select().from(riderProfiles).where(eq(riderProfiles.userId, user.id));
      roleProfile = rp || null;
    } else if (user.role === 'shopkeeper') {
      const [sp] = await db.select().from(shopProfiles).where(eq(shopProfiles.ownerId, user.id));
      roleProfile = sp || null;
    } else if (user.role === 'customer') {
      const [[cp], userAddresses] = await Promise.all([
        db.select().from(customerProfiles).where(eq(customerProfiles.userId, user.id)),
        db.select().from(addresses).where(eq(addresses.userId, user.id)),
      ]);
      roleProfile = { ...cp, addresses: userAddresses };
    }

    const wsToken = signAuthToken({
      userId: user.id,
      uid: user.uid,
      email: user.email,
      role: user.role,
    });

    res.json({
      wsToken,
      user: sanitizePublicUser(user),
      verificationApplication: latestApp || null,
      roleProfile,
    });
  } catch (error) {
    console.error('Get /me error:', error);
    res.status(500).json({ error: 'Failed to load profile' });
  }
});

// Customer Registration
router.post('/register/customer', authRateLimiter, async (req, res) => {
  try {
    const { fullName, dob, phone, email, cnicNumber, password, confirmPassword } = req.body as Record<string, string>;

    if (!fullName || !dob || !phone || !email || !cnicNumber || !password) {
      return res.status(400).json({ error: 'All registration fields are required' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }
    const age = calculateAgeFromDob(dob);
    if (age === null || age < 18) {
      return res.status(400).json({ error: 'You must be at least 18 years old to register' });
    }
    if (!isValidCnicFormat(cnicNumber)) {
      return res.status(400).json({ error: 'CNIC must follow format XXXXX-XXXXXXX-X' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const dupEmail = await db.select({ id: users.id }).from(users).where(eq(users.email, normalizedEmail));
    if (dupEmail.length > 0) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }
    const dupPhone = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone.trim()));
    if (dupPhone.length > 0) {
      return res.status(409).json({ error: 'An account with this phone number already exists' });
    }
    const dupCnic = await db.select({ id: users.id }).from(users).where(eq(users.cnicNumber, cnicNumber.trim()));
    if (dupCnic.length > 0) {
      return res.status(409).json({ error: 'An account with this CNIC already exists' });
    }

    const [created] = await db
      .insert(users)
      .values({
        uid: `cust-${crypto.randomUUID()}`,
        email: normalizedEmail,
        passwordHash: hashPassword(password),
        fullName: fullName.trim(),
        phone: phone.trim(),
        dob,
        cnicNumber: cnicNumber.trim(),
        cnicMasked: maskCnic(cnicNumber.trim()),
        role: 'customer',
        accountStatus: 'pending_verification',
      })
      .returning();

    await db.insert(customerProfiles).values({
      userId: created.id,
      ageVerified: true,
    });

    const [app] = await db
      .insert(verificationApplications)
      .values({
        userId: created.id,
        targetRole: 'customer',
        status: 'pending_verification',
      })
      .returning();

    const emailOtp = await issueOtp(created.id, normalizedEmail, 'email');
    const phoneOtp = await issueOtp(created.id, phone.trim(), 'phone');

    emitToRole('admin', 'admin:new_registration', {
      userId: created.id,
      fullName: created.fullName,
      role: 'customer',
    });

    const token = signAuthToken({
      userId: created.id,
      uid: created.uid,
      email: created.email,
      role: created.role,
    });
    setSessionCookie(res, req, token);

    res.status(201).json({
      token,
      user: sanitizePublicUser(created),
      applicationId: app.id,
      otps: { emailOtp, phoneOtp },
    });
  } catch (error) {
    console.error('Customer registration error:', error);
    res.status(500).json({ error: 'Customer registration failed' });
  }
});

// Rider Registration
router.post('/register/rider', authRateLimiter, async (req, res) => {
  try {
    const {
      fullName,
      dob,
      phone,
      email,
      cnicNumber,
      residentialAddress,
      vehicleType,
      vehicleRegistration,
      drivingLicenseNumber,
      licenseExpiryDate,
      emergencyContact,
      password,
      confirmPassword,
      documents,
    } = req.body as {
      fullName?: string;
      dob?: string;
      phone?: string;
      email?: string;
      cnicNumber?: string;
      residentialAddress?: string;
      vehicleType?: string;
      vehicleRegistration?: string;
      drivingLicenseNumber?: string;
      licenseExpiryDate?: string;
      emergencyContact?: string;
      password?: string;
      confirmPassword?: string;
      documents?: Array<{ docType: string; fileName: string; mimeType: string; fileSize: number; storageDataUrl: string; expiryDate?: string }>;
    };

    if (!fullName || !dob || !phone || !email || !cnicNumber || !residentialAddress || !vehicleType || !emergencyContact || !password) {
      return res.status(400).json({ error: 'All required rider registration fields must be filled' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }
    const age = calculateAgeFromDob(dob);
    if (age === null || age < 18) {
      return res.status(400).json({ error: 'Riders must be at least 18 years old' });
    }
    if (!isValidCnicFormat(cnicNumber)) {
      return res.status(400).json({ error: 'CNIC must follow format XXXXX-XXXXXXX-X' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const dupEmail = await db.select({ id: users.id }).from(users).where(eq(users.email, normalizedEmail));
    if (dupEmail.length > 0) return res.status(409).json({ error: 'Email already registered' });
    const dupPhone = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone.trim()));
    if (dupPhone.length > 0) return res.status(409).json({ error: 'Phone number already registered' });
    const dupCnic = await db.select({ id: users.id }).from(users).where(eq(users.cnicNumber, cnicNumber.trim()));
    if (dupCnic.length > 0) return res.status(409).json({ error: 'CNIC already registered' });

    const [created] = await db
      .insert(users)
      .values({
        uid: `rider-${crypto.randomUUID()}`,
        email: normalizedEmail,
        passwordHash: hashPassword(password),
        fullName: fullName.trim(),
        phone: phone.trim(),
        dob,
        cnicNumber: cnicNumber.trim(),
        cnicMasked: maskCnic(cnicNumber.trim()),
        role: 'rider',
        accountStatus: 'pending_verification',
      })
      .returning();

    const profilePhotoDoc = documents?.find((d) => d.docType === 'profile_photo');
    await db.insert(riderProfiles).values({
      userId: created.id,
      residentialAddress: residentialAddress.trim(),
      vehicleType,
      vehicleRegistration: vehicleRegistration?.trim() || null,
      drivingLicenseNumber: drivingLicenseNumber?.trim() || null,
      licenseExpiryDate: licenseExpiryDate || null,
      emergencyContact: emergencyContact.trim(),
      profilePhotoUrl: profilePhotoDoc?.storageDataUrl || null,
    });

    const [app] = await db
      .insert(verificationApplications)
      .values({
        userId: created.id,
        targetRole: 'rider',
        status: 'pending_verification',
      })
      .returning();

    if (Array.isArray(documents) && documents.length > 0) {
      const validDocs = documents
        .filter((d) => d.fileName && d.storageDataUrl && d.fileSize <= 5 * 1024 * 1024)
        .map((d) => ({
          applicationId: app.id,
          userId: created.id,
          docType: d.docType,
          fileName: d.fileName,
          mimeType: d.mimeType || 'image/jpeg',
          fileSize: d.fileSize || 1024,
          storageDataUrl: d.storageDataUrl,
          expiryDate: d.expiryDate || (d.docType === 'driving_license' ? licenseExpiryDate : undefined) || null,
        }));
      if (validDocs.length > 0) {
        await db.insert(verificationDocuments).values(validDocs);
      }
    }

    const emailOtp = await issueOtp(created.id, normalizedEmail, 'email');
    const phoneOtp = await issueOtp(created.id, phone.trim(), 'phone');

    emitToRole('admin', 'admin:new_registration', {
      userId: created.id,
      fullName: created.fullName,
      role: 'rider',
    });

    const token = signAuthToken({
      userId: created.id,
      uid: created.uid,
      email: created.email,
      role: created.role,
    });
    setSessionCookie(res, req, token);

    res.status(201).json({
      token,
      user: sanitizePublicUser(created),
      applicationId: app.id,
      otps: { emailOtp, phoneOtp },
    });
  } catch (error) {
    console.error('Rider registration error:', error);
    res.status(500).json({ error: 'Rider registration failed' });
  }
});

// Shopkeeper Registration
router.post('/register/shopkeeper', authRateLimiter, async (req, res) => {
  try {
    const {
      fullName,
      phone,
      email,
      cnicNumber,
      shopName,
      categoryId,
      shopDescription,
      shopAddress,
      city,
      lat,
      lng,
      shopContactNumber,
      businessRegNumber,
      bankName,
      bankAccountTitle,
      bankAccountNumber,
      password,
      confirmPassword,
      documents,
    } = req.body as {
      fullName?: string;
      phone?: string;
      email?: string;
      cnicNumber?: string;
      shopName?: string;
      categoryId?: number;
      shopDescription?: string;
      shopAddress?: string;
      city?: string;
      lat?: number;
      lng?: number;
      shopContactNumber?: string;
      businessRegNumber?: string;
      bankName?: string;
      bankAccountTitle?: string;
      bankAccountNumber?: string;
      password?: string;
      confirmPassword?: string;
      documents?: Array<{ docType: string; fileName: string; mimeType: string; fileSize: number; storageDataUrl: string }>;
    };

    if (!fullName || !phone || !email || !cnicNumber || !shopName || !categoryId || !shopDescription || !shopAddress || !shopContactNumber || !password) {
      return res.status(400).json({ error: 'All required shopkeeper and business details must be provided' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }
    if (!isValidCnicFormat(cnicNumber)) {
      return res.status(400).json({ error: 'CNIC must follow format XXXXX-XXXXXXX-X' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const dupEmail = await db.select({ id: users.id }).from(users).where(eq(users.email, normalizedEmail));
    if (dupEmail.length > 0) return res.status(409).json({ error: 'Email already registered' });
    const dupPhone = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone.trim()));
    if (dupPhone.length > 0) return res.status(409).json({ error: 'Phone number already registered' });
    const dupCnic = await db.select({ id: users.id }).from(users).where(eq(users.cnicNumber, cnicNumber.trim()));
    if (dupCnic.length > 0) return res.status(409).json({ error: 'CNIC already registered' });

    const [created] = await db
      .insert(users)
      .values({
        uid: `shop-${crypto.randomUUID()}`,
        email: normalizedEmail,
        passwordHash: hashPassword(password),
        fullName: fullName.trim(),
        phone: phone.trim(),
        cnicNumber: cnicNumber.trim(),
        cnicMasked: maskCnic(cnicNumber.trim()),
        role: 'shopkeeper',
        accountStatus: 'pending_verification',
      })
      .returning();

    const slugBase = shopName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    const slug = `${slugBase || 'shop'}-${Date.now().toString(36)}`;
    const logoDoc = documents?.find((d) => d.docType === 'logo');
    const photoDoc = documents?.find((d) => d.docType === 'shop_photo');

    await db.insert(shopProfiles).values({
      ownerId: created.id,
      name: shopName.trim(),
      slug,
      categoryId: Number(categoryId),
      description: shopDescription.trim(),
      address: shopAddress.trim(),
      city: city?.trim() || 'Karachi',
      lat: typeof lat === 'number' ? lat : 24.8615,
      lng: typeof lng === 'number' ? lng : 67.0099,
      contactNumber: shopContactNumber.trim(),
      businessRegNumber: businessRegNumber?.trim() || null,
      logoUrl: logoDoc?.storageDataUrl || '/src/assets/images/shop_urban_grill_1795715717464.jpg',
      bannerUrl: photoDoc?.storageDataUrl || '/src/assets/images/shop_urban_grill_1795715717464.jpg',
      bankName: bankName?.trim() || null,
      bankAccountTitle: bankAccountTitle?.trim() || null,
      bankAccountNumber: bankAccountNumber?.trim() || null,
      approvalStatus: 'pending_verification',
    });

    const [app] = await db
      .insert(verificationApplications)
      .values({
        userId: created.id,
        targetRole: 'shopkeeper',
        status: 'pending_verification',
      })
      .returning();

    if (Array.isArray(documents) && documents.length > 0) {
      const validDocs = documents
        .filter((d) => d.fileName && d.storageDataUrl && d.fileSize <= 5 * 1024 * 1024)
        .map((d) => ({
          applicationId: app.id,
          userId: created.id,
          docType: d.docType,
          fileName: d.fileName,
          mimeType: d.mimeType || 'image/jpeg',
          fileSize: d.fileSize || 1024,
          storageDataUrl: d.storageDataUrl,
        }));
      if (validDocs.length > 0) {
        await db.insert(verificationDocuments).values(validDocs);
      }
    }

    const emailOtp = await issueOtp(created.id, normalizedEmail, 'email');
    const phoneOtp = await issueOtp(created.id, phone.trim(), 'phone');

    emitToRole('admin', 'admin:new_shop_application', {
      userId: created.id,
      shopName: shopName.trim(),
    });

    const token = signAuthToken({
      userId: created.id,
      uid: created.uid,
      email: created.email,
      role: created.role,
    });
    setSessionCookie(res, req, token);

    res.status(201).json({
      token,
      user: sanitizePublicUser(created),
      applicationId: app.id,
      otps: { emailOtp, phoneOtp },
    });
  } catch (error) {
    console.error('Shopkeeper registration error:', error);
    res.status(500).json({ error: 'Shop registration failed' });
  }
});

// Resend OTP
router.post('/otp/send', requireAuth, authRateLimiter, async (req: AuthedRequest, res) => {
  try {
    const { channel } = req.body as { channel?: 'email' | 'phone' };
    const authUser = req.authUser!;
    const target = channel === 'phone' ? authUser.phone : authUser.email;
    const otp = await issueOtp(authUser.id, target, channel === 'phone' ? 'phone' : 'email');
    res.json({ otp });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({ error: 'Failed to issue verification code' });
  }
});

// Verify Email or Phone OTP and enqueue automatic verification pipeline
router.post('/otp/verify', requireAuth, authRateLimiter, async (req: AuthedRequest, res) => {
  try {
    const { channel, code } = req.body as { channel?: 'email' | 'phone'; code?: string };
    if (!channel || !code) {
      return res.status(400).json({ error: 'Verification channel and 6-digit code are required' });
    }
    const authUser = req.authUser!;
    const target = channel === 'phone' ? authUser.phone.toLowerCase() : authUser.email.toLowerCase();

    const [otpRow] = await db
      .select()
      .from(otpVerifications)
      .where(
        and(
          eq(otpVerifications.target, target),
          eq(otpVerifications.channel, channel),
          eq(otpVerifications.consumed, false)
        )
      )
      .orderBy(desc(otpVerifications.id))
      .limit(1);

    if (!otpRow || otpRow.expiresAt < new Date()) {
      return res.status(400).json({ error: 'Verification code is expired or invalid' });
    }
    if (otpRow.attempts >= 5) {
      return res.status(429).json({ error: 'Too many failed OTP attempts. Request a new code.' });
    }

    if (hashOtp(code.trim()) !== otpRow.codeHash) {
      await db
        .update(otpVerifications)
        .set({ attempts: otpRow.attempts + 1 })
        .where(eq(otpVerifications.id, otpRow.id));
      return res.status(400).json({ error: 'Incorrect verification code' });
    }

    await db.update(otpVerifications).set({ consumed: true }).where(eq(otpVerifications.id, otpRow.id));

    await db
      .update(users)
      .set(channel === 'email' ? { emailVerified: true } : { phoneVerified: true })
      .where(eq(users.id, authUser.id));

    const [latestApp] = await db
      .select()
      .from(verificationApplications)
      .where(eq(verificationApplications.userId, authUser.id))
      .orderBy(desc(verificationApplications.id))
      .limit(1);

    if (latestApp) {
      verificationQueue.enqueue(latestApp.id);
    }

    const [updated] = await db.select().from(users).where(eq(users.id, authUser.id));
    res.json({
      verified: true,
      user: sanitizePublicUser(updated),
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ error: 'Failed to verify code' });
  }
});

// Password Reset Request & Confirm
router.post('/password-reset/request', authRateLimiter, async (req, res) => {
  try {
    const { email } = req.body as { email?: string };
    if (!email) return res.status(400).json({ error: 'Email address is required' });
    const normalized = email.trim().toLowerCase();
    const [user] = await db.select().from(users).where(eq(users.email, normalized));
    if (!user) {
      return res.json({ message: 'If an account matches this email, a reset code has been issued.' });
    }
    const otp = await issueOtp(user.id, normalized, 'password_reset');
    res.json({
      message: 'Password reset code generated.',
      otp,
    });
  } catch (error) {
    console.error('Password reset request error:', error);
    res.status(500).json({ error: 'Could not start password reset' });
  }
});

router.post('/password-reset/confirm', authRateLimiter, async (req, res) => {
  try {
    const { email, code, newPassword } = req.body as { email?: string; code?: string; newPassword?: string };
    if (!email || !code || !newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'Valid email, 6-digit code, and new password (min 8 chars) required' });
    }
    const normalized = email.trim().toLowerCase();
    const [otpRow] = await db
      .select()
      .from(otpVerifications)
      .where(
        and(
          eq(otpVerifications.target, normalized),
          eq(otpVerifications.channel, 'password_reset'),
          eq(otpVerifications.consumed, false)
        )
      )
      .orderBy(desc(otpVerifications.id))
      .limit(1);

    if (!otpRow || otpRow.expiresAt < new Date() || hashOtp(code.trim()) !== otpRow.codeHash) {
      return res.status(400).json({ error: 'Invalid or expired reset code' });
    }

    await db.update(otpVerifications).set({ consumed: true }).where(eq(otpVerifications.id, otpRow.id));
    await db.update(users).set({ passwordHash: hashPassword(newPassword), updatedAt: new Date() }).where(eq(users.email, normalized));
    res.json({ message: 'Password updated successfully. You can now sign in.' });
  } catch (error) {
    console.error('Password reset confirm error:', error);
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

// Resubmit rejected verification application
router.post('/verification/resubmit', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const { fullName, phone, cnicNumber, dob, documents } = req.body as {
      fullName?: string;
      phone?: string;
      cnicNumber?: string;
      dob?: string;
      documents?: Array<{ docType: string; fileName: string; mimeType: string; fileSize: number; storageDataUrl: string; expiryDate?: string }>;
    };

    if (cnicNumber && !isValidCnicFormat(cnicNumber)) {
      return res.status(400).json({ error: 'CNIC must match XXXXX-XXXXXXX-X' });
    }

    await db
      .update(users)
      .set({
        ...(fullName ? { fullName: fullName.trim() } : {}),
        ...(phone ? { phone: phone.trim() } : {}),
        ...(dob ? { dob } : {}),
        ...(cnicNumber ? { cnicNumber: cnicNumber.trim(), cnicMasked: maskCnic(cnicNumber.trim()) } : {}),
        accountStatus: 'under_review',
        rejectionReason: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, authUser.id));

    const [app] = await db
      .insert(verificationApplications)
      .values({
        userId: authUser.id,
        targetRole: authUser.role,
        status: 'under_review',
      })
      .returning();

    if (Array.isArray(documents) && documents.length > 0) {
      const validDocs = documents
        .filter((d) => d.fileName && d.storageDataUrl)
        .map((d) => ({
          applicationId: app.id,
          userId: authUser.id,
          docType: d.docType,
          fileName: d.fileName,
          mimeType: d.mimeType || 'image/jpeg',
          fileSize: d.fileSize || 1024,
          storageDataUrl: d.storageDataUrl,
          expiryDate: d.expiryDate || null,
        }));
      if (validDocs.length > 0) {
        await db.insert(verificationDocuments).values(validDocs);
      }
    }

    verificationQueue.enqueue(app.id);
    res.json({ message: 'Application resubmitted for verification', applicationId: app.id });
  } catch (error) {
    console.error('Resubmit error:', error);
    res.status(500).json({ error: 'Failed to resubmit application' });
  }
});

// Privacy & Safety Settings update
router.patch('/account/privacy', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const { shareLiveLocation, marketingEmails, smsAlerts, dataAnalyticsConsent } = req.body as Record<string, boolean>;
    const [updated] = await db
      .update(users)
      .set({
        privacySettings: {
          shareLiveLocation: Boolean(shareLiveLocation),
          marketingEmails: Boolean(marketingEmails),
          smsAlerts: Boolean(smsAlerts),
          dataAnalyticsConsent: Boolean(dataAnalyticsConsent),
        },
        updatedAt: new Date(),
      })
      .where(eq(users.id, authUser.id))
      .returning();

    res.json({ user: sanitizePublicUser(updated) });
  } catch (error) {
    console.error('Privacy update error:', error);
    res.status(500).json({ error: 'Failed to update privacy settings' });
  }
});

// Change Password
router.post('/account/change-password', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const { currentPassword, newPassword } = req.body as { currentPassword?: string; newPassword?: string };
    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters' });
    }
    const [user] = await db.select().from(users).where(eq(users.id, authUser.id));
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (user.passwordHash && (!currentPassword || !verifyPassword(currentPassword, user.passwordHash))) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    await db.update(users).set({ passwordHash: hashPassword(newPassword), updatedAt: new Date() }).where(eq(users.id, user.id));
    await db.insert(auditLogs).values({
      actorId: user.id,
      actorRole: user.role,
      action: 'password_changed',
      targetType: 'user',
      targetId: String(user.id),
      ipAddress: req.ip,
    });
    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Failed to update password' });
  }
});

// Danger Zone: Account Deletion
router.delete('/account', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const { confirmationText, password } = req.body as { confirmationText?: string; password?: string };

    if (confirmationText !== 'DELETE MY ACCOUNT') {
      return res.status(400).json({ error: 'Please type DELETE MY ACCOUNT to confirm permanent deletion.' });
    }

    const [user] = await db.select().from(users).where(eq(users.id, authUser.id));
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (user.passwordHash && (!password || !verifyPassword(password, user.passwordHash))) {
      return res.status(400).json({ error: 'Password confirmation failed' });
    }

    if (user.role === 'admin') {
      const admins = await db.select({ id: users.id }).from(users).where(and(eq(users.role, 'admin'), eq(users.accountStatus, 'approved')));
      if (admins.length <= 1) {
        return res.status(400).json({ error: 'Cannot delete the sole active administrator account.' });
      }
    }

    const activeOrders = await db
      .select({ id: orders.id })
      .from(orders)
      .where(
        and(
          user.role === 'rider' ? eq(orders.riderId, user.id) : eq(orders.customerId, user.id),
          inArray(orders.status, ['placed', 'accepted', 'preparing', 'ready_for_pickup', 'rider_assigned', 'picked_up', 'on_the_way'])
        )
      );
    if (activeOrders.length > 0) {
      return res.status(400).json({
        error: 'You have active orders in progress. Complete or cancel them before deleting your account.',
      });
    }

    await db.transaction(async (tx) => {
      const anonymizedSuffix = `${user.id}-${Date.now()}`;
      await tx
        .update(users)
        .set({
          email: `deleted-${anonymizedSuffix}@deleted.delivoo.local`,
          fullName: 'Deleted User',
          phone: `0000-${user.id}`,
          cnicNumber: null,
          cnicMasked: null,
          passwordHash: null,
          accountStatus: 'deleted',
          deletedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(users.id, user.id));

      if (user.role === 'shopkeeper') {
        await tx
          .update(shopProfiles)
          .set({ isOpen: false, approvalStatus: 'suspended' })
          .where(eq(shopProfiles.ownerId, user.id));
      }
      if (user.role === 'rider') {
        await tx
          .update(riderProfiles)
          .set({ isOnline: false, isAvailable: false })
          .where(eq(riderProfiles.userId, user.id));
      }

      await tx.insert(auditLogs).values({
        actorId: user.id,
        actorRole: user.role,
        action: 'account_deleted_by_user',
        targetType: 'user',
        targetId: String(user.id),
        ipAddress: req.ip,
      });
    });

    clearSessionCookie(res, req);
    res.json({ message: 'Your DELIVOO account has been permanently deleted.' });
  } catch (error) {
    console.error('Delete account error:', error);
    res.status(500).json({ error: 'Failed to delete account' });
  }
});

export default router;
