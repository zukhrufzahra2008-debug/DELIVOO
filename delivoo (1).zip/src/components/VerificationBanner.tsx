import React, { useState } from 'react';
import { ShieldAlert, CheckCircle2, Clock, RefreshCw, Mail, Phone } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const VerificationBanner: React.FC = () => {
  const { user, verificationApplication, apiFetch, refreshSession, pushToast } = useApp();

  const [emailCode, setEmailCode] = useState('');
  const [phoneCode, setPhoneCode] = useState('');
  const [deliveryNotices, setDeliveryNotices] = useState<{ email?: string; phone?: string }>({});
  const [busy, setBusy] = useState(false);

  // Resubmission fields when rejected
  const [resubmitCnic, setResubmitCnic] = useState('');
  const [resubmitPhone, setResubmitPhone] = useState(user?.phone || '');

  if (!user || user.accountStatus === 'approved') return null;

  const sendOtp = async (channel: 'email' | 'phone') => {
    setBusy(true);
    try {
      const resp = await apiFetch<{
        otp: { delivered?: boolean; maskedTarget?: string; notice?: string };
      }>('/api/auth/otp/send', {
        method: 'POST',
        body: JSON.stringify({ channel }),
      });
      const notice =
        resp.otp?.notice ||
        `Verification code sent to ${resp.otp?.maskedTarget || `your ${channel}`}.`;
      setDeliveryNotices((prev) => ({ ...prev, [channel]: notice }));
      pushToast(resp.otp?.delivered ? 'success' : 'info', notice);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to send OTP');
    } finally {
      setBusy(false);
    }
  };

  const verifyOtp = async (channel: 'email' | 'phone', code: string) => {
    setBusy(true);
    try {
      await apiFetch('/api/auth/otp/verify', {
        method: 'POST',
        body: JSON.stringify({ channel, code }),
      });
      await refreshSession();
      pushToast('success', `${channel === 'email' ? 'Email' : 'Phone'} verified!`);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'OTP verification failed');
    } finally {
      setBusy(false);
    }
  };

  const handleResubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await apiFetch('/api/verification/resubmit', {
        method: 'POST',
        body: JSON.stringify({
          phone: resubmitPhone,
          ...(resubmitCnic ? { cnicNumber: resubmitCnic } : {}),
        }),
      });
      await refreshSession();
      pushToast('success', 'Application resubmitted for verification.');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Resubmission failed');
    } finally {
      setBusy(false);
    }
  };

  const statusLabel = user.accountStatus.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  const reviewNotes =
    typeof verificationApplication?.reviewNotes === 'string'
      ? verificationApplication.reviewNotes
      : null;

  return (
    <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-4 sm:p-5 mb-6 space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          {user.accountStatus === 'rejected' ? (
            <ShieldAlert className="w-5 h-5 text-rose-600 mt-0.5 shrink-0" />
          ) : (
            <Clock className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
          )}
          <div>
            <div className="flex flex-wrap items-center gap-2 text-sm font-semibold text-slate-900">
              <span>Verification Status: {statusLabel}</span>
              <span className="text-slate-400">&middot;</span>
              <span className="text-xs font-normal text-slate-600">
                Email {user.emailVerified ? 'Verified' : 'Pending'} &middot; Phone{' '}
                {user.phoneVerified ? 'Verified' : 'Pending'}
              </span>
            </div>
            {user.rejectionReason && (
              <p className="text-xs text-rose-700 font-medium mt-1">
                Rejection reason: {user.rejectionReason}
              </p>
            )}
            {!user.rejectionReason && reviewNotes && (
              <p className="text-xs text-slate-700 mt-1">{reviewNotes}</p>
            )}
          </div>
        </div>
      </div>

      {/* Email & Phone OTP Boxes when pending */}
      {(!user.emailVerified || !user.phoneVerified) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-amber-200/70">
          {!user.emailVerified && (
            <div className="rounded-lg bg-white border border-slate-200 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs font-medium text-slate-800">
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-rose-600" />
                  Email OTP ({user.email})
                </span>
                <button
                  type="button"
                  onClick={() => sendOtp('email')}
                  disabled={busy}
                  className="text-rose-600 hover:underline font-semibold"
                >
                  Send Code
                </button>
              </div>
              {deliveryNotices.email && (
                <p className="text-[11px] text-slate-600">{deliveryNotices.email}</p>
              )}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={emailCode}
                  onChange={(e) => setEmailCode(e.target.value)}
                  placeholder="6-digit Email OTP"
                  className="flex-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={() => verifyOtp('email', emailCode)}
                  disabled={busy || emailCode.length < 6}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-medium disabled:opacity-50"
                >
                  Verify
                </button>
              </div>
            </div>
          )}

          {!user.phoneVerified && (
            <div className="rounded-lg bg-white border border-slate-200 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs font-medium text-slate-800">
                <span className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-rose-600" />
                  Phone OTP ({user.phone})
                </span>
                <button
                  type="button"
                  onClick={() => sendOtp('phone')}
                  disabled={busy}
                  className="text-rose-600 hover:underline font-semibold"
                >
                  Send Code
                </button>
              </div>
              {deliveryNotices.phone && (
                <p className="text-[11px] text-slate-600">{deliveryNotices.phone}</p>
              )}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={phoneCode}
                  onChange={(e) => setPhoneCode(e.target.value)}
                  placeholder="6-digit Phone OTP"
                  className="flex-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={() => verifyOtp('phone', phoneCode)}
                  disabled={busy || phoneCode.length < 6}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-medium disabled:opacity-50"
                >
                  Verify
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {user.emailVerified && user.phoneVerified && user.accountStatus === 'under_review' && (
        <div className="flex items-center gap-2 text-xs text-emerald-700 font-medium">
          <CheckCircle2 className="w-4 h-4" />
          <span>Both Email and Phone OTPs verified. Your application is in the Admin verification queue.</span>
        </div>
      )}

      {/* Resubmit Form if Rejected */}
      {user.accountStatus === 'rejected' && (
        <form
          onSubmit={handleResubmit}
          className="rounded-lg bg-white border border-rose-200 p-4 space-y-3"
        >
          <p className="text-xs font-semibold text-slate-900 flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5 text-rose-600" />
            Correct Information &amp; Resubmit Application
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              value={resubmitPhone}
              onChange={(e) => setResubmitPhone(e.target.value)}
              placeholder="Phone number (+92...)"
              className="rounded-lg border border-slate-200 px-3 py-2 text-xs"
            />
            <input
              type="text"
              value={resubmitCnic}
              onChange={(e) => setResubmitCnic(e.target.value)}
              placeholder="Updated CNIC (XXXXX-XXXXXXX-X)"
              className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-mono"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="px-4 py-2 rounded-lg bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700 disabled:opacity-50"
          >
            {busy ? 'Resubmitting...' : 'Resubmit for Verification'}
          </button>
        </form>
      )}
    </div>
  );
};
