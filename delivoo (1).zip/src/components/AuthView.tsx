import React, { useEffect, useState } from 'react';
import {
  Eye,
  EyeOff,
  ArrowLeft,
  UserPlus,
  Bike,
  Store,
  CheckCircle2,
  Upload,
  ShieldCheck,
  KeyRound,
} from 'lucide-react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import { useApp, type UserProfile } from '../context/AppContext';
import { DelivooLogo } from './DelivooLogo';
import { DeliveryMap } from './DeliveryMap';

interface AuthViewProps {
  initialMode?: 'login' | 'register' | 'admin';
  onBackToMarketplace: () => void;
}

interface OtpDispatchSummary {
  delivered?: boolean;
  channel?: string;
  maskedTarget?: string;
  notice?: string;
}

interface UploadedDoc {
  docType: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  storageDataUrl: string;
  expiryDate?: string;
}

interface CategoryItem {
  id: number;
  name: string;
}

export const AuthView: React.FC<AuthViewProps> = ({
  initialMode = 'login',
  onBackToMarketplace,
}) => {
  const { apiFetch, setSession, pushToast } = useApp();

  const [view, setView] = useState<'login' | 'forgot' | 'register' | 'otp' | 'admin' | 'admin_claim'>(initialMode);
  const [regType, setRegType] = useState<'customer' | 'rider' | 'shopkeeper'>('customer');

  useEffect(() => {
    setView(initialMode);
  }, [initialMode]);

  // Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Admin First-Run Bootstrap State
  const [hasAdmin, setHasAdmin] = useState(true);
  const [hasEnvPasscode, setHasEnvPasscode] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminName, setAdminName] = useState('');
  const [adminPhone, setAdminPhone] = useState('+923000000000');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminEnvPasscode, setAdminEnvPasscode] = useState('');

  // Forgot Password State
  const [resetEmail, setResetEmail] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [resetNewPass, setResetNewPass] = useState('');
  const [resetDeliveryNotice, setResetDeliveryNotice] = useState<string | null>(null);
  const [resetStep, setResetStep] = useState<'request' | 'confirm'>('request');

  // Shared Registration Fields
  const [fullName, setFullName] = useState('');
  const [dob, setDob] = useState('1996-05-15');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [cnicNumber, setCnicNumber] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Rider Specific Fields
  const [residentialAddress, setResidentialAddress] = useState('');
  const [vehicleType, setVehicleType] = useState('motorbike');
  const [vehicleRegistration, setVehicleRegistration] = useState('');
  const [drivingLicenseNumber, setDrivingLicenseNumber] = useState('');
  const [licenseExpiryDate, setLicenseExpiryDate] = useState('2029-12-31');
  const [emergencyContact, setEmergencyContact] = useState('');

  // Shopkeeper Specific Fields
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [shopName, setShopName] = useState('');
  const [categoryId, setCategoryId] = useState<number>(1);
  const [shopDescription, setShopDescription] = useState('');
  const [shopAddress, setShopAddress] = useState('');
  const [shopCity, setShopCity] = useState('Karachi');
  const [shopLat, setShopLat] = useState(24.8615);
  const [shopLng, setShopLng] = useState(67.0099);
  const [shopContactNumber, setShopContactNumber] = useState('');
  const [businessRegNumber, setBusinessRegNumber] = useState('');
  const [bankName, setBankName] = useState('');
  const [bankAccountTitle, setBankAccountTitle] = useState('');
  const [bankAccountNumber, setBankAccountNumber] = useState('');

  // Uploaded Docs
  const [docs, setDocs] = useState<Record<string, UploadedDoc>>({});

  // Post-registration OTP Step
  const [otpDeliveryInfo, setOtpDeliveryInfo] = useState<{
    emailNotice?: string;
    phoneNotice?: string;
  }>({});
  const [emailOtpInput, setEmailOtpInput] = useState('');
  const [phoneOtpInput, setPhoneOtpInput] = useState('');
  const [emailVerifiedNow, setEmailVerifiedNow] = useState(false);
  const [phoneVerifiedNow, setPhoneVerifiedNow] = useState(false);

  useEffect(() => {
    void apiFetch<{ hasAdmin: boolean; hasEnvPasscode: boolean }>('/api/auth/admin-bootstrap-status')
      .then((res) => {
        setHasAdmin(res.hasAdmin);
        setHasEnvPasscode(res.hasEnvPasscode);
      })
      .catch(() => {});

    void apiFetch<{ categories: CategoryItem[] }>('/api/marketplace/home')
      .then((res) => {
        if (res.categories?.length) {
          setCategories(res.categories);
          setCategoryId(res.categories[0].id);
        }
      })
      .catch(() => {});
  }, [apiFetch]);

  const handleFileUpload = (docType: string, file: File | null) => {
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      setErrorMsg('Document file size must be under 4 MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setDocs((prev) => ({
          ...prev,
          [docType]: {
            docType,
            fileName: file.name,
            mimeType: file.type || 'image/jpeg',
            fileSize: file.size,
            storageDataUrl: reader.result as string,
          },
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLogin = async (e: React.FormEvent, requireAdmin = false) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);
    try {
      const resp = await apiFetch<{ token: string; user: UserProfile }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });
      if (requireAdmin && resp.user.role !== 'admin') {
        await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
        setErrorMsg('Admin Portal is restricted to registered Main Admin and Sub-Admin accounts.');
        return;
      }
      await setSession(resp.token, resp.user);
      pushToast('success', `Welcome back, ${resp.user.fullName}`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async (requireAdmin = false) => {
    setErrorMsg(null);
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      const idToken = await result.user.getIdToken();
      const resp = await apiFetch<{ token: string; user: UserProfile }>('/api/auth/firebase-session', {
        method: 'POST',
        body: JSON.stringify({ idToken }),
      });
      if (requireAdmin && resp.user.role !== 'admin') {
        await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
        setErrorMsg('Admin Portal is restricted to registered Main Admin and Sub-Admin accounts.');
        return;
      }
      await setSession(resp.token, resp.user);
      pushToast('success', `Signed in as ${resp.user.fullName}`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google Sign-In failed');
    } finally {
      setLoading(false);
    }
  };

  const handleAdminBootstrap = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);
    try {
      const resp = await apiFetch<{ token: string; user: UserProfile }>('/api/auth/admin-bootstrap', {
        method: 'POST',
        body: JSON.stringify({
          email: adminEmail,
          fullName: adminName,
          phone: adminPhone,
          password: adminPassword,
          envPasscode: adminEnvPasscode,
        }),
      });
      await setSession(resp.token, resp.user);
      pushToast('success', 'Administrator account created and active.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Admin setup failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);
    try {
      const docsArray = Object.values(docs);
      let endpoint = '/api/auth/register/customer';
      let payload: Record<string, unknown> = {
        fullName,
        dob,
        phone,
        email,
        cnicNumber,
        password,
        confirmPassword,
      };

      if (regType === 'rider') {
        endpoint = '/api/auth/register/rider';
        payload = {
          ...payload,
          residentialAddress,
          vehicleType,
          vehicleRegistration,
          drivingLicenseNumber,
          licenseExpiryDate,
          emergencyContact,
          documents: docsArray,
        };
      } else if (regType === 'shopkeeper') {
        endpoint = '/api/auth/register/shopkeeper';
        payload = {
          fullName,
          phone,
          email,
          cnicNumber,
          shopName,
          categoryId,
          shopDescription,
          shopAddress,
          city: shopCity,
          lat: shopLat,
          lng: shopLng,
          shopContactNumber,
          businessRegNumber,
          bankName,
          bankAccountTitle,
          bankAccountNumber,
          password,
          confirmPassword,
          documents: docsArray,
        };
      }

      const resp = await apiFetch<{
        token: string;
        user: UserProfile;
        otps: {
          emailOtp: OtpDispatchSummary;
          phoneOtp: OtpDispatchSummary;
        };
      }>(endpoint, {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      await setSession(resp.token, resp.user);
      setOtpDeliveryInfo({
        emailNotice:
          resp.otps?.emailOtp?.notice ||
          `Verification code dispatched to ${resp.otps?.emailOtp?.maskedTarget || email}.`,
        phoneNotice:
          resp.otps?.phoneOtp?.notice ||
          `Verification code dispatched to ${resp.otps?.phoneOtp?.maskedTarget || phone}.`,
      });
      setView('otp');
      pushToast('success', 'Account created! Check your email and phone for verification OTPs.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const resendRegOtp = async (channel: 'email' | 'phone') => {
    setErrorMsg(null);
    setLoading(true);
    try {
      const resp = await apiFetch<{ otp: OtpDispatchSummary }>('/api/auth/otp/send', {
        method: 'POST',
        body: JSON.stringify({ channel }),
      });
      setOtpDeliveryInfo((prev) => ({
        ...prev,
        [channel === 'email' ? 'emailNotice' : 'phoneNotice']:
          resp.otp?.notice || `OTP sent to your registered ${channel}.`,
      }));
      pushToast(resp.otp?.delivered ? 'success' : 'info', resp.otp?.notice || `Verification code dispatched to ${channel}.`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to resend code');
    } finally {
      setLoading(false);
    }
  };

  const verifyRegOtp = async (channel: 'email' | 'phone', code: string) => {
    setErrorMsg(null);
    setLoading(true);
    try {
      await apiFetch('/api/auth/otp/verify', {
        method: 'POST',
        body: JSON.stringify({ channel, code }),
      });
      if (channel === 'email') setEmailVerifiedNow(true);
      else setPhoneVerifiedNow(true);
      pushToast('success', `${channel === 'email' ? 'Email' : 'Phone'} verified!`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Invalid code');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] flex flex-col justify-between py-8 px-4">
      <div className="max-w-3xl w-full mx-auto">
        <div className="flex items-center justify-between mb-8">
          <button
            type="button"
            onClick={onBackToMarketplace}
            className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 min-h-[44px]"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Marketplace</span>
          </button>
          <DelivooLogo />
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 shadow-sm">
          {/* Mode Switcher Tabs: Sign In / Create Account / Admin Portal */}
          {(view === 'login' || view === 'register' || view === 'admin') && (
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl mb-6">
              <button
                type="button"
                onClick={() => {
                  setView('login');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
                  view === 'login'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setView('register');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
                  view === 'register'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Create Account
              </button>
              <button
                type="button"
                onClick={() => {
                  setView('admin');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors inline-flex items-center justify-center gap-1.5 ${
                  view === 'admin'
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                <span>Admin Portal</span>
              </button>
            </div>
          )}

          {errorMsg && (
            <div className="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
              {errorMsg}
            </div>
          )}

          {/* UNIFIED LOGIN */}
          {view === 'login' && (
            <div className="max-w-md mx-auto space-y-5">
              <div>
                <h1 className="font-display text-2xl font-bold text-slate-900">Sign in to DELIVOO</h1>
                <p className="text-sm text-slate-500 mt-1">
                  Your account role is detected automatically upon sign-in.
                </p>
              </div>

              <form onSubmit={(e) => void handleLogin(e, false)} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-rose-600"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setView('forgot');
                        setErrorMsg(null);
                      }}
                      className="text-xs font-medium text-rose-600 hover:underline"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 pr-11 text-sm focus:outline-none focus:border-rose-600"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((s) => !s)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-slate-700"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold transition-colors disabled:opacity-50 min-h-[44px]"
                >
                  {loading ? 'Signing in...' : 'Login'}
                </button>
              </form>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-200" />
                <span className="shrink mx-3 text-xs text-slate-400">or</span>
                <div className="flex-grow border-t border-slate-200" />
              </div>

              <button
                type="button"
                onClick={() => void handleGoogleSignIn(false)}
                disabled={loading}
                className="w-full py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-sm font-medium transition-colors flex items-center justify-center gap-2 min-h-[44px]"
              >
                <span>Continue with Google</span>
              </button>

              {!hasAdmin && (
                <div className="pt-3 border-t border-slate-100 text-center">
                  <button
                    type="button"
                    onClick={() => setView('admin_claim')}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-rose-600"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>First-Run Main Administrator Setup</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* DEDICATED ADMIN & SUB-ADMIN PORTAL */}
          {view === 'admin' && (
            <div className="max-w-md mx-auto space-y-5">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-1">
                <div className="flex items-center gap-2 text-slate-900">
                  <ShieldCheck className="w-5 h-5 text-rose-600 shrink-0" />
                  <h1 className="font-display text-lg font-bold">Admin &amp; Sub-Admin Portal</h1>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Restricted access for the platform Main Admin and up to 3 authorized Sub-Admins created inside the Admin Console.
                </p>
              </div>

              <form onSubmit={(e) => void handleLogin(e, true)} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Administrator Email
                  </label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="admin@company.com"
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-slate-900"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setView('forgot');
                        setErrorMsg(null);
                      }}
                      className="text-xs font-medium text-rose-600 hover:underline"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Enter administrator password"
                      className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 pr-11 text-sm focus:outline-none focus:border-slate-900"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((s) => !s)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-slate-700"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors disabled:opacity-50 min-h-[44px]"
                >
                  {loading ? 'Verifying Credentials...' : 'Sign In to Admin Console'}
                </button>
              </form>

              <button
                type="button"
                onClick={() => void handleGoogleSignIn(true)}
                disabled={loading}
                className="w-full py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-sm font-medium transition-colors flex items-center justify-center gap-2 min-h-[44px]"
              >
                <span>Continue with Authorized Google Account</span>
              </button>

              {!hasAdmin && (
                <div className="pt-3 border-t border-slate-100 text-center">
                  <button
                    type="button"
                    onClick={() => setView('admin_claim')}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-600 hover:underline"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>No Main Admin exists yet — Claim Main Admin Account</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* FIRST-RUN ADMIN SETUP (Locked permanently once claimed) */}
          {view === 'admin_claim' && !hasAdmin && (
            <form onSubmit={handleAdminBootstrap} className="max-w-md mx-auto space-y-4">
              <div className="flex items-center gap-2 text-slate-900">
                <ShieldCheck className="w-5 h-5 text-rose-600" />
                <h2 className="font-display text-xl font-bold">Initial Administrator Setup</h2>
              </div>
              <p className="text-xs text-slate-500">
                Claim the platform administrator account. This one-time setup locks automatically after completion.
              </p>
              <input
                type="text"
                required
                value={adminName}
                onChange={(e) => setAdminName(e.target.value)}
                placeholder="Administrator Full Name"
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
              />
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="Admin Email Address"
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
              />
              <input
                type="text"
                required
                value={adminPhone}
                onChange={(e) => setAdminPhone(e.target.value)}
                placeholder="Phone (+92300...)"
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
              />
              <input
                type="password"
                required
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Create Admin Password (min 8 chars)"
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
              />
              {hasEnvPasscode && (
                <input
                  type="password"
                  required
                  value={adminEnvPasscode}
                  onChange={(e) => setAdminEnvPasscode(e.target.value)}
                  placeholder="Configured ADMIN_INITIAL_PASSWORD"
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
                />
              )}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setView('login')}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800"
                >
                  {loading ? 'Creating...' : 'Claim Admin Account'}
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD */}
          {view === 'forgot' && (
            <div className="max-w-md mx-auto space-y-4">
              <h2 className="font-display text-xl font-bold text-slate-900">Reset Password</h2>
              {resetStep === 'request' ? (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    setLoading(true);
                    setErrorMsg(null);
                    try {
                      const resp = await apiFetch<{ message?: string; otp?: OtpDispatchSummary }>(
                        '/api/auth/password-reset/request',
                        { method: 'POST', body: JSON.stringify({ email: resetEmail }) }
                      );
                      setResetDeliveryNotice(
                        resp.otp?.notice ||
                          resp.message ||
                          'If your email is registered, a 6-digit password reset code has been sent to your email address.'
                      );
                      setResetStep('confirm');
                    } catch (err) {
                      setErrorMsg(err instanceof Error ? err.message : 'Request failed');
                    } finally {
                      setLoading(false);
                    }
                  }}
                  className="space-y-4"
                >
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="Enter registered email address"
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setView('login')}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white text-sm font-semibold"
                    >
                      Send Reset Code
                    </button>
                  </div>
                </form>
              ) : (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    setLoading(true);
                    setErrorMsg(null);
                    try {
                      await apiFetch('/api/auth/password-reset/confirm', {
                        method: 'POST',
                        body: JSON.stringify({
                          email: resetEmail,
                          code: resetCode,
                          newPassword: resetNewPass,
                        }),
                      });
                      pushToast('success', 'Password reset! Please sign in.');
                      setView('login');
                    } catch (err) {
                      setErrorMsg(err instanceof Error ? err.message : 'Reset failed');
                    } finally {
                      setLoading(false);
                    }
                  }}
                  className="space-y-4"
                >
                  {resetDeliveryNotice && (
                    <div className="rounded-lg bg-slate-50 border border-slate-200 px-3 py-2 text-xs text-slate-700">
                      {resetDeliveryNotice}
                    </div>
                  )}
                  <input
                    type="text"
                    required
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value)}
                    placeholder="6-digit Reset Code from your Email"
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono"
                  />
                  <input
                    type="password"
                    required
                    value={resetNewPass}
                    onChange={(e) => setResetNewPass(e.target.value)}
                    placeholder="New Password (min 8 characters)"
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
                  />
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-2.5 rounded-xl bg-rose-600 text-white text-sm font-semibold"
                  >
                    Confirm Password Reset
                  </button>
                </form>
              )}
            </div>
          )}

          {/* PUBLIC REGISTRATION (3 Options: Customer, Rider, Shopkeeper — NO Admin!) */}
          {view === 'register' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'customer' as const, label: 'Create Customer Account', icon: UserPlus },
                  { id: 'rider' as const, label: 'Register as Rider', icon: Bike },
                  { id: 'shopkeeper' as const, label: 'Register Your Shop', icon: Store },
                ].map((opt) => {
                  const Icon = opt.icon;
                  const active = regType === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setRegType(opt.id)}
                      className={`flex items-center justify-center gap-2 px-3 py-3 rounded-xl border text-xs sm:text-sm font-semibold transition-colors min-h-[44px] ${
                        active
                          ? 'border-rose-600 bg-rose-50 text-rose-700'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{opt.label}</span>
                    </button>
                  );
                })}
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {regType === 'shopkeeper' ? "Owner's Full Name *" : 'Full Name *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Zainab Raza"
                      className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {regType === 'shopkeeper' ? "Owner's Phone Number *" : 'Phone Number *'}
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+923001234567"
                      className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      CNIC Number (XXXXX-XXXXXXX-X) *
                    </label>
                    <input
                      type="text"
                      required
                      value={cnicNumber}
                      onChange={(e) => setCnicNumber(e.target.value)}
                      placeholder="42101-1234567-1"
                      className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                    />
                  </div>
                  {regType !== 'shopkeeper' && (
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Date of Birth (18+ Required) *
                      </label>
                      <input
                        type="date"
                        required
                        value={dob}
                        onChange={(e) => setDob(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                      />
                    </div>
                  )}
                </div>

                {/* Rider Fields */}
                {regType === 'rider' && (
                  <div className="pt-4 border-t border-slate-100 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">Rider Vehicle &amp; Document Details</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <input
                        type="text"
                        required
                        value={residentialAddress}
                        onChange={(e) => setResidentialAddress(e.target.value)}
                        placeholder="Residential Address *"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm sm:col-span-2"
                      />
                      <select
                        value={vehicleType}
                        onChange={(e) => setVehicleType(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white"
                      >
                        <option value="motorbike">Motorbike</option>
                        <option value="bicycle">Bicycle</option>
                        <option value="scooter">Scooter</option>
                        <option value="car">Car</option>
                      </select>
                      <input
                        type="text"
                        value={vehicleRegistration}
                        onChange={(e) => setVehicleRegistration(e.target.value)}
                        placeholder="Vehicle Registration (e.g. KHI-4210)"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                      />
                      <input
                        type="text"
                        value={drivingLicenseNumber}
                        onChange={(e) => setDrivingLicenseNumber(e.target.value)}
                        placeholder="Driving License Number"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                      />
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">License Expiry Date</label>
                        <input
                          type="date"
                          value={licenseExpiryDate}
                          onChange={(e) => setLicenseExpiryDate(e.target.value)}
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                        />
                      </div>
                      <input
                        type="text"
                        required
                        value={emergencyContact}
                        onChange={(e) => setEmergencyContact(e.target.value)}
                        placeholder="Emergency Contact Number *"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono sm:col-span-2"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        { key: 'profile_photo', label: 'Profile Photograph *' },
                        { key: 'cnic_front', label: 'CNIC Front Image *' },
                        { key: 'cnic_back', label: 'CNIC Back Image *' },
                        { key: 'driving_license', label: 'Driving License Image' },
                      ].map((docItem) => (
                        <label
                          key={docItem.key}
                          className="flex items-center justify-between gap-2 rounded-xl border border-dashed border-slate-300 px-3 py-2.5 cursor-pointer hover:border-rose-400"
                        >
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-800">{docItem.label}</p>
                            <p className="text-[11px] text-slate-500 truncate">
                              {docs[docItem.key]?.fileName || 'Upload image (max 4 MB)'}
                            </p>
                          </div>
                          <Upload className="w-4 h-4 text-slate-400 shrink-0" />
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handleFileUpload(docItem.key, e.target.files?.[0] || null)}
                          />
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {/* Shopkeeper Fields */}
                {regType === 'shopkeeper' && (
                  <div className="pt-4 border-t border-slate-100 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">Shop &amp; Settlement Details</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <input
                        type="text"
                        required
                        value={shopName}
                        onChange={(e) => setShopName(e.target.value)}
                        placeholder="Shop / Business Name *"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                      />
                      <select
                        value={categoryId}
                        onChange={(e) => setCategoryId(Number(e.target.value))}
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white"
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                      <textarea
                        required
                        rows={2}
                        value={shopDescription}
                        onChange={(e) => setShopDescription(e.target.value)}
                        placeholder="Shop description & specialty *"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm sm:col-span-2"
                      />
                      <input
                        type="text"
                        required
                        value={shopAddress}
                        onChange={(e) => setShopAddress(e.target.value)}
                        placeholder="Complete Shop Street Address *"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                      />
                      <input
                        type="text"
                        required
                        value={shopContactNumber}
                        onChange={(e) => setShopContactNumber(e.target.value)}
                        placeholder="Shop Contact Number *"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                      />
                      <input
                        type="text"
                        value={businessRegNumber}
                        onChange={(e) => setBusinessRegNumber(e.target.value)}
                        placeholder="Business Reg / NTN (optional)"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                      />
                      <input
                        type="text"
                        value={shopCity}
                        onChange={(e) => setShopCity(e.target.value)}
                        placeholder="City"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                      />
                      <input
                        type="text"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder="Bank Name (for settlements)"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                      />
                      <input
                        type="text"
                        value={bankAccountNumber}
                        onChange={(e) => setBankAccountNumber(e.target.value)}
                        placeholder="IBAN / Account Number"
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <p className="text-xs font-semibold text-slate-700">
                        Pin Shop Location on Map ({shopLat.toFixed(4)}, {shopLng.toFixed(4)})
                      </p>
                      <DeliveryMap
                        center={[shopLat, shopLng]}
                        markers={[{ lat: shopLat, lng: shopLng, label: shopName || 'Your Shop', kind: 'shop' }]}
                        interactivePick
                        onPickLocation={(lat, lng) => {
                          setShopLat(lat);
                          setShopLng(lng);
                        }}
                        heightClass="h-48"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        { key: 'logo', label: 'Shop Logo *' },
                        { key: 'shop_photo', label: 'Shop Photograph *' },
                        { key: 'cnic_front', label: 'Owner CNIC Front *' },
                        { key: 'business_reg', label: 'Business Document' },
                      ].map((docItem) => (
                        <label
                          key={docItem.key}
                          className="flex items-center justify-between gap-2 rounded-xl border border-dashed border-slate-300 px-3 py-2.5 cursor-pointer hover:border-rose-400"
                        >
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-800">{docItem.label}</p>
                            <p className="text-[11px] text-slate-500 truncate">
                              {docs[docItem.key]?.fileName || 'Upload file (max 4 MB)'}
                            </p>
                          </div>
                          <Upload className="w-4 h-4 text-slate-400 shrink-0" />
                          <input
                            type="file"
                            accept="image/*,.pdf"
                            className="hidden"
                            onChange={(e) => handleFileUpload(docItem.key, e.target.files?.[0] || null)}
                          />
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Password *</label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Min 8 characters"
                      className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Confirm Password *
                    </label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Re-enter password"
                      className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold transition-colors disabled:opacity-50 min-h-[44px]"
                >
                  {loading
                    ? 'Submitting Registration...'
                    : regType === 'customer'
                    ? 'Create Customer Account'
                    : regType === 'rider'
                    ? 'Submit Rider Application'
                    : 'Register Your Shop'}
                </button>
              </form>
            </div>
          )}

          {/* POST-REGISTRATION OTP VERIFICATION */}
          {view === 'otp' && (
            <div className="max-w-md mx-auto space-y-5">
              <div>
                <h2 className="font-display text-xl font-bold text-slate-900">Verify Email &amp; Phone</h2>
                <p className="text-xs text-slate-500 mt-1">
                  Enter the 6-digit codes sent directly to your registered email inbox and mobile number.
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 p-4 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
                  <span>Email Verification ({email})</span>
                  {emailVerifiedNow ? (
                    <span className="text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Verified
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void resendRegOtp('email')}
                      disabled={loading}
                      className="text-rose-600 hover:underline font-semibold"
                    >
                      Resend Code
                    </button>
                  )}
                </div>
                {otpDeliveryInfo.emailNotice && !emailVerifiedNow && (
                  <p className="text-xs text-slate-600">{otpDeliveryInfo.emailNotice}</p>
                )}
                {!emailVerifiedNow && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={emailOtpInput}
                      onChange={(e) => setEmailOtpInput(e.target.value)}
                      placeholder="6-digit Email OTP"
                      className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => verifyRegOtp('email', emailOtpInput)}
                      disabled={loading}
                      className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold"
                    >
                      Verify
                    </button>
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-slate-200 p-4 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
                  <span>Phone Verification ({phone})</span>
                  {phoneVerifiedNow ? (
                    <span className="text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Verified
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void resendRegOtp('phone')}
                      disabled={loading}
                      className="text-rose-600 hover:underline font-semibold"
                    >
                      Resend Code
                    </button>
                  )}
                </div>
                {otpDeliveryInfo.phoneNotice && !phoneVerifiedNow && (
                  <p className="text-xs text-slate-600">{otpDeliveryInfo.phoneNotice}</p>
                )}
                {!phoneVerifiedNow && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={phoneOtpInput}
                      onChange={(e) => setPhoneOtpInput(e.target.value)}
                      placeholder="6-digit Phone OTP"
                      className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => verifyRegOtp('phone', phoneOtpInput)}
                      disabled={loading}
                      className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold"
                    >
                      Verify
                    </button>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={onBackToMarketplace}
                className="w-full py-3 rounded-xl bg-rose-600 text-white text-sm font-semibold hover:bg-rose-700"
              >
                Continue to Dashboard
              </button>
            </div>
          )}
        </div>
      </div>

      <footer className="text-center text-xs text-slate-400 mt-8">
        DELIVOO Marketplace &middot; Encrypted Sessions &amp; CNIC Data Protection
      </footer>
    </div>
  );
};
