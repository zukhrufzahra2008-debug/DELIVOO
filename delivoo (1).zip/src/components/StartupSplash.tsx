import React, { useEffect, useState } from 'react';

interface StartupSplashProps {
  onComplete: () => void;
}

const LETTERS = ['D', 'E', 'L', 'I', 'V', 'O', 'O'];

export const StartupSplash: React.FC<StartupSplashProps> = ({ onComplete }) => {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    try {
      if (window.sessionStorage.getItem('delivoo_splash_seen') === '1') {
        onComplete();
        return;
      }
      window.sessionStorage.setItem('delivoo_splash_seen', '1');
    } catch {
      // Ignore storage restrictions
    }

    const exitTimer = setTimeout(() => setExiting(true), 850);
    const doneTimer = setTimeout(() => onComplete(), 1150);
    return () => {
      clearTimeout(exitTimer);
      clearTimeout(doneTimer);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#FAFAFA] transition-opacity duration-400 ${
        exiting ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      aria-label="Loading DELIVOO"
    >
      <div className="flex flex-col items-center px-6">
        {/* Calligraphic SVG emblem stroke-drawing */}
        <svg
          width="76"
          height="76"
          viewBox="0 0 80 80"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="mb-6"
        >
          <rect
            x="6"
            y="6"
            width="68"
            height="68"
            rx="20"
            stroke="#E11D48"
            strokeWidth="3.5"
            className="animate-delivoo-stroke"
          />
          <path
            d="M24 26H41C50.5 26 56 32 56 40C56 48 50.5 54 41 54H24V26Z"
            stroke="#0F172A"
            strokeWidth="3.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="animate-delivoo-stroke"
          />
          <path
            d="M32 40H46M46 40L40.5 34.5M46 40L40.5 45.5"
            stroke="#E11D48"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="animate-delivoo-stroke"
          />
        </svg>

        {/* Kinetic letter-by-letter DELIVOO writing reveal */}
        <div className="flex items-baseline gap-1 sm:gap-1.5 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900">
          {LETTERS.map((ch, idx) => (
            <span
              key={idx}
              style={{ animationDelay: `${0.18 + idx * 0.08}s` }}
              className={`animate-delivoo-letter inline-block ${
                idx >= 5 ? 'text-rose-600' : 'text-slate-900'
              }`}
            >
              {ch}
            </span>
          ))}
        </div>

        {/* Expressive stroke sweep line */}
        <div className="mt-3 h-1 w-44 rounded-full bg-slate-200 overflow-hidden">
          <div className="h-full w-full bg-rose-600 animate-delivoo-sweep rounded-full" />
        </div>

        <p className="mt-4 text-xs sm:text-sm font-medium tracking-wide text-slate-500">
          Local Commerce &middot; Live Delivery
        </p>

        <button
          type="button"
          onClick={onComplete}
          className="mt-8 text-xs font-medium text-slate-400 hover:text-slate-700 transition-colors px-3 py-1.5 min-h-[40px]"
        >
          Skip intro
        </button>
      </div>
    </div>
  );
};
