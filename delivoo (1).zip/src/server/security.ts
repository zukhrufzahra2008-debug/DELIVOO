import crypto from 'node:crypto';
import net from 'node:net';
import jwt from 'jsonwebtoken';
import type { Request, Response, NextFunction } from 'express';

const EPHEMERAL_JWT_SECRET = crypto.randomBytes(32).toString('hex');

function getJwtSecret(): string {
  return process.env.JWT_SECRET && process.env.JWT_SECRET.trim().length >= 16
    ? process.env.JWT_SECRET.trim()
    : EPHEMERAL_JWT_SECRET;
}

export interface JwtPayload {
  userId: number;
  uid: string;
  email: string;
  role: string;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string | null | undefined): boolean {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, expectedHex] = storedHash.split(':');
  if (!salt || !expectedHex) return false;
  try {
    const derived = crypto.scryptSync(password, salt, 64);
    const expected = Buffer.from(expectedHex, 'hex');
    if (derived.length !== expected.length) return false;
    return crypto.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

export function signAuthToken(payload: JwtPayload): string {
  return jwt.sign(payload, getJwtSecret(), { expiresIn: '24h' });
}

export function verifyAuthToken(token: string): JwtPayload | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret());
    if (typeof decoded === 'object' && decoded !== null && 'userId' in decoded) {
      return decoded as JwtPayload;
    }
    return null;
  } catch {
    return null;
  }
}

export function hashOtp(code: string): string {
  return crypto.createHash('sha256').update(code).digest('hex');
}

export function generateSixDigitOtp(): string {
  return String(crypto.randomInt(100000, 999999));
}

export function isValidCnicFormat(cnic: string): boolean {
  return /^\d{5}-\d{7}-\d{1}$/.test(cnic.trim());
}

export function maskCnic(cnic: string | null | undefined): string | null {
  if (!cnic) return null;
  const trimmed = cnic.trim();
  if (trimmed.length < 4) return '*****';
  const lastChar = trimmed.slice(-1);
  return `*****-*******-${lastChar}`;
}

export function calculateAgeFromDob(dob: string | null | undefined): number | null {
  if (!dob) return null;
  const parsed = new Date(dob);
  if (Number.isNaN(parsed.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - parsed.getFullYear();
  const m = today.getMonth() - parsed.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < parsed.getDate())) {
    age--;
  }
  return age;
}

export function sanitizePublicUser<T extends Record<string, unknown>>(
  user: T,
  includeMaskedOnly = true
): Omit<T, 'passwordHash' | 'cnicNumber'> & { cnicNumber?: string | null } {
  const clone = { ...user };
  delete clone.passwordHash;
  if (includeMaskedOnly) {
    delete clone.cnicNumber;
  }
  return clone as Omit<T, 'passwordHash' | 'cnicNumber'> & { cnicNumber?: string | null };
}

export function isSafeExternalHttpUrl(rawUrl: string): { safe: boolean; url?: URL; reason?: string } {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return { safe: false, reason: 'Only HTTP/HTTPS URLs are supported' };
    }
    const hostname = parsed.hostname.toLowerCase();
    if (
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '0.0.0.0' ||
      hostname === '::1' ||
      hostname.endsWith('.local') ||
      hostname.endsWith('.internal') ||
      hostname === '169.254.169.254' ||
      hostname === 'metadata.google.internal'
    ) {
      return { safe: false, reason: 'Private or local network hosts are blocked' };
    }
    if (net.isIP(hostname)) {
      const parts = hostname.split('.').map(Number);
      if (
        parts[0] === 10 ||
        parts[0] === 127 ||
        (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
        (parts[0] === 192 && parts[1] === 168) ||
        (parts[0] === 169 && parts[1] === 254)
      ) {
        return { safe: false, reason: 'Private IP ranges are blocked' };
      }
    }
    return { safe: true, url: parsed };
  } catch {
    return { safe: false, reason: 'Invalid URL format' };
  }
}

export function createRateLimiter(maxRequests: number, windowMs: number) {
  const buckets = new Map<string, { count: number; resetAt: number }>();

  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${req.ip || 'unknown'}:${req.path}`;
    const now = Date.now();
    const existing = buckets.get(key);

    if (!existing || existing.resetAt <= now) {
      buckets.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }

    if (existing.count >= maxRequests) {
      return res.status(429).json({
        error: 'Too many requests. Please wait a moment and try again.',
      });
    }

    existing.count += 1;
    return next();
  };
}
