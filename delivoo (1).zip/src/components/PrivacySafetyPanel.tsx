import React, { useState } from 'react';
import { ShieldCheck, Lock, AlertTriangle, Trash2, PhoneCall, KeyRound, EyeOff } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PrivacySafetyPanel: React.FC = () => {
  const { user, apiFetch, refreshSession, logout, pushToast } = useApp();

  const [shareLiveLocation, setShareLiveLocation] = useState(
    user?.privacySettings?.shareLiveLocation ?? true
  );
  const [smsAlerts, setSmsAlerts] = useState(user?.privacySettings?.smsAlerts ?? true);
  const [marketingEmails, setMarketingEmails] = useState(
    user?.privacySettings?.marketingEmails ?? false
  );
  const [dataAnalyticsConsent, setDataAnalyticsConsent] = useState(
    user?.privacySettings?.dataAnalyticsConsent ?? true
  );
  const [savingPrivacy, setSavingPrivacy] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingPwd, setSavingPwd] = useState(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deletePassword, setDeletePassword] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  if (!user) return null;

  const handleSavePrivacy = async () => {
    setSavingPrivacy(true);
    try {
      await apiFetch('/api/account/privacy', {
        method: 'PATCH',
        body: JSON.stringify({
          shareLiveLocation,
          smsAlerts,
          marketingEmails,
          dataAnalyticsConsent,
        }),
      });
      await refreshSession();
      pushToast('success', 'Privacy preferences updated.');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to update privacy');
    } finally {
      setSavingPrivacy(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      pushToast('error', 'New password must be at least 8 characters');
      return;
    }
    setSavingPwd(true);
    try {
      await apiFetch('/api/account/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setCurrentPassword('');
      setNewPassword('');
      pushToast('success', 'Password changed successfully.');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Password change failed');
    } finally {
      setSavingPwd(false);
    }
  };

  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeleteError(null);
    setDeleting(true);
    try {
      await apiFetch('/api/account', {
        method: 'DELETE',
        body: JSON.stringify({
          confirmationText: deleteConfirmText,
          password: deletePassword,
        }),
      });
      setShowDeleteModal(false);
      pushToast('info', 'Account deleted permanently.');
      logout();
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete account');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="font-display text-2xl font-bold text-slate-900">Privacy, Safety &amp; Account</h2>
        <p className="text-sm text-slate-500 mt-1">
          Manage your data permissions, identity masking, account security, and permanent deletion options.
        </p>
      </div>

      {/* Identity & Data Protection Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-2">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
            <EyeOff className="w-4 h-4 text-emerald-600" />
            <span>CNIC &amp; Identity Masking</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Your CNIC is stored protected on the server and masked in standard views:{' '}
            <span className="font-mono font-semibold text-slate-900">
              {user.cnicMasked || 'Not provided'}
            </span>
            . Only authorized compliance reviews generate an audited access event.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-2">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
            <PhoneCall className="w-4 h-4 text-rose-600" />
            <span>Safety &amp; Emergency Support</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            DELIVOO never exposes your exact live location to unauthorized accounts. Payment cards and CVVs are never stored on our servers. 24/7 Trust &amp; Safety hotline:{' '}
            <span className="font-mono font-semibold text-slate-900">+92-21-111-DELIVOO</span>.
          </p>
        </div>
      </div>

      {/* Privacy Preferences */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-slate-800" />
            <div>
              <h3 className="text-base font-semibold text-slate-900">Privacy Preferences</h3>
              <p className="text-xs text-slate-500">Control location sharing and alert channels</p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleSavePrivacy}
            disabled={savingPrivacy}
            className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 disabled:opacity-50 min-h-[40px]"
          >
            {savingPrivacy ? 'Saving...' : 'Save Preferences'}
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {[
            {
              label: 'Live Location Sharing During Active Deliveries',
              desc: 'Allows sharing GPS coordinates with your assigned customer/rider strictly while an order is active.',
              checked: shareLiveLocation,
              onChange: setShareLiveLocation,
            },
            {
              label: 'Order & Verification SMS Alerts',
              desc: 'Receive critical OTP codes, pickup confirmations, and delivery notifications.',
              checked: smsAlerts,
              onChange: setSmsAlerts,
            },
            {
              label: 'Promotional Offers & Discounts',
              desc: 'Receive seasonal coupons and curated local store recommendations.',
              checked: marketingEmails,
              onChange: setMarketingEmails,
            },
            {
              label: 'Service Quality Analytics',
              desc: 'Help improve delivery ETA predictions and routing reliability.',
              checked: dataAnalyticsConsent,
              onChange: setDataAnalyticsConsent,
            },
          ].map((item) => (
            <label
              key={item.label}
              className="flex items-center justify-between gap-4 py-3.5 cursor-pointer"
            >
              <div>
                <p className="text-sm font-medium text-slate-900">{item.label}</p>
                <p className="text-xs text-slate-500 mt-0.5">{item.desc}</p>
              </div>
              <input
                type="checkbox"
                checked={item.checked}
                onChange={(e) => item.onChange(e.target.checked)}
                className="h-5 w-5 rounded border-slate-300 text-rose-600 focus:ring-rose-500 shrink-0"
              />
            </label>
          ))}
        </div>
      </div>

      {/* Password & Security */}
      <form
        onSubmit={handlePasswordChange}
        className="rounded-xl border border-slate-200 bg-white p-6 space-y-4"
      >
        <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
          <KeyRound className="w-5 h-5 text-slate-800" />
          <div>
            <h3 className="text-base font-semibold text-slate-900">Account Security &amp; Password</h3>
            <p className="text-xs text-slate-500">Update your login credentials</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Current Password</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Enter current password"
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:outline-none focus:border-slate-900"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">New Password (min 8 chars)</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Create strong new password"
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:outline-none focus:border-slate-900"
            />
          </div>
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={savingPwd || !newPassword}
            className="px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-900 text-xs font-semibold min-h-[40px] disabled:opacity-50"
          >
            {savingPwd ? 'Updating...' : 'Update Password'}
          </button>
        </div>
      </form>

      {/* Danger Zone: Account Deletion Warning */}
      <div className="rounded-xl border border-rose-300 bg-rose-50/50 p-6 space-y-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-rose-100 text-rose-700 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h3 className="text-base font-bold text-rose-900">Danger Zone &mdash; Delete Account</h3>
            <p className="text-sm text-rose-800 mt-1 leading-relaxed">
              Deleting your DELIVOO account is permanent and irreversible. Your profile, saved addresses, active shop/rider availability, and login access will be permanently removed. Any in-progress orders must be completed or cancelled before deletion.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-rose-200/80">
          <span className="text-xs font-medium text-rose-700 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5" />
            Protected by password &amp; confirmation verification
          </span>
          <button
            type="button"
            onClick={() => setShowDeleteModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold transition-colors min-h-[44px]"
          >
            <Trash2 className="w-4 h-4" />
            Delete My Account
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <form
            onSubmit={handleDeleteAccount}
            className="w-full max-w-md rounded-2xl bg-white border border-slate-200 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-center gap-2.5 text-rose-700">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h4 className="font-display text-lg font-bold text-slate-900">
                Confirm Permanent Deletion
              </h4>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              This action cannot be undone. Type{' '}
              <span className="font-mono font-bold text-rose-700">DELETE MY ACCOUNT</span> below and enter your password to proceed.
            </p>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Confirmation Phrase
              </label>
              <input
                type="text"
                required
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                placeholder="DELETE MY ACCOUNT"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono focus:outline-none focus:border-rose-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Account Password (if set)
              </label>
              <input
                type="password"
                value={deletePassword}
                onChange={(e) => setDeletePassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:border-rose-600"
              />
            </div>

            {deleteError && (
              <div className="rounded-lg bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
                {deleteError}
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowDeleteModal(false);
                  setDeleteError(null);
                }}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 min-h-[40px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={deleting || deleteConfirmText !== 'DELETE MY ACCOUNT'}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold disabled:opacity-50 min-h-[40px]"
              >
                {deleting ? 'Deleting...' : 'Permanently Delete'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
