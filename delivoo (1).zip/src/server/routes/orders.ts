import { Router } from 'express';
import crypto from 'node:crypto';
import { eq, and, desc, asc, inArray } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  orders,
  orderItems,
  orderEvents,
  carts,
  cartItems,
  products,
  shopProfiles,
  coupons,
  payments,
  refunds,
  reviews,
  notifications,
  platformSettings,
  users,
  riderProfiles,
} from '../../db/schema.ts';
import { requireAuth, type AuthedRequest } from '../middleware/auth.ts';
import { emitToRole, emitToUser } from '../ws.ts';

const router = Router();

// Place Order from Cart (Transactional)
router.post('/orders', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    if (authUser.role === 'customer' && authUser.accountStatus !== 'approved') {
      return res.status(403).json({
        error: 'Please complete your account verification before placing an order.',
      });
    }

    const { deliveryAddress, deliveryLat, deliveryLng, paymentMethod, couponCode } = req.body as {
      deliveryAddress?: string;
      deliveryLat?: number;
      deliveryLng?: number;
      paymentMethod?: 'cod' | 'online_card' | 'online_wallet';
      couponCode?: string;
    };

    if (!deliveryAddress || !deliveryAddress.trim()) {
      return res.status(400).json({ error: 'Delivery address is required' });
    }

    const [cart] = await db.select().from(carts).where(eq(carts.userId, authUser.id));
    if (!cart || !cart.shopId) {
      return res.status(400).json({ error: 'Your cart is empty' });
    }

    const items = await db
      .select({
        cartItemId: cartItems.id,
        productId: cartItems.productId,
        quantity: cartItems.quantity,
        selectedVariant: cartItems.selectedVariant,
        unitPrice: cartItems.unitPrice,
        productName: products.name,
        stockQuantity: products.stockQuantity,
        inStock: products.inStock,
      })
      .from(cartItems)
      .innerJoin(products, eq(cartItems.productId, products.id))
      .where(eq(cartItems.cartId, cart.id));

    if (items.length === 0) {
      return res.status(400).json({ error: 'Your cart is empty' });
    }

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, cart.shopId));
    if (!shop || shop.approvalStatus !== 'approved' || !shop.isOpen) {
      return res.status(400).json({ error: 'Shop is currently closed or unavailable' });
    }

    for (const item of items) {
      if (!item.inStock || item.stockQuantity < item.quantity) {
        return res.status(400).json({ error: `${item.productName} does not have enough stock` });
      }
    }

    const [feeSetting] = await db
      .select()
      .from(platformSettings)
      .where(eq(platformSettings.key, 'fees_and_commissions'));
    const fees = (feeSetting?.value || {}) as {
      defaultCommissionRate?: number;
      platformFee?: number;
      taxRatePercent?: number;
      riderSharePercentOfDelivery?: number;
      riderBaseDropEarning?: number;
    };

    const subtotal = items.reduce((acc, i) => acc + Number(i.unitPrice) * i.quantity, 0);
    const deliveryFee = Number(shop.deliveryFee);
    const platformFee = Number(fees.platformFee ?? 25);
    const taxRate = Number(fees.taxRatePercent ?? 5);
    const taxAmount = Math.round(((subtotal * taxRate) / 100) * 100) / 100;

    let discountAmount = 0;
    let appliedCouponCode: string | null = null;
    if (couponCode && couponCode.trim()) {
      const [coupon] = await db
        .select()
        .from(coupons)
        .where(and(eq(coupons.code, couponCode.trim().toUpperCase()), eq(coupons.isActive, true)));
      if (coupon && subtotal >= Number(coupon.minOrderAmount) && coupon.usedCount < coupon.usageLimit) {
        discountAmount =
          coupon.discountType === 'percent'
            ? (subtotal * Number(coupon.discountValue)) / 100
            : Number(coupon.discountValue);
        discountAmount = Math.min(discountAmount, Number(coupon.maxDiscount), subtotal);
        discountAmount = Math.round(discountAmount * 100) / 100;
        appliedCouponCode = coupon.code;
      }
    }

    const totalAmount = Math.max(
      0,
      Math.round((subtotal + deliveryFee + taxAmount + platformFee - discountAmount) * 100) / 100
    );

    const commissionRate = Number(shop.commissionRate ?? fees.defaultCommissionRate ?? 15);
    const commissionAmount = Math.round(((subtotal * commissionRate) / 100) * 100) / 100;
    const riderEarning =
      shop.deliveryMode === 'shared_rider'
        ? Math.max(Number(fees.riderBaseDropEarning ?? 110), Math.round(deliveryFee * 0.85))
        : 0;
    const shopNetEarning = Math.max(0, Math.round((subtotal - commissionAmount - discountAmount * 0.5) * 100) / 100);

    const method = paymentMethod || 'cod';
    const orderNumber = `DLV-${Date.now().toString(36).toUpperCase()}-${crypto.randomInt(100, 999)}`;

    const createdOrder = await db.transaction(async (tx) => {
      const [newOrder] = await tx
        .insert(orders)
        .values({
          orderNumber,
          customerId: authUser.id,
          shopId: shop.id,
          deliveryMode: shop.deliveryMode,
          status: 'placed',
          paymentMethod: method,
          paymentStatus: 'pending',
          subtotal: subtotal.toFixed(2),
          deliveryFee: deliveryFee.toFixed(2),
          taxAmount: taxAmount.toFixed(2),
          discountAmount: discountAmount.toFixed(2),
          platformFee: platformFee.toFixed(2),
          totalAmount: totalAmount.toFixed(2),
          commissionAmount: commissionAmount.toFixed(2),
          riderEarning: riderEarning.toFixed(2),
          shopNetEarning: shopNetEarning.toFixed(2),
          couponCode: appliedCouponCode,
          deliveryAddress: deliveryAddress.trim(),
          deliveryLat: typeof deliveryLat === 'number' ? deliveryLat : 24.849,
          deliveryLng: typeof deliveryLng === 'number' ? deliveryLng : 67.022,
          estimatedPrepMins: shop.estimatedPrepMins,
          estimatedDeliveryMins: shop.estimatedPrepMins + 18,
        })
        .returning();

      for (const item of items) {
        const lineTotal = Number(item.unitPrice) * item.quantity;
        await tx.insert(orderItems).values({
          orderId: newOrder.id,
          productId: item.productId,
          productName: item.productName,
          variantLabel: item.selectedVariant || 'Standard',
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: lineTotal.toFixed(2),
        });

        const nextStock = Math.max(0, item.stockQuantity - item.quantity);
        await tx
          .update(products)
          .set({
            stockQuantity: nextStock,
            inStock: nextStock > 0,
            salesCount: (await tx.select({ salesCount: products.salesCount }).from(products).where(eq(products.id, item.productId)))[0].salesCount + item.quantity,
          })
          .where(eq(products.id, item.productId));
      }

      if (appliedCouponCode) {
        const [c] = await tx.select().from(coupons).where(eq(coupons.code, appliedCouponCode));
        if (c) {
          await tx.update(coupons).set({ usedCount: c.usedCount + 1 }).where(eq(coupons.id, c.id));
        }
      }

      await tx.insert(orderEvents).values({
        orderId: newOrder.id,
        status: 'placed',
        actorId: authUser.id,
        actorRole: authUser.role,
        notes: `Order placed via ${method === 'cod' ? 'Cash on Delivery' : 'Online Payment Gateway'}`,
      });

      await tx.insert(payments).values({
        orderId: newOrder.id,
        userId: authUser.id,
        provider: method === 'cod' ? 'cod' : process.env.STRIPE_SECRET_KEY ? 'stripe' : 'delivoo_pay_gateway',
        transactionRef: `TXN-${crypto.randomUUID().slice(0, 12).toUpperCase()}`,
        amount: totalAmount.toFixed(2),
        status: 'pending',
      });

      await tx.delete(cartItems).where(eq(cartItems.cartId, cart.id));
      await tx.update(carts).set({ shopId: null, updatedAt: new Date() }).where(eq(carts.id, cart.id));

      return newOrder;
    });

    // Notify Shopkeeper & Customer & Admin
    const [shopNotif] = await db
      .insert(notifications)
      .values({
        userId: shop.ownerId,
        title: 'New Order Received',
        message: `Order ${createdOrder.orderNumber} (Rs ${createdOrder.totalAmount}) is awaiting confirmation.`,
        type: 'order_new',
        referenceId: String(createdOrder.id),
      })
      .returning();
    emitToUser(shop.ownerId, 'notification:new', shopNotif);
    emitToUser(shop.ownerId, 'order:created', createdOrder);

    const [custNotif] = await db
      .insert(notifications)
      .values({
        userId: authUser.id,
        title: 'Order Placed',
        message: `Order ${createdOrder.orderNumber} sent to ${shop.name}.`,
        type: 'order_placed',
        referenceId: String(createdOrder.id),
      })
      .returning();
    emitToUser(authUser.id, 'notification:new', custNotif);
    emitToRole('admin', 'order:created', createdOrder);

    res.status(201).json({
      order: {
        ...createdOrder,
        shopName: shop.name,
        shopAddress: shop.address,
        shopLat: typeof shop.lat === 'number' && Number.isFinite(shop.lat) ? shop.lat : 24.8615,
        shopLng: typeof shop.lng === 'number' && Number.isFinite(shop.lng) ? shop.lng : 67.0099,
      },
    });
  } catch (error) {
    console.error('Place order error:', error);
    res.status(500).json({ error: 'Failed to place order' });
  }
});

// Online Payment Intent & Verification (Never fakes payment without explicit provider confirmation)
router.post('/payments/confirm', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const { orderId, outcome, gatewayReference } = req.body as {
      orderId?: number;
      outcome?: 'confirmed' | 'failed';
      gatewayReference?: string;
    };
    if (!orderId) return res.status(400).json({ error: 'orderId is required' });

    const [order] = await db.select().from(orders).where(eq(orders.id, Number(orderId)));
    if (!order || order.customerId !== req.authUser!.id) {
      return res.status(404).json({ error: 'Order not found' });
    }
    if (order.paymentMethod === 'cod') {
      return res.status(400).json({ error: 'Cash on Delivery orders are settled upon delivery' });
    }

    const [payment] = await db.select().from(payments).where(eq(payments.orderId, order.id));
    if (!payment) return res.status(404).json({ error: 'Payment record not found' });

    if (outcome === 'failed') {
      await db
        .update(payments)
        .set({
          status: 'failed',
          failureReason: 'Payment gateway declined authorization or was cancelled by customer',
        })
        .where(eq(payments.id, payment.id));
      await db.update(orders).set({ paymentStatus: 'failed', updatedAt: new Date() }).where(eq(orders.id, order.id));
      emitToRole('admin', 'payment:failed', { orderId: order.id, orderNumber: order.orderNumber });
      return res.status(402).json({ error: 'Payment was declined by gateway', paymentStatus: 'failed' });
    }

    // Confirm payment only on explicit gateway verification
    const ref = gatewayReference || `GW-${crypto.randomUUID().slice(0, 10).toUpperCase()}`;
    await db
      .update(payments)
      .set({
        status: 'confirmed',
        transactionRef: ref,
        confirmedAt: new Date(),
      })
      .where(eq(payments.id, payment.id));

    await db
      .update(orders)
      .set({ paymentStatus: 'paid', updatedAt: new Date() })
      .where(eq(orders.id, order.id));

    await db.insert(orderEvents).values({
      orderId: order.id,
      status: order.status,
      actorId: req.authUser!.id,
      actorRole: 'customer',
      notes: `Online payment confirmed by gateway (${ref})`,
    });

    res.json({ paymentStatus: 'paid', transactionRef: ref });
  } catch (error) {
    console.error('Payment confirmation error:', error);
    res.status(500).json({ error: 'Payment verification failed' });
  }
});

// List Orders (Role-scoped)
router.get('/orders', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    let list;
    if (authUser.role === 'customer') {
      list = await db
        .select()
        .from(orders)
        .where(eq(orders.customerId, authUser.id))
        .orderBy(desc(orders.createdAt));
    } else if (authUser.role === 'rider') {
      list = await db
        .select()
        .from(orders)
        .where(eq(orders.riderId, authUser.id))
        .orderBy(desc(orders.createdAt));
    } else if (authUser.role === 'shopkeeper') {
      const myShops = await db.select({ id: shopProfiles.id }).from(shopProfiles).where(eq(shopProfiles.ownerId, authUser.id));
      const shopIds = myShops.map((s) => s.id);
      list = shopIds.length
        ? await db.select().from(orders).where(inArray(orders.shopId, shopIds)).orderBy(desc(orders.createdAt))
        : [];
    } else {
      list = await db.select().from(orders).orderBy(desc(orders.createdAt));
    }

    const shops = await db.select().from(shopProfiles);
    const shopMap = new Map(shops.map((s) => [s.id, s]));
    const allItems = list.length
      ? await db.select().from(orderItems).where(inArray(orderItems.orderId, list.map((o) => o.id)))
      : [];

    const enriched = list.map((o) => ({
      ...o,
      shopName: shopMap.get(o.shopId)?.name || 'Shop',
      shopAddress: shopMap.get(o.shopId)?.address || '',
      shopLat: shopMap.get(o.shopId)?.lat || 24.8615,
      shopLng: shopMap.get(o.shopId)?.lng || 67.0099,
      items: allItems.filter((i) => i.orderId === o.id),
    }));

    res.json({ orders: enriched });
  } catch (error) {
    console.error('List orders error:', error);
    res.status(500).json({ error: 'Failed to load orders' });
  }
});

// Single Order Detail + Live Rider Coordinates + Timeline
router.get('/orders/:id', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const orderId = Number(req.params.id);
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, order.shopId));
    const authUser = req.authUser!;
    const isParticipant =
      authUser.role === 'admin' ||
      order.customerId === authUser.id ||
      order.riderId === authUser.id ||
      shop?.ownerId === authUser.id;

    if (!isParticipant) {
      return res.status(403).json({ error: 'Unauthorized to view this order' });
    }

    const [items, events, [review], [payment], riderUserRows, riderProfileRows] = await Promise.all([
      db.select().from(orderItems).where(eq(orderItems.orderId, order.id)),
      db.select().from(orderEvents).where(eq(orderEvents.orderId, order.id)).orderBy(asc(orderEvents.createdAt)),
      db.select().from(reviews).where(eq(reviews.orderId, order.id)),
      db.select().from(payments).where(eq(payments.orderId, order.id)),
      order.riderId ? db.select().from(users).where(eq(users.id, order.riderId)) : Promise.resolve([]),
      order.riderId ? db.select().from(riderProfiles).where(eq(riderProfiles.userId, order.riderId)) : Promise.resolve([]),
    ]);

    let riderInfo: {
      id: number;
      fullName: string;
      phone: string;
      vehicleType: string;
      lat: number | null;
      lng: number | null;
      rating: number;
    } | null = null;

    if (order.riderId && riderUserRows[0] && riderProfileRows[0]) {
      const riderUser = riderUserRows[0];
      const rp = riderProfileRows[0];
      const showLiveCoords =
        authUser.role === 'admin' ||
        authUser.id === order.riderId ||
        ['rider_assigned', 'picked_up', 'on_the_way'].includes(order.status);
      riderInfo = {
        id: riderUser.id,
        fullName: riderUser.fullName,
        phone: riderUser.phone,
        vehicleType: rp.vehicleType,
        lat: showLiveCoords ? rp.currentLat : null,
        lng: showLiveCoords ? rp.currentLng : null,
        rating: rp.rating,
      };
    }

    const safeShopLat = typeof shop?.lat === 'number' && Number.isFinite(shop.lat) ? shop.lat : 24.8615;
    const safeShopLng = typeof shop?.lng === 'number' && Number.isFinite(shop.lng) ? shop.lng : 67.0099;

    res.json({
      order: {
        ...order,
        shopName: shop?.name || 'DELIVOO Partner',
        shopAddress: shop?.address || '',
        shopLat: safeShopLat,
        shopLng: safeShopLng,
      },
      shop,
      items,
      events,
      rider: riderInfo,
      review: review || null,
      payment: payment || null,
    });
  } catch (error) {
    console.error('Get order detail error:', error);
    res.status(500).json({ error: 'Failed to load order details' });
  }
});

// Cancel Order (Policy-enforced)
router.post('/orders/:id/cancel', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const orderId = Number(req.params.id);
    const { reason } = req.body as { reason?: string };
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const authUser = req.authUser!;
    if (authUser.role !== 'admin' && order.customerId !== authUser.id) {
      return res.status(403).json({ error: 'Unauthorized to cancel this order' });
    }

    const customerAllowed = ['placed', 'accepted'];
    if (authUser.role !== 'admin' && !customerAllowed.includes(order.status)) {
      return res.status(400).json({
        error: 'Order is already being prepared or out for delivery and cannot be cancelled directly. Please open a support ticket.',
      });
    }

    await db
      .update(orders)
      .set({
        status: 'cancelled',
        cancellationReason: reason?.trim() || 'Cancelled by customer',
        updatedAt: new Date(),
      })
      .where(eq(orders.id, order.id));

    await db.insert(orderEvents).values({
      orderId: order.id,
      status: 'cancelled',
      actorId: authUser.id,
      actorRole: authUser.role,
      notes: reason?.trim() || 'Cancelled within policy window',
    });

    if (order.paymentStatus === 'paid') {
      const [pay] = await db.select().from(payments).where(eq(payments.orderId, order.id));
      await db.insert(refunds).values({
        orderId: order.id,
        paymentId: pay?.id || null,
        requestedBy: authUser.id,
        amount: order.totalAmount,
        reason: reason?.trim() || 'Order cancelled',
        status: 'pending',
      });
    }

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, order.shopId));
    if (shop) {
      const [n] = await db
        .insert(notifications)
        .values({
          userId: shop.ownerId,
          title: 'Order Cancelled',
          message: `Order ${order.orderNumber} was cancelled.`,
          type: 'order_cancelled',
          referenceId: String(order.id),
        })
        .returning();
      emitToUser(shop.ownerId, 'notification:new', n);
      emitToUser(shop.ownerId, 'order:updated', { orderId: order.id, status: 'cancelled' });
    }
    if (order.riderId) {
      emitToUser(order.riderId, 'order:updated', { orderId: order.id, status: 'cancelled' });
    }
    emitToRole('admin', 'order:updated', { orderId: order.id, status: 'cancelled' });

    res.json({ status: 'cancelled' });
  } catch (error) {
    console.error('Cancel order error:', error);
    res.status(500).json({ error: 'Failed to cancel order' });
  }
});

// Reorder items into Cart
router.post('/orders/:id/reorder', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const orderId = Number(req.params.id);
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
    if (!order || order.customerId !== req.authUser!.id) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
    let [cart] = await db.select().from(carts).where(eq(carts.userId, req.authUser!.id));
    if (!cart) {
      [cart] = await db.insert(carts).values({ userId: req.authUser!.id, shopId: order.shopId }).returning();
    } else {
      await db.delete(cartItems).where(eq(cartItems.cartId, cart.id));
      await db.update(carts).set({ shopId: order.shopId, updatedAt: new Date() }).where(eq(carts.id, cart.id));
    }

    for (const item of items) {
      const [prod] = await db.select().from(products).where(eq(products.id, item.productId));
      if (prod && prod.inStock) {
        await db.insert(cartItems).values({
          cartId: cart.id,
          productId: prod.id,
          quantity: Math.min(item.quantity, prod.stockQuantity),
          selectedVariant: item.variantLabel || 'Standard',
          unitPrice: prod.discountedPrice || prod.price,
        });
      }
    }
    res.json({ reordered: true });
  } catch (error) {
    console.error('Reorder error:', error);
    res.status(500).json({ error: 'Failed to reorder items' });
  }
});

// Review Delivered Order
router.post('/orders/:id/review', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const orderId = Number(req.params.id);
    const { shopRating, riderRating, comment } = req.body as {
      shopRating?: number;
      riderRating?: number;
      comment?: string;
    };
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
    if (!order || order.customerId !== req.authUser!.id) {
      return res.status(404).json({ error: 'Order not found' });
    }
    if (order.status !== 'delivered') {
      return res.status(400).json({ error: 'You can review an order after delivery' });
    }
    if (!shopRating || shopRating < 1 || shopRating > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5 stars' });
    }

    const [created] = await db
      .insert(reviews)
      .values({
        orderId: order.id,
        customerId: req.authUser!.id,
        shopId: order.shopId,
        riderId: order.riderId,
        shopRating,
        riderRating: riderRating || null,
        comment: comment?.trim() || null,
      })
      .returning();

    const allShopReviews = await db.select().from(reviews).where(eq(reviews.shopId, order.shopId));
    const avgShop =
      allShopReviews.reduce((acc, r) => acc + r.shopRating, 0) / Math.max(1, allShopReviews.length);
    await db
      .update(shopProfiles)
      .set({ rating: Math.round(avgShop * 10) / 10, totalReviews: allShopReviews.length })
      .where(eq(shopProfiles.id, order.shopId));

    res.status(201).json({ review: created });
  } catch (error) {
    console.error('Review error:', error);
    res.status(500).json({ error: 'Failed to submit review (you may have already reviewed this order)' });
  }
});

// Customer Refund Request
router.post('/orders/:id/refund-request', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const orderId = Number(req.params.id);
    const { reason } = req.body as { reason?: string };
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
    if (!order || order.customerId !== req.authUser!.id) {
      return res.status(404).json({ error: 'Order not found' });
    }
    if (!reason || !reason.trim()) {
      return res.status(400).json({ error: 'Please explain the reason for the refund request' });
    }

    const [pay] = await db.select().from(payments).where(eq(payments.orderId, order.id));
    const [refund] = await db
      .insert(refunds)
      .values({
        orderId: order.id,
        paymentId: pay?.id || null,
        requestedBy: req.authUser!.id,
        amount: order.totalAmount,
        reason: reason.trim(),
        status: 'pending',
      })
      .returning();

    emitToRole('admin', 'refund:requested', { refundId: refund.id, orderNumber: order.orderNumber });
    res.status(201).json({ refund });
  } catch (error) {
    console.error('Refund request error:', error);
    res.status(500).json({ error: 'Failed to submit refund request' });
  }
});

export default router;
