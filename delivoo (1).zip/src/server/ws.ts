import { WebSocketServer, WebSocket } from 'ws';
import type { Server } from 'node:http';
import { verifyAuthToken } from './security.ts';
import { parseCookieValue } from './middleware/auth.ts';

interface SocketMeta {
  userId: number;
  role: string;
}

const userSockets = new Map<number, Set<WebSocket>>();
const roleSockets = new Map<string, Set<WebSocket>>();
const socketMeta = new WeakMap<WebSocket, SocketMeta>();

let wssInstance: WebSocketServer | null = null;

function registerSocket(ws: WebSocket, userId: number, role: string) {
  const prev = socketMeta.get(ws);
  if (prev) {
    userSockets.get(prev.userId)?.delete(ws);
    roleSockets.get(prev.role)?.delete(ws);
  }

  socketMeta.set(ws, { userId, role });
  if (!userSockets.has(userId)) userSockets.set(userId, new Set());
  userSockets.get(userId)!.add(ws);

  if (!roleSockets.has(role)) roleSockets.set(role, new Set());
  roleSockets.get(role)!.add(ws);

  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'auth:ok', userId, role }));
  }
}

export function initWebSocketServer(server: Server): WebSocketServer {
  if (wssInstance) return wssInstance;

  const wss = new WebSocketServer({ server, path: '/ws' });
  wssInstance = wss;

  wss.on('connection', (ws, req) => {
    // Auto-authenticate from HttpOnly session cookie if present on WebSocket upgrade
    const cookieToken = parseCookieValue(req.headers.cookie, 'delivoo_session');
    if (cookieToken) {
      const payload = verifyAuthToken(cookieToken);
      if (payload) {
        registerSocket(ws, payload.userId, payload.role);
      }
    }

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg?.type === 'auth' && typeof msg.token === 'string') {
          const payload = verifyAuthToken(msg.token);
          if (!payload) {
            ws.send(JSON.stringify({ type: 'auth:error', message: 'Invalid session token' }));
            return;
          }
          registerSocket(ws, payload.userId, payload.role);
        } else if (msg?.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', ts: Date.now() }));
        }
      } catch {
        // Ignore malformed socket frames
      }
    });

    ws.on('close', () => {
      const meta = socketMeta.get(ws);
      if (meta) {
        userSockets.get(meta.userId)?.delete(ws);
        roleSockets.get(meta.role)?.delete(ws);
      }
    });
  });

  return wss;
}

export function emitToUser(userId: number, event: string, data: unknown) {
  const sockets = userSockets.get(userId);
  if (!sockets) return;
  const payload = JSON.stringify({ type: event, data, ts: Date.now() });
  for (const ws of sockets) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

export function emitToRole(role: string, event: string, data: unknown) {
  const sockets = roleSockets.get(role);
  if (!sockets) return;
  const payload = JSON.stringify({ type: event, data, ts: Date.now() });
  for (const ws of sockets) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}
