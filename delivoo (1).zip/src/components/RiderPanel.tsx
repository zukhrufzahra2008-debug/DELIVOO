import React, { useEffect, useState, useCallback } from 'react';
import {
  Bike,
  MapPin,
  Navigation,
  CheckCircle2,
  XCircle,
  Wallet,
  LogOut,
  Shield,
  Home,
  WifiOff,
  Compass,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DelivooLogo } from './DelivooLogo';
import { DeliveryMap } from './DeliveryMap';
import { VerificationBanner } from './VerificationBanner';
import { PrivacySafetyPanel } from './PrivacySafetyPanel';

interface RiderDashboardData {
  profile: {
    id: number;
    vehicleType: string;
    isOnline: boolean;
    isAvailable: boolean;
    currentLat: number;
    currentLng: number;
    rating: number;
    totalDeliveries: number;
    totalEarnings: string;
    zoneName: string;
  };
  accountStatus: string;
  stats: {
    todayEarnings: number;
    weeklyEarnings: number;
    monthlyEarnings: number;
    totalDeliveries: number;
    totalEarnings: number;
    rating: number;
  };
  pendingOffers: Array<{
    id: number;
    distanceKm: number;
    estimatedMinutes: number;
    order: {
      id: number;
      orderNumber: string;
      shopName: string;
      shopAddress: string;
      shopLat: number;
      shopLng: number;
      deliveryAddress: string;
      deliveryLat: number;
      deliveryLng: number;
      riderEarning: string;
      paymentMethod: string;
      totalAmount: string;
      items: Array<{ productName: string; quantity: number }>;
    } | null;
  }>;
  activeDelivery: {
    id: number;
    orderNumber: string;
    status: string;
    shopName: string;
    shopAddress: string;
    shopPhone: string;
    shopLat: number;
    shopLng: number;
    deliveryAddress: string;
    deliveryLat: number;
    deliveryLng: number;
    riderEarning: string;
    paymentMethod: string;
    totalAmount: string;
    items: Array<{ productName: string; quantity: number }>;
  } | null;
  orders: Array<{ id: number; orderNumber: string; status: string; shopName: string; riderEarning: string; createdAt: string }>;
  earnings: Array<{ id: number; earningType: string; amount: string; status: string; note: string | null; createdAt: string }>;
}

export const RiderPanel: React.FC = () => {
  const { user, lastWsEvent, apiFetch, logout, pushToast } = useApp();
  const [tab, setTab] = useState<'home' | 'earnings' | 'privacy'>('home');
  const [data, setData] = useState<RiderDashboardData | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'tracking' | 'error'>('idle');
  const [busy, setBusy] = useState(false);

  const loadDashboard = useCallback(async () => {
    try {
      const resp = await apiFetch<RiderDashboardData>('/api/rider/dashboard');
      setData(resp);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to load rider dashboard');
    }
  }, [apiFetch, pushToast]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  useEffect(() => {
    if (!lastWsEvent) return;
    if (['rider:offer', 'order:updated'].includes(lastWsEvent.type)) {
      void loadDashboard();
    }
  }, [lastWsEvent, loadDashboard]);

  // Browser GPS capture when online
  useEffect(() => {
    if (!data?.profile.isOnline || !navigator.geolocation) return;
    setGpsStatus('tracking');
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setGpsStatus('tracking');
        void apiFetch('/api/rider/location', {
          method: 'POST',
          body: JSON.stringify({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            orderId: data.activeDelivery?.id,
          }),
        }).catch(() => {});
      },
      () => {
        setGpsStatus('error');
      },
      { enableHighAccuracy: true, maximumAge: 8000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, [data?.profile.isOnline, data?.activeDelivery?.id, apiFetch]);

  const toggleOnline = async () => {
    if (!data) return;
    setBusy(true);
    try {
      await apiFetch('/api/rider/status', {
        method: 'POST',
        body: JSON.stringify({ isOnline: !data.profile.isOnline }),
      });
      await loadDashboard();
      pushToast('success', !data.profile.isOnline ? 'You are now Online.' : 'You are now Offline.');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Unable to change status');
    } finally {
      setBusy(false);
    }
  };

  const respondOffer = async (assignmentId: number, decision: 'accept' | 'reject') => {
    setBusy(true);
    try {
      await apiFetch(`/api/rider/assignments/${assignmentId}/respond`, {
        method: 'POST',
        body: JSON.stringify({ decision }),
      });
      await loadDashboard();
      pushToast('success', decision === 'accept' ? 'Delivery accepted!' : 'Offer declined.');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Action failed');
    } finally {
      setBusy(false);
    }
  };

  const advanceOrder = async (orderId: number, nextStatus: 'picked_up' | 'on_the_way' | 'delivered') => {
    setBusy(true);
    try {
      await apiFetch(`/api/rider/orders/${orderId}/status`, {
        method: 'POST',
        body: JSON.stringify({ nextStatus }),
      });
      await loadDashboard();
      pushToast('success', `Order marked ${nextStatus.replace(/_/g, ' ')}`);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Update failed');
    } finally {
      setBusy(false);
    }
  };

  const sendLocationPing = async (lat: number, lng: number) => {
    try {
      await apiFetch('/api/rider/location', {
        method: 'POST',
        body: JSON.stringify({ lat, lng, orderId: data?.activeDelivery?.id }),
      });
      await loadDashboard();
      pushToast('info', 'GPS location synced.');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to sync location');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-20 md:pb-10">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <DelivooLogo />
            <span className="text-xs font-semibold text-slate-500 hidden sm:inline">
              &middot; Rider Partner
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              type="button"
              onClick={() => setTab('home')}
              className={`py-1 border-b-2 ${
                tab === 'home' ? 'border-rose-600 text-slate-900' : 'border-transparent'
              }`}
            >
              Deliveries
            </button>
            <button
              type="button"
              onClick={() => setTab('earnings')}
              className={`py-1 border-b-2 ${
                tab === 'earnings' ? 'border-rose-600 text-slate-900' : 'border-transparent'
              }`}
            >
              Earnings
            </button>
            <button
              type="button"
              onClick={() => setTab('privacy')}
              className={`py-1 border-b-2 ${
                tab === 'privacy' ? 'border-rose-600 text-slate-900' : 'border-transparent'
              }`}
            >
              Privacy &amp; Safety
            </button>
          </nav>

          <div className="flex items-center gap-3">
            {data && (
              <button
                type="button"
                disabled={busy}
                onClick={() => void toggleOnline()}
                className={`px-4 py-2 rounded-xl text-xs font-bold min-h-[40px] transition-colors ${
                  data.profile.isOnline
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                    : 'bg-slate-200 text-slate-800 hover:bg-slate-300'
                }`}
              >
                {data.profile.isOnline ? 'Online' : 'Offline'}
              </button>
            )}
            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold min-h-[40px]"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 space-y-6">
        <VerificationBanner />

        {tab === 'home' && data && (
          <>
            {/* Performance & KPI Summary */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: "Today's Earnings", value: `Rs ${data.stats.todayEarnings.toFixed(0)}` },
                { label: 'Weekly Earnings', value: `Rs ${data.stats.weeklyEarnings.toFixed(0)}` },
                { label: 'Completed Drops', value: String(data.stats.totalDeliveries) },
                { label: 'Rider Rating', value: `${data.stats.rating.toFixed(1)} / 5.0` },
              ].map((kpi) => (
                <div key={kpi.label} className="rounded-2xl border border-slate-200 bg-white p-4">
                  <p className="text-xs text-slate-500">{kpi.label}</p>
                  <p className="font-display text-xl font-bold text-slate-900 mt-1 tabular-nums">
                    {kpi.value}
                  </p>
                </div>
              ))}
            </div>

            {gpsStatus === 'error' && data.profile.isOnline && (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 flex items-center justify-between text-xs text-amber-800">
                <span className="flex items-center gap-2">
                  <WifiOff className="w-4 h-4 shrink-0" />
                  Browser GPS permission unavailable. Click the map below to manually update your position.
                </span>
              </div>
            )}

            {/* Pending Delivery Offers */}
            {data.pendingOffers.length > 0 && (
              <div className="space-y-3">
                <h2 className="font-display text-lg font-bold text-slate-900">
                  Incoming Delivery Requests ({data.pendingOffers.length})
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.pendingOffers.map(
                    (offer) =>
                      offer.order && (
                        <div
                          key={offer.id}
                          className="rounded-2xl border border-rose-300 bg-white p-5 space-y-4 shadow-sm"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="font-mono text-xs text-slate-500">
                                {offer.order.orderNumber}
                              </span>
                              <h3 className="font-display text-base font-bold text-slate-900">
                                {offer.order.shopName}
                              </h3>
                            </div>
                            <span className="font-mono text-sm font-bold text-emerald-700 tabular-nums">
                              Earn Rs {Number(offer.order.riderEarning).toFixed(0)}
                            </span>
                          </div>
                          <div className="text-xs text-slate-600 space-y-1">
                            <p>
                              <strong>Pickup:</strong> {offer.order.shopAddress}
                            </p>
                            <p>
                              <strong>Drop-off:</strong> {offer.order.deliveryAddress}
                            </p>
                            <p className="tabular-nums">
                              Distance: {offer.distanceKm} km &middot; ETA ~{offer.estimatedMinutes} mins
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void respondOffer(offer.id, 'reject')}
                              className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 inline-flex items-center justify-center gap-1.5"
                            >
                              <XCircle className="w-4 h-4 text-rose-600" />
                              Reject
                            </button>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void respondOffer(offer.id, 'accept')}
                              className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 inline-flex items-center justify-center gap-1.5"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              Accept Request
                            </button>
                          </div>
                        </div>
                      )
                  )}
                </div>
              </div>
            )}

            {/* Active Delivery + Navigation Map */}
            {data.activeDelivery ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-mono text-xs text-slate-500">
                      Active Delivery &middot; {data.activeDelivery.orderNumber}
                    </p>
                    <h2 className="font-display text-xl font-bold text-slate-900">
                      {data.activeDelivery.shopName} &rarr; Customer
                    </h2>
                  </div>
                  <span className="text-xs font-bold text-rose-600 capitalize">
                    {data.activeDelivery.status.replace(/_/g, ' ')}
                  </span>
                </div>

                <DeliveryMap
                  center={[data.profile.currentLat, data.profile.currentLng]}
                  markers={[
                    {
                      lat: data.activeDelivery.shopLat,
                      lng: data.activeDelivery.shopLng,
                      label: `Pickup: ${data.activeDelivery.shopName}`,
                      kind: 'shop',
                    },
                    {
                      lat: data.activeDelivery.deliveryLat,
                      lng: data.activeDelivery.deliveryLng,
                      label: 'Customer Drop-off',
                      kind: 'customer',
                    },
                    {
                      lat: data.profile.currentLat,
                      lng: data.profile.currentLng,
                      label: 'You (Rider)',
                      kind: 'rider',
                    },
                  ]}
                  routePoints={[
                    [data.profile.currentLat, data.profile.currentLng],
                    [data.activeDelivery.shopLat, data.activeDelivery.shopLng],
                    [data.activeDelivery.deliveryLat, data.activeDelivery.deliveryLng],
                  ]}
                  interactivePick
                  onPickLocation={(lat, lng) => void sendLocationPing(lat, lng)}
                  heightClass="h-64"
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-50 rounded-xl p-4">
                  <div>
                    <p className="font-bold text-slate-900 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-600" />
                      Pickup Location
                    </p>
                    <p className="text-slate-600 mt-1">{data.activeDelivery.shopAddress}</p>
                    <p className="text-slate-500 font-mono mt-0.5">{data.activeDelivery.shopPhone}</p>
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Navigation className="w-3.5 h-3.5 text-rose-600" />
                      Delivery Destination
                    </p>
                    <p className="text-slate-600 mt-1">{data.activeDelivery.deliveryAddress}</p>
                    <p className="text-slate-700 font-semibold mt-0.5">
                      {data.activeDelivery.paymentMethod === 'cod'
                        ? `Collect COD: Rs ${Number(data.activeDelivery.totalAmount).toFixed(0)}`
                        : 'Already Paid Online'}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3">
                  {data.activeDelivery.status === 'rider_assigned' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void advanceOrder(data.activeDelivery!.id, 'picked_up')}
                      className="flex-1 py-3 rounded-xl bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 min-h-[44px]"
                    >
                      Confirm Pickup from Shop
                    </button>
                  )}
                  {data.activeDelivery.status === 'picked_up' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void advanceOrder(data.activeDelivery!.id, 'on_the_way')}
                      className="flex-1 py-3 rounded-xl bg-amber-600 text-white text-sm font-semibold hover:bg-amber-700 min-h-[44px]"
                    >
                      Heading to Customer
                    </button>
                  )}
                  {['picked_up', 'on_the_way'].includes(data.activeDelivery.status) && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void advanceOrder(data.activeDelivery!.id, 'delivered')}
                      className="flex-1 py-3 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 min-h-[44px]"
                    >
                      Confirm Delivery Complete
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-slate-200 bg-white p-8 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Bike className="w-6 h-6 text-rose-600" />
                    <div>
                      <h3 className="font-display text-base font-bold text-slate-900">
                        {data.profile.isOnline ? 'Waiting for Nearby Requests' : 'You Are Offline'}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Zone: {data.profile.zoneName} &middot; Vehicle: {data.profile.vehicleType}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      void sendLocationPing(data.profile.currentLat, data.profile.currentLng)
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold hover:bg-slate-50"
                  >
                    <Compass className="w-3.5 h-3.5 text-emerald-600" />
                    Sync Position
                  </button>
                </div>
                <DeliveryMap
                  center={[data.profile.currentLat, data.profile.currentLng]}
                  markers={[
                    {
                      lat: data.profile.currentLat,
                      lng: data.profile.currentLng,
                      label: `${user?.fullName || 'Rider'} (Current GPS)`,
                      kind: 'rider',
                    },
                  ]}
                  interactivePick
                  onPickLocation={(lat, lng) => void sendLocationPing(lat, lng)}
                  heightClass="h-52"
                />
              </div>
            )}
          </>
        )}

        {tab === 'earnings' && data && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="text-xs text-slate-500">Weekly Earnings</p>
                <p className="font-display text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                  Rs {data.stats.weeklyEarnings.toFixed(0)}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="text-xs text-slate-500">Monthly Earnings</p>
                <p className="font-display text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                  Rs {data.stats.monthlyEarnings.toFixed(0)}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="text-xs text-slate-500">Lifetime Total</p>
                <p className="font-display text-2xl font-bold text-emerald-700 mt-1 tabular-nums">
                  Rs {data.stats.totalEarnings.toFixed(0)}
                </p>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100">
                <h3 className="font-display text-base font-bold text-slate-900">
                  Delivery Earnings Ledger
                </h3>
              </div>
              {data.earnings.length === 0 ? (
                <p className="p-8 text-center text-sm text-slate-500">No earnings recorded yet.</p>
              ) : (
                <div className="divide-y divide-slate-100">
                  {data.earnings.map((e) => (
                    <div key={e.id} className="px-5 py-3.5 flex items-center justify-between text-sm">
                      <div>
                        <p className="font-semibold text-slate-900 capitalize">
                          {e.note || e.earningType.replace(/_/g, ' ')}
                        </p>
                        <p className="text-xs text-slate-500">
                          {new Date(e.createdAt).toLocaleString()} &middot; {e.status}
                        </p>
                      </div>
                      <span className="font-mono font-bold text-emerald-700 tabular-nums">
                        +Rs {Number(e.amount).toFixed(0)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'privacy' && <PrivacySafetyPanel />}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 h-16 grid grid-cols-3 items-center">
        <button
          type="button"
          onClick={() => setTab('home')}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'home' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Deliveries</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('earnings')}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'earnings' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <Wallet className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Earnings</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('privacy')}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'privacy' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <Shield className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Privacy</span>
        </button>
      </nav>
    </div>
  );
};
