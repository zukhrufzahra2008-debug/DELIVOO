import { relations } from 'drizzle-orm';
import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from 'drizzle-orm/pg-core';

export const users = pgTable(
  'users',
  {
    id: serial('id').primaryKey(),
    uid: text('uid').notNull().unique(),
    email: text('email').notNull().unique(),
    passwordHash: text('password_hash'),
    fullName: text('full_name').notNull(),
    phone: text('phone').notNull(),
    dob: text('dob'),
    cnicNumber: text('cnic_number'),
    cnicMasked: text('cnic_masked'),
    role: text('role').notNull().default('customer'), // customer | shopkeeper | rider | admin
    adminTier: text('admin_tier'), // 'main' | 'sub' | null
    createdByAdminId: integer('created_by_admin_id'),
    accountStatus: text('account_status').notNull().default('pending_verification'), // pending_verification | under_review | approved | rejected | suspended | deleted
    emailVerified: boolean('email_verified').notNull().default(false),
    phoneVerified: boolean('phone_verified').notNull().default(false),
    rejectionReason: text('rejection_reason'),
    privacySettings: jsonb('privacy_settings').$type<{
      shareLiveLocation: boolean;
      marketingEmails: boolean;
      smsAlerts: boolean;
      dataAnalyticsConsent: boolean;
    }>().default({
      shareLiveLocation: true,
      marketingEmails: false,
      smsAlerts: true,
      dataAnalyticsConsent: true,
    }),
    deletedAt: timestamp('deleted_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_users_role_status').on(table.role, table.accountStatus),
    index('idx_users_phone').on(table.phone),
    index('idx_users_cnic').on(table.cnicNumber),
  ]
);

export const otpVerifications = pgTable(
  'otp_verifications',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
    target: text('target').notNull(),
    channel: text('channel').notNull(), // email | phone | password_reset
    codeHash: text('code_hash').notNull(),
    expiresAt: timestamp('expires_at').notNull(),
    consumed: boolean('consumed').notNull().default(false),
    attempts: integer('attempts').notNull().default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_otp_target_channel').on(table.target, table.channel)]
);

export const customerProfiles = pgTable('customer_profiles', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull()
    .unique(),
  ageVerified: boolean('age_verified').notNull().default(false),
  loyaltyPoints: integer('loyalty_points').notNull().default(0),
  emergencyContact: text('emergency_contact'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const riderProfiles = pgTable(
  'rider_profiles',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull()
      .unique(),
    residentialAddress: text('residential_address').notNull(),
    vehicleType: text('vehicle_type').notNull(), // motorbike | bicycle | car | scooter
    vehicleRegistration: text('vehicle_registration'),
    drivingLicenseNumber: text('driving_license_number'),
    licenseExpiryDate: text('license_expiry_date'),
    emergencyContact: text('emergency_contact').notNull(),
    profilePhotoUrl: text('profile_photo_url'),
    isOnline: boolean('is_online').notNull().default(false),
    isAvailable: boolean('is_available').notNull().default(true),
    currentLat: doublePrecision('current_lat').default(24.8607),
    currentLng: doublePrecision('current_lng').default(67.0011),
    lastLocationAt: timestamp('last_location_at'),
    activeOrdersCount: integer('active_orders_count').notNull().default(0),
    rating: doublePrecision('rating').notNull().default(5.0),
    totalDeliveries: integer('total_deliveries').notNull().default(0),
    totalEarnings: numeric('total_earnings', { precision: 12, scale: 2 }).notNull().default('0.00'),
    zoneName: text('zone_name').notNull().default('Central Metro'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_riders_online_avail').on(table.isOnline, table.isAvailable)]
);

export const categories = pgTable('categories', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  slug: text('slug').notNull().unique(),
  description: text('description'),
  iconName: text('icon_name').notNull().default('Store'),
  sortOrder: integer('sort_order').notNull().default(0),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const shopProfiles = pgTable(
  'shop_profiles',
  {
    id: serial('id').primaryKey(),
    ownerId: integer('owner_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    name: text('name').notNull(),
    slug: text('slug').notNull().unique(),
    categoryId: integer('category_id')
      .references(() => categories.id)
      .notNull(),
    description: text('description').notNull(),
    address: text('address').notNull(),
    city: text('city').notNull().default('Karachi'),
    lat: doublePrecision('lat').notNull().default(24.8615),
    lng: doublePrecision('lng').notNull().default(67.0099),
    contactNumber: text('contact_number').notNull(),
    businessRegNumber: text('business_reg_number'),
    logoUrl: text('logo_url'),
    bannerUrl: text('banner_url'),
    openingHours: text('opening_hours').notNull().default('09:00 AM - 11:30 PM'),
    deliveryMode: text('delivery_mode').notNull().default('shared_rider'), // shared_rider | own_rider
    ownRiderName: text('own_rider_name'),
    ownRiderPhone: text('own_rider_phone'),
    deliveryFee: numeric('delivery_fee', { precision: 10, scale: 2 }).notNull().default('120.00'),
    estimatedPrepMins: integer('estimated_prep_mins').notNull().default(20),
    commissionRate: numeric('commission_rate', { precision: 5, scale: 2 }).notNull().default('15.00'),
    bankName: text('bank_name'),
    bankAccountTitle: text('bank_account_title'),
    bankAccountNumber: text('bank_account_number'),
    rating: doublePrecision('rating').notNull().default(4.8),
    totalReviews: integer('total_reviews').notNull().default(0),
    isOpen: boolean('is_open').notNull().default(true),
    isFeatured: boolean('is_featured').notNull().default(false),
    isPopular: boolean('is_popular').notNull().default(false),
    approvalStatus: text('approval_status').notNull().default('pending_verification'), // pending_verification | under_review | approved | rejected | suspended
    rejectionReason: text('rejection_reason'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_shops_category_status').on(table.categoryId, table.approvalStatus),
    index('idx_shops_owner').on(table.ownerId),
  ]
);

export const verificationApplications = pgTable(
  'verification_applications',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    targetRole: text('target_role').notNull(),
    status: text('status').notNull().default('pending_verification'),
    autoChecksPassed: boolean('auto_checks_passed').notNull().default(false),
    identityProviderStatus: text('identity_provider_status').notNull().default('pending'),
    riskScore: integer('risk_score').notNull().default(0),
    riskFlags: jsonb('risk_flags').$type<string[]>().default([]),
    reviewNotes: text('review_notes'),
    reviewedBy: integer('reviewed_by').references(() => users.id),
    reviewedAt: timestamp('reviewed_at'),
    submittedAt: timestamp('submitted_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('idx_verif_status').on(table.status)]
);

export const verificationDocuments = pgTable('verification_documents', {
  id: serial('id').primaryKey(),
  applicationId: integer('application_id')
    .references(() => verificationApplications.id, { onDelete: 'cascade' })
    .notNull(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  docType: text('doc_type').notNull(),
  fileName: text('file_name').notNull(),
  mimeType: text('mime_type').notNull(),
  fileSize: integer('file_size').notNull(),
  storageDataUrl: text('storage_data_url').notNull(),
  expiryDate: text('expiry_date'),
  verificationState: text('verification_state').notNull().default('uploaded'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const addresses = pgTable('addresses', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  label: text('label').notNull().default('Home'),
  streetAddress: text('street_address').notNull(),
  area: text('area').notNull(),
  city: text('city').notNull().default('Karachi'),
  lat: doublePrecision('lat').notNull().default(24.8607),
  lng: doublePrecision('lng').notNull().default(67.0011),
  instructions: text('instructions'),
  isDefault: boolean('is_default').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const products = pgTable(
  'products',
  {
    id: serial('id').primaryKey(),
    shopId: integer('shop_id')
      .references(() => shopProfiles.id, { onDelete: 'cascade' })
      .notNull(),
    categoryId: integer('category_id')
      .references(() => categories.id)
      .notNull(),
    name: text('name').notNull(),
    description: text('description').notNull(),
    price: numeric('price', { precision: 10, scale: 2 }).notNull(),
    discountedPrice: numeric('discounted_price', { precision: 10, scale: 2 }),
    stockQuantity: integer('stock_quantity').notNull().default(25),
    inStock: boolean('in_stock').notNull().default(true),
    unitLabel: text('unit_label').default('1 item'),
    variants: jsonb('variants').$type<Array<{ name: string; priceDelta: number }>>().default([]),
    imageUrl: text('image_url'),
    barcode: text('barcode'),
    expiryDate: text('expiry_date'),
    manufacturingDate: text('manufacturing_date'),
    freshnessInfo: text('freshness_info'),
    importSource: text('import_source').notNull().default('manual'),
    isRecommended: boolean('is_recommended').notNull().default(false),
    salesCount: integer('sales_count').notNull().default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_products_shop').on(table.shopId, table.inStock),
    index('idx_products_barcode').on(table.barcode),
  ]
);

export const productImages = pgTable('product_images', {
  id: serial('id').primaryKey(),
  productId: integer('product_id')
    .references(() => products.id, { onDelete: 'cascade' })
    .notNull(),
  imageUrl: text('image_url').notNull(),
  isPrimary: boolean('is_primary').notNull().default(false),
  sortOrder: integer('sort_order').notNull().default(0),
});

export const carts = pgTable('carts', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull()
    .unique(),
  shopId: integer('shop_id').references(() => shopProfiles.id, { onDelete: 'set null' }),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const cartItems = pgTable(
  'cart_items',
  {
    id: serial('id').primaryKey(),
    cartId: integer('cart_id')
      .references(() => carts.id, { onDelete: 'cascade' })
      .notNull(),
    productId: integer('product_id')
      .references(() => products.id, { onDelete: 'cascade' })
      .notNull(),
    quantity: integer('quantity').notNull().default(1),
    selectedVariant: text('selected_variant').default('Standard'),
    unitPrice: numeric('unit_price', { precision: 10, scale: 2 }).notNull(),
  },
  (table) => [uniqueIndex('idx_cart_product_variant').on(table.cartId, table.productId, table.selectedVariant)]
);

export const coupons = pgTable('coupons', {
  id: serial('id').primaryKey(),
  code: text('code').notNull().unique(),
  title: text('title').notNull(),
  discountType: text('discount_type').notNull().default('percent'), // percent | fixed
  discountValue: numeric('discount_value', { precision: 10, scale: 2 }).notNull(),
  minOrderAmount: numeric('min_order_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
  maxDiscount: numeric('max_discount', { precision: 10, scale: 2 }).notNull().default('500.00'),
  usageLimit: integer('usage_limit').notNull().default(1000),
  usedCount: integer('used_count').notNull().default(0),
  expiresAt: timestamp('expires_at'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const orders = pgTable(
  'orders',
  {
    id: serial('id').primaryKey(),
    orderNumber: text('order_number').notNull().unique(),
    customerId: integer('customer_id')
      .references(() => users.id)
      .notNull(),
    shopId: integer('shop_id')
      .references(() => shopProfiles.id)
      .notNull(),
    riderId: integer('rider_id').references(() => users.id),
    deliveryMode: text('delivery_mode').notNull().default('shared_rider'),
    status: text('status').notNull().default('placed'),
    // placed | accepted | preparing | ready_for_pickup | rider_assigned | picked_up | on_the_way | delivered | cancelled | rejected
    paymentMethod: text('payment_method').notNull().default('cod'), // cod | online_card | online_wallet
    paymentStatus: text('payment_status').notNull().default('pending'), // pending | paid | failed | refunded
    subtotal: numeric('subtotal', { precision: 12, scale: 2 }).notNull(),
    deliveryFee: numeric('delivery_fee', { precision: 10, scale: 2 }).notNull(),
    taxAmount: numeric('tax_amount', { precision: 10, scale: 2 }).notNull(),
    discountAmount: numeric('discount_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
    platformFee: numeric('platform_fee', { precision: 10, scale: 2 }).notNull().default('0.00'),
    totalAmount: numeric('total_amount', { precision: 12, scale: 2 }).notNull(),
    commissionAmount: numeric('commission_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
    riderEarning: numeric('rider_earning', { precision: 10, scale: 2 }).notNull().default('0.00'),
    shopNetEarning: numeric('shop_net_earning', { precision: 12, scale: 2 }).notNull().default('0.00'),
    couponCode: text('coupon_code'),
    deliveryAddress: text('delivery_address').notNull(),
    deliveryLat: doublePrecision('delivery_lat').notNull().default(24.8607),
    deliveryLng: doublePrecision('delivery_lng').notNull().default(67.0011),
    estimatedPrepMins: integer('estimated_prep_mins').default(20),
    estimatedDeliveryMins: integer('estimated_delivery_mins').default(35),
    cancellationReason: text('cancellation_reason'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('idx_orders_customer').on(table.customerId, table.createdAt),
    index('idx_orders_shop').on(table.shopId, table.status),
    index('idx_orders_rider').on(table.riderId, table.status),
  ]
);

export const orderItems = pgTable('order_items', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id')
    .references(() => orders.id, { onDelete: 'cascade' })
    .notNull(),
  productId: integer('product_id')
    .references(() => products.id)
    .notNull(),
  productName: text('product_name').notNull(),
  variantLabel: text('variant_label').default('Standard'),
  quantity: integer('quantity').notNull(),
  unitPrice: numeric('unit_price', { precision: 10, scale: 2 }).notNull(),
  totalPrice: numeric('total_price', { precision: 12, scale: 2 }).notNull(),
});

export const orderEvents = pgTable(
  'order_events',
  {
    id: serial('id').primaryKey(),
    orderId: integer('order_id')
      .references(() => orders.id, { onDelete: 'cascade' })
      .notNull(),
    status: text('status').notNull(),
    actorId: integer('actor_id').references(() => users.id),
    actorRole: text('actor_role').notNull(),
    notes: text('notes'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_order_events_order').on(table.orderId, table.createdAt)]
);

export const riderAssignments = pgTable(
  'rider_assignments',
  {
    id: serial('id').primaryKey(),
    orderId: integer('order_id')
      .references(() => orders.id, { onDelete: 'cascade' })
      .notNull(),
    riderId: integer('rider_id')
      .references(() => users.id)
      .notNull(),
    assignmentType: text('assignment_type').notNull().default('auto'), // auto | manual | own_rider
    status: text('status').notNull().default('offered'), // offered | accepted | rejected | timed_out | completed | reassigned
    distanceKm: doublePrecision('distance_km').default(1.8),
    estimatedMinutes: integer('estimated_minutes').default(18),
    offeredAt: timestamp('offered_at').defaultNow().notNull(),
    respondedAt: timestamp('responded_at'),
  },
  (table) => [index('idx_assignments_rider_status').on(table.riderId, table.status)]
);

export const riderLocations = pgTable(
  'rider_locations',
  {
    id: serial('id').primaryKey(),
    riderId: integer('rider_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    orderId: integer('order_id').references(() => orders.id, { onDelete: 'set null' }),
    lat: doublePrecision('lat').notNull(),
    lng: doublePrecision('lng').notNull(),
    heading: doublePrecision('heading').default(0),
    speedKmh: doublePrecision('speed_kmh').default(0),
    recordedAt: timestamp('recorded_at').defaultNow().notNull(),
  },
  (table) => [index('idx_rider_locs_rider').on(table.riderId, table.recordedAt)]
);

export const payments = pgTable('payments', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id')
    .references(() => orders.id, { onDelete: 'cascade' })
    .notNull(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  provider: text('provider').notNull(), // cod | delivoo_pay_gateway | stripe
  transactionRef: text('transaction_ref').notNull(),
  amount: numeric('amount', { precision: 12, scale: 2 }).notNull(),
  currency: text('currency').notNull().default('PKR'),
  status: text('status').notNull().default('pending'), // pending | confirmed | failed | refunded
  failureReason: text('failure_reason'),
  confirmedAt: timestamp('confirmed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const refunds = pgTable('refunds', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id')
    .references(() => orders.id, { onDelete: 'cascade' })
    .notNull(),
  paymentId: integer('payment_id').references(() => payments.id),
  requestedBy: integer('requested_by')
    .references(() => users.id)
    .notNull(),
  amount: numeric('amount', { precision: 12, scale: 2 }).notNull(),
  reason: text('reason').notNull(),
  status: text('status').notNull().default('pending'), // pending | approved | processed | rejected
  processedBy: integer('processed_by').references(() => users.id),
  processedAt: timestamp('processed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const shopSettlements = pgTable('shop_settlements', {
  id: serial('id').primaryKey(),
  shopId: integer('shop_id')
    .references(() => shopProfiles.id, { onDelete: 'cascade' })
    .notNull(),
  periodLabel: text('period_label').notNull(),
  grossAmount: numeric('gross_amount', { precision: 12, scale: 2 }).notNull(),
  commissionAmount: numeric('commission_amount', { precision: 12, scale: 2 }).notNull(),
  netAmount: numeric('net_amount', { precision: 12, scale: 2 }).notNull(),
  status: text('status').notNull().default('pending'), // pending | processing | settled
  referenceNo: text('reference_no'),
  settledAt: timestamp('settled_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const riderEarnings = pgTable('rider_earnings', {
  id: serial('id').primaryKey(),
  riderId: integer('rider_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  orderId: integer('order_id').references(() => orders.id, { onDelete: 'set null' }),
  earningType: text('earning_type').notNull().default('delivery_fee'), // delivery_fee | bonus | incentive | settlement_payout
  amount: numeric('amount', { precision: 10, scale: 2 }).notNull(),
  status: text('status').notNull().default('available'), // pending | available | settled
  note: text('note'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const reviews = pgTable('reviews', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id')
    .references(() => orders.id, { onDelete: 'cascade' })
    .notNull()
    .unique(),
  customerId: integer('customer_id')
    .references(() => users.id)
    .notNull(),
  shopId: integer('shop_id')
    .references(() => shopProfiles.id)
    .notNull(),
  riderId: integer('rider_id').references(() => users.id),
  shopRating: integer('shop_rating').notNull(),
  riderRating: integer('rider_rating'),
  comment: text('comment'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const notifications = pgTable(
  'notifications',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    title: text('title').notNull(),
    message: text('message').notNull(),
    type: text('type').notNull().default('info'),
    referenceId: text('reference_id'),
    isRead: boolean('is_read').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_notifications_user_read').on(table.userId, table.isRead)]
);

export const supportTickets = pgTable('support_tickets', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  userRole: text('user_role').notNull(),
  orderId: integer('order_id').references(() => orders.id, { onDelete: 'set null' }),
  category: text('category').notNull().default('general'),
  subject: text('subject').notNull(),
  description: text('description').notNull(),
  status: text('status').notNull().default('open'), // open | in_progress | resolved | closed
  resolutionNotes: text('resolution_notes'),
  resolvedBy: integer('resolved_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const banners = pgTable('banners', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  subtitle: text('subtitle').notNull(),
  badgeText: text('badge_text').default('Featured'),
  ctaText: text('cta_text').default('Explore'),
  targetCategory: text('target_category'),
  imageUrl: text('image_url'),
  isActive: boolean('is_active').notNull().default(true),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const deliveryZones = pgTable('delivery_zones', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  city: text('city').notNull().default('Karachi'),
  centerLat: doublePrecision('center_lat').notNull(),
  centerLng: doublePrecision('center_lng').notNull(),
  radiusKm: doublePrecision('radius_km').notNull().default(12),
  baseDeliveryFee: numeric('base_delivery_fee', { precision: 10, scale: 2 }).notNull().default('100.00'),
  perKmFee: numeric('per_km_fee', { precision: 10, scale: 2 }).notNull().default('25.00'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const platformSettings = pgTable('platform_settings', {
  id: serial('id').primaryKey(),
  key: text('key').notNull().unique(),
  value: jsonb('value').$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const auditLogs = pgTable(
  'audit_logs',
  {
    id: serial('id').primaryKey(),
    actorId: integer('actor_id'),
    actorRole: text('actor_role').notNull(),
    action: text('action').notNull(),
    targetType: text('target_type').notNull(),
    targetId: text('target_id'),
    details: jsonb('details').$type<Record<string, unknown>>().default({}),
    ipAddress: text('ip_address'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('idx_audit_created').on(table.createdAt)]
);

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  customerProfile: one(customerProfiles, { fields: [users.id], references: [customerProfiles.userId] }),
  riderProfile: one(riderProfiles, { fields: [users.id], references: [riderProfiles.userId] }),
  shops: many(shopProfiles),
  addresses: many(addresses),
  notifications: many(notifications),
}));

export const shopProfilesRelations = relations(shopProfiles, ({ one, many }) => ({
  owner: one(users, { fields: [shopProfiles.ownerId], references: [users.id] }),
  category: one(categories, { fields: [shopProfiles.categoryId], references: [categories.id] }),
  products: many(products),
  orders: many(orders),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  shop: one(shopProfiles, { fields: [products.shopId], references: [shopProfiles.id] }),
  category: one(categories, { fields: [products.categoryId], references: [categories.id] }),
  images: many(productImages),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(users, { fields: [orders.customerId], references: [users.id] }),
  shop: one(shopProfiles, { fields: [orders.shopId], references: [shopProfiles.id] }),
  rider: one(users, { fields: [orders.riderId], references: [users.id] }),
  items: many(orderItems),
  events: many(orderEvents),
}));
