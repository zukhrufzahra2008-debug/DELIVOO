import React from 'react';

interface DelivooLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showMark?: boolean;
}

export const DelivooLogo: React.FC<DelivooLogoProps> = ({ size = 'md', showMark = true }) => {
  const iconSize = size === 'sm' ? 26 : size === 'lg' ? 38 : 32;
  const textClass =
    size === 'sm'
      ? 'text-lg font-extrabold tracking-tight'
      : size === 'lg'
      ? 'text-2xl font-extrabold tracking-tight'
      : 'text-xl font-extrabold tracking-tight';

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 select-none">
      {showMark && (
        <svg
          width={iconSize}
          height={iconSize}
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          <rect width="40" height="40" rx="11" fill="#E11D48" />
          <path
            d="M12 13.5H20.5C25.2 13.5 28.5 16.4 28.5 20C28.5 23.6 25.2 26.5 20.5 26.5H12V13.5Z"
            stroke="#FFFFFF"
            strokeWidth="2.8"
            strokeLinejoin="round"
          />
          <path
            d="M17 20H23.5M23.5 20L21 17.5M23.5 20L21 22.5"
            stroke="#FFFFFF"
            strokeWidth="2.3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
      <span className={`font-display ${textClass} text-slate-900`}>
        DELIV<span className="text-rose-600">OO</span>
      </span>
    </span>
  );
};
