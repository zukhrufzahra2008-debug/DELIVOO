import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import {
  Search,
  MapPin,
  ShoppingBag,
  Star,
  Clock,
  Plus,
  Minus,
  Trash2,
  X,
  ArrowLeft,
  Bell,
  Home,
  Receipt,
  Shield,
  LifeBuoy,
  LogOut,
  CheckCircle2,
  CreditCard,
  Banknote,
  RotateCcw,
  LocateFixed,
  Loader2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DelivooLogo } from './DelivooLogo';
import { DeliveryMap } from './DeliveryMap';
import { VerificationBanner } from './VerificationBanner';
import { PrivacySafetyPanel } from './PrivacySafetyPanel';

interface CustomerPanelProps {
  onOpenAuth: (mode: 'login' | 'register' | 'admin') => void;
}

class MapErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(err: Error) {
    console.error('Order tracking map boundary caught:', err);
  }

  render() {
    if (this.state.failed) {
      return (
        <div className="h-56 rounded-xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center p-4 text-center space-y-2">
          <MapPin className="w-5 h-5 text-rose-600" />
          <p className="text-xs font-semibold text-slate-800">
            Live map preview paused — order status timeline remains live below.
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}

interface Category {
  id: number;
  name: string;
  slug: string;
}

interface Shop {
  id: number;
  name: string;
  categoryId?: number;
  categoryName: string;
  categorySlug: string;
  description: string;
  address: string;
  lat: number;
  lng: number;
  openingHours: string;
  deliveryFee: string;
  estimatedPrepMins: number;
  estimatedTotalMins: number;
  distanceKm: number;
  rating: number;
  totalReviews: number;
  logoUrl: string | null;
  bannerUrl: string | null;
  isOpen: boolean;
  isFeatured: boolean;
  isPopular: boolean;
  deliveryMode: string;
  isRestaurant?: boolean;
  priceTier?: 'premium' | 'mid' | 'street';
  priceTierLabel?: string;
  cuisineStyle?: string;
  avgProductPrice?: number;
}

interface Product {
  id: number;
  shopId: number;
  categoryId?: number;
  name: string;
  description: string;
  price: string;
  discountedPrice: string | null;
  stockQuantity: number;
  inStock: boolean;
  unitLabel: string | null;
  variants: Array<{ name: string; priceDelta: number }>;
  imageUrl: string | null;
  expiryDate: string | null;
  manufacturingDate: string | null;
  freshnessInfo: string | null;
  salesCount?: number;
  shopName?: string;
  categoryName?: string;
  shopCategorySlug?: string;
  isRestaurant?: boolean;
  priceTier?: 'premium' | 'mid' | 'street';
  priceTierLabel?: string;
  cuisineStyle?: string;
}

const STREET_INTENT_RE = /\b(street|bun kabab|shami|anda shami|dhaba|paratha|chaat|gol gappay|thela|roadside|tawa)\b/i;
const PREMIUM_INTENT_RE = /\b(brim|brimcraft|wagyu|dry-aged|artisan|gourmet|craft|truffle|smash|patisserie|french|organic|studio|anc|botanical|sourdough)\b/i;

function haversineKmClient(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const r = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return Math.round(r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * 10) / 10;
}

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  selectedVariant: string;
  unitPrice: string;
  productName: string;
  imageUrl: string | null;
}

interface OrderRecord {
  id: number;
  orderNumber: string;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  subtotal: string;
  deliveryFee: string;
  taxAmount: string;
  discountAmount: string;
  platformFee: string;
  totalAmount: string;
  deliveryAddress: string;
  deliveryLat: number;
  deliveryLng: number;
  shopName: string;
  shopAddress: string;
  shopLat: number;
  shopLng: number;
  estimatedDeliveryMins: number;
  createdAt: string;
  items: Array<{ productName: string; quantity: number; variantLabel: string; totalPrice: string }>;
}

interface OrderDetailPayload {
  order: OrderRecord;
  shop: Shop;
  items: Array<{ productName: string; quantity: number; variantLabel: string; totalPrice: string }>;
  events: Array<{ id: number; status: string; actorRole: string; notes: string | null; createdAt: string }>;
  rider: {
    id: number;
    fullName: string;
    phone: string;
    vehicleType: string;
    lat: number | null;
    lng: number | null;
    rating: number;
  } | null;
  review: { shopRating: number; comment: string | null } | null;
}

export const CustomerPanel: React.FC<CustomerPanelProps> = ({ onOpenAuth }) => {
  const {
    user,
    notifications,
    unreadCount,
    lastWsEvent,
    apiFetch,
    logout,
    pushToast,
    markNotificationsRead,
  } = useApp();

  const [tab, setTab] = useState<'browse' | 'orders' | 'support' | 'privacy'>('browse');
  const [banners, setBanners] = useState<Array<{ id: number; title: string; subtitle: string; ctaText: string; badgeText?: string | null; targetCategory: string | null; imageUrl: string | null }>>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([]);
  const [coupons, setCoupons] = useState<Array<{ code: string; title: string }>>([]);

  // Filters & Location
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTier, setSelectedTier] = useState<'all' | 'premium' | 'mid' | 'street'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('featured');
  const [catalogProducts, setCatalogProducts] = useState<Product[]>([]);
  const [deliveryAddress, setDeliveryAddress] = useState('Clifton Block 2, Karachi');
  const [deliveryLat, setDeliveryLat] = useState(24.849);
  const [deliveryLng, setDeliveryLng] = useState(67.022);
  const [isLiveLocation, setIsLiveLocation] = useState(false);
  const [detectingLocation, setDetectingLocation] = useState(false);
  const [locationSearchQuery, setLocationSearchQuery] = useState('');
  const [locationSearchResults, setLocationSearchResults] = useState<Array<{ display_name: string; lat: string; lon: string }>>([]);
  const [searchingLocation, setSearchingLocation] = useState(false);
  const [savedAddresses, setSavedAddresses] = useState<Array<{ id: number; label: string; streetAddress: string; area: string; lat: number; lng: number }>>([]);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [newStreet, setNewStreet] = useState('');
  const [newArea, setNewArea] = useState('');

  // Selected Shop Detail
  const [activeShopId, setActiveShopId] = useState<number | null>(null);
  const [shopDetail, setShopDetail] = useState<{
    shop: Shop;
    products: Product[];
    reviews: Array<{ id: number; shopRating: number; comment: string | null; customerName: string; createdAt: string }>;
    similarShops?: Shop[];
  } | null>(null);
  const shopCacheRef = useRef<
    Map<
      number,
      {
        shop: Shop;
        products: Product[];
        reviews: Array<{ id: number; shopRating: number; comment: string | null; customerName: string; createdAt: string }>;
        similarShops?: Shop[];
      }
    >
  >(new Map());
  const [variantChoice, setVariantChoice] = useState<Record<number, string>>({});

  // Cart & Checkout
  const [cartOpen, setCartOpen] = useState(false);
  const [cartData, setCartData] = useState<{ shop: Shop | null; items: CartItem[]; subtotal: number }>({
    shop: null,
    items: [],
    subtotal: 0,
  });
  const [couponInput, setCouponInput] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<{ code: string; amount: number } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'online_card'>('cod');
  const [placingOrder, setPlacingOrder] = useState(false);
  const [pendingGatewayOrder, setPendingGatewayOrder] = useState<{ id: number; orderNumber: string; totalAmount: string } | null>(null);

  // Orders & Live Tracking
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [trackedOrderId, setTrackedOrderId] = useState<number | null>(null);
  const [trackedDetail, setTrackedDetail] = useState<OrderDetailPayload | null>(null);
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [liveRiderPos, setLiveRiderPos] = useState<{ lat: number; lng: number } | null>(null);
  const trackingSectionRef = useRef<HTMLDivElement | null>(null);

  // Review Modal
  const [reviewOrderId, setReviewOrderId] = useState<number | null>(null);
  const [shopStars, setShopStars] = useState(5);
  const [riderStars, setRiderStars] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  // Notifications popover
  const [notifOpen, setNotifOpen] = useState(false);

  // Support Tickets
  const [tickets, setTickets] = useState<Array<{ id: number; subject: string; status: string; resolutionNotes: string | null; createdAt: string }>>([]);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketDesc, setTicketDesc] = useState('');
  const [switchShopProduct, setSwitchShopProduct] = useState<Product | null>(null);

  const loadMarketplace = useCallback(async () => {
    try {
      const resp = await apiFetch<{
        banners: typeof banners;
        categories: Category[];
        shops: Shop[];
        recommendedProducts: Product[];
        catalogProducts?: Product[];
        coupons: Array<{ code: string; title: string }>;
      }>('/api/marketplace/home');
      setBanners(resp.banners || []);
      setCategories(resp.categories || []);
      setShops(resp.shops || []);
      setRecommendedProducts(resp.recommendedProducts || []);
      setCatalogProducts(resp.catalogProducts || resp.recommendedProducts || []);
      setCoupons(resp.coupons || []);
    } catch (err) {
      console.error('Load marketplace error:', err);
    }
  }, [apiFetch]);

  const loadCart = useCallback(async () => {
    if (!user) return;
    try {
      const resp = await apiFetch<{ shop: Shop | null; items: CartItem[]; subtotal: number }>('/api/cart');
      setCartData(resp);
    } catch {
      // Ignore
    }
  }, [apiFetch, user]);

  const loadOrders = useCallback(async () => {
    if (!user) return;
    try {
      const resp = await apiFetch<{ orders: OrderRecord[] }>('/api/orders');
      setOrders(resp.orders || []);
    } catch {
      // Ignore
    }
  }, [apiFetch, user]);

  const reverseGeocodeLocation = useCallback(async (lat: number, lng: number, asLive = false) => {
    setDeliveryLat(lat);
    setDeliveryLng(lng);
    try {
      const resp = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
        { signal: AbortSignal.timeout(4500) }
      );
      if (resp.ok) {
        const data = (await resp.json()) as {
          display_name?: string;
          address?: {
            road?: string;
            house_number?: string;
            neighbourhood?: string;
            suburb?: string;
            city_district?: string;
            city?: string;
            town?: string;
            village?: string;
          };
        };
        const a = data.address || {};
        const streetPart = [a.house_number, a.road].filter(Boolean).join(' ') || a.neighbourhood || '';
        const areaPart = [a.suburb || a.city_district, a.city || a.town || a.village].filter(Boolean).join(', ');
        const formatted = [streetPart, areaPart].filter(Boolean).join(', ') ||
          (data.display_name ? data.display_name.split(',').slice(0, 3).join(',').trim() : '');
        if (formatted) {
          setNewStreet(streetPart || formatted.split(',')[0]?.trim() || '');
          setNewArea(areaPart || formatted.split(',').slice(1).join(',').trim() || '');
          setDeliveryAddress(formatted);
          if (asLive) setIsLiveLocation(true);
          return;
        }
      }
    } catch {
      // Fallback to coordinate label when offline or rate-limited
    }
    const fallbackLabel = asLive
      ? `Live GPS (${lat.toFixed(4)}, ${lng.toFixed(4)})`
      : `Pinned (${lat.toFixed(4)}, ${lng.toFixed(4)})`;
    setDeliveryAddress(fallbackLabel);
    if (asLive) setIsLiveLocation(true);
  }, []);

  const detectCurrentLiveLocation = useCallback(
    (silent = false) => {
      if (!('geolocation' in navigator)) {
        if (!silent) pushToast('error', 'Live GPS geolocation is not supported in this browser.');
        return;
      }
      setDetectingLocation(true);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = Math.round(pos.coords.latitude * 100000) / 100000;
          const lng = Math.round(pos.coords.longitude * 100000) / 100000;
          void reverseGeocodeLocation(lat, lng, true).finally(() => {
            setDetectingLocation(false);
            if (!silent) pushToast('success', 'Current live location detected on map.');
          });
        },
        () => {
          setDetectingLocation(false);
          if (!silent) {
            pushToast('info', 'Could not read GPS automatically. Please search or click on the map to set your location.');
          }
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 15000 }
      );
    },
    [pushToast, reverseGeocodeLocation]
  );

  const searchMapLocation = useCallback(async () => {
    const q = locationSearchQuery.trim();
    if (!q) return;
    setSearchingLocation(true);
    try {
      const resp = await fetch(
        `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=${encodeURIComponent(q)}`,
        { signal: AbortSignal.timeout(5000) }
      );
      if (resp.ok) {
        const list = (await resp.json()) as Array<{ display_name: string; lat: string; lon: string }>;
        setLocationSearchResults(list);
      }
    } catch {
      pushToast('error', 'Location search temporarily unavailable. Click directly on the map instead.');
    } finally {
      setSearchingLocation(false);
    }
  }, [locationSearchQuery, pushToast]);

  useEffect(() => {
    void loadMarketplace();
  }, [loadMarketplace]);

  useEffect(() => {
    if (!user) {
      detectCurrentLiveLocation(true);
    }
  }, [user, detectCurrentLiveLocation]);

  useEffect(() => {
    if (user) {
      void loadCart();
      void loadOrders();
      void apiFetch<{ addresses: typeof savedAddresses }>('/api/addresses')
        .then((r) => {
          setSavedAddresses(r.addresses || []);
          if (r.addresses?.length) {
            const first = r.addresses[0];
            setDeliveryAddress(`${first.streetAddress}, ${first.area}`);
            setDeliveryLat(first.lat);
            setDeliveryLng(first.lng);
            setIsLiveLocation(false);
          } else {
            detectCurrentLiveLocation(true);
          }
        })
        .catch(() => {});
      void apiFetch<{ tickets: typeof tickets }>('/api/support/tickets')
        .then((r) => setTickets(r.tickets || []))
        .catch(() => {});
    }
  }, [user, loadCart, loadOrders, apiFetch, detectCurrentLiveLocation]);

  // Listen to real-time WebSocket updates
  useEffect(() => {
    if (!lastWsEvent) return;
    if (lastWsEvent.type === 'order:updated') {
      void loadOrders();
      if (trackedOrderId) {
        void openOrderTracking(trackedOrderId);
      }
    } else if (lastWsEvent.type === 'rider:location' && lastWsEvent.data) {
      const d = lastWsEvent.data as { orderId?: number; lat?: number; lng?: number };
      if (d.orderId === trackedOrderId && typeof d.lat === 'number' && typeof d.lng === 'number') {
        setLiveRiderPos({ lat: d.lat, lng: d.lng });
      }
    }
  }, [lastWsEvent, trackedOrderId, loadOrders]);

  // Instantaneous 0ms client-side distance, category, tier, and search filtering
  const filteredCatalog = useMemo(() => {
    const term = searchQuery.trim().toLowerCase();
    const productPool = catalogProducts.length > 0 ? catalogProducts : recommendedProducts;

    const shopsWithDist = shops.map((s) => {
      const distKm = haversineKmClient(deliveryLat, deliveryLng, s.lat, s.lng);
      return {
        ...s,
        distanceKm: distKm,
        estimatedTotalMins: s.estimatedPrepMins + Math.max(10, Math.round(distKm * 3.5)),
      };
    });

    let matchedShops = [...shopsWithDist];
    if (selectedCategory !== 'all') {
      matchedShops = matchedShops.filter(
        (s) => s.categorySlug === selectedCategory || String(s.categoryId) === selectedCategory
      );
    }
    if (selectedTier !== 'all') {
      matchedShops = matchedShops.filter((s) => s.priceTier === selectedTier);
    }

    if (term) {
      const matchingProdShopIds = new Set(
        productPool
          .filter(
            (p) =>
              p.name.toLowerCase().includes(term) ||
              p.description.toLowerCase().includes(term)
          )
          .map((p) => p.shopId)
      );
      matchedShops = matchedShops.filter(
        (s) =>
          s.name.toLowerCase().includes(term) ||
          s.description.toLowerCase().includes(term) ||
          s.categoryName.toLowerCase().includes(term) ||
          (s.cuisineStyle || '').toLowerCase().includes(term) ||
          matchingProdShopIds.has(s.id)
      );
    }

    if (sortBy === 'rating') {
      matchedShops.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'popular') {
      matchedShops.sort((a, b) => b.totalReviews - a.totalReviews);
    } else if (sortBy === 'price_low') {
      matchedShops.sort((a, b) => (a.avgProductPrice || 0) - (b.avgProductPrice || 0));
    } else if (sortBy === 'distance') {
      matchedShops.sort((a, b) => a.distanceKm - b.distanceKm);
    } else {
      matchedShops.sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || b.rating - a.rating);
    }

    const restaurants = matchedShops.filter(
      (s) => s.isRestaurant ?? s.categorySlug === 'food-and-restaurants'
    );
    const retailStores = matchedShops.filter(
      (s) => !(s.isRestaurant ?? s.categorySlug === 'food-and-restaurants')
    );

    // Strictly tier-matched Recommended Products:
    // Searching or browsing gourmet craft burgers (e.g. "brim", "smash", "wagyu")
    // NEVER recommends mismatched budget street-food items like shami bun kabab.
    let matchedProducts = [...productPool];
    if (selectedCategory !== 'all') {
      matchedProducts = matchedProducts.filter((p) => {
        if (p.shopCategorySlug) return p.shopCategorySlug === selectedCategory;
        const parentShop = shopsWithDist.find((s) => s.id === p.shopId);
        return parentShop?.categorySlug === selectedCategory;
      });
    }
    if (selectedTier !== 'all') {
      matchedProducts = matchedProducts.filter((p) => p.priceTier === selectedTier);
    }

    if (term) {
      const nameMatchedShops = shopsWithDist.filter(
        (s) =>
          s.name.toLowerCase().includes(term) ||
          (s.cuisineStyle || '').toLowerCase().includes(term)
      );
      const explicitPremiumIntent =
        PREMIUM_INTENT_RE.test(term) ||
        (nameMatchedShops.length > 0 && nameMatchedShops.every((s) => s.priceTier === 'premium'));
      const explicitStreetIntent =
        STREET_INTENT_RE.test(term) ||
        (nameMatchedShops.length > 0 && nameMatchedShops.every((s) => s.priceTier === 'street'));

      matchedProducts = matchedProducts.filter((p) => {
        const textMatch =
          p.name.toLowerCase().includes(term) ||
          p.description.toLowerCase().includes(term) ||
          (p.shopName || '').toLowerCase().includes(term) ||
          (p.cuisineStyle || '').toLowerCase().includes(term);
        if (!textMatch) return false;
        if (explicitPremiumIntent && p.priceTier === 'street') return false;
        if (explicitStreetIntent && p.priceTier === 'premium') return false;
        return true;
      });
    }

    matchedProducts.sort((a, b) => (b.salesCount || 0) - (a.salesCount || 0));

    return {
      shops: matchedShops,
      restaurants,
      retailStores,
      recommendedProducts: matchedProducts.slice(0, 12),
    };
  }, [
    shops,
    catalogProducts,
    recommendedProducts,
    selectedCategory,
    selectedTier,
    searchQuery,
    sortBy,
    deliveryLat,
    deliveryLng,
  ]);

  const openShop = async (shopId: number) => {
    setActiveShopId(shopId);

    // Instantaneous 0ms preview from cache or preloaded marketplace catalog
    const cached = shopCacheRef.current.get(shopId);
    if (cached) {
      setShopDetail(cached);
    } else {
      const fallbackShop = shops.find((s) => s.id === shopId);
      if (fallbackShop) {
        const pool = catalogProducts.length > 0 ? catalogProducts : recommendedProducts;
        const fallbackProducts = pool.filter((p) => p.shopId === shopId);
        const fallbackSimilar = shops.filter(
          (s) =>
            s.id !== shopId &&
            s.categorySlug === fallbackShop.categorySlug &&
            s.priceTier === fallbackShop.priceTier
        );
        setShopDetail({
          shop: fallbackShop,
          products: fallbackProducts,
          reviews: [],
          similarShops: fallbackSimilar,
        });
      }
    }

    try {
      const resp = await apiFetch<{
        shop: Shop;
        products: Product[];
        reviews: Array<{ id: number; shopRating: number; comment: string | null; customerName: string; createdAt: string }>;
        similarShops?: Shop[];
      }>(`/api/marketplace/shops/${shopId}`);
      shopCacheRef.current.set(shopId, resp);
      setShopDetail(resp);
    } catch (err) {
      if (!shopCacheRef.current.has(shopId)) {
        pushToast('error', err instanceof Error ? err.message : 'Unable to open shop');
      }
    }
  };

  const addToCart = async (product: Product, replaceShop = false) => {
    if (!user) {
      pushToast('info', 'Please sign in or create an account to add items to your bag.');
      onOpenAuth('login');
      return;
    }
    const chosenVariant =
      variantChoice[product.id] || product.variants?.[0]?.name || 'Standard';
    try {
      const resp = await apiFetch<{ shop: Shop | null; items: CartItem[]; subtotal: number }>(
        '/api/cart/items',
        {
          method: 'POST',
          body: JSON.stringify({
            productId: product.id,
            quantity: 1,
            selectedVariant: chosenVariant,
            replaceShop,
          }),
        }
      );
      setCartData(resp);
      pushToast('success', `${product.name} added to cart.`);
    } catch (err) {
      const e = err as Error & { code?: string };
      if (e.code === 'DIFFERENT_SHOP') {
        setSwitchShopProduct(product);
      } else {
        pushToast('error', e.message);
      }
    }
  };

  const updateCartQty = async (itemId: number, quantity: number) => {
    try {
      const resp = await apiFetch<{ shop: Shop | null; items: CartItem[]; subtotal: number }>(
        `/api/cart/items/${itemId}`,
        {
          method: 'PATCH',
          body: JSON.stringify({ quantity }),
        }
      );
      setCartData(resp);
      setAppliedDiscount(null);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Could not update quantity');
    }
  };

  const applyCoupon = async () => {
    try {
      const resp = await apiFetch<{ valid: boolean; discountAmount: number; coupon: { code: string } }>(
        '/api/cart/validate-coupon',
        {
          method: 'POST',
          body: JSON.stringify({ code: couponInput, subtotal: cartData.subtotal }),
        }
      );
      setAppliedDiscount({ code: resp.coupon.code, amount: resp.discountAmount });
      pushToast('success', `Coupon ${resp.coupon.code} applied (-Rs ${resp.discountAmount}).`);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Invalid coupon');
    }
  };

  const placeOrder = async () => {
    if (!user) return onOpenAuth('login');
    setPlacingOrder(true);
    try {
      const resp = await apiFetch<{ order: OrderRecord }>('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          deliveryAddress,
          deliveryLat,
          deliveryLng,
          paymentMethod,
          couponCode: appliedDiscount?.code || undefined,
        }),
      });
      const createdOrder = resp?.order;
      setAppliedDiscount(null);
      setCouponInput('');
      await Promise.all([loadCart(), loadOrders()]);

      if (!createdOrder?.id) {
        setCartOpen(false);
        setTab('orders');
        pushToast('success', 'Order placed!');
        return;
      }

      if (paymentMethod === 'online_card') {
        setPendingGatewayOrder({
          id: createdOrder.id,
          orderNumber: createdOrder.orderNumber,
          totalAmount: createdOrder.totalAmount,
        });
      } else {
        setCartOpen(false);
        setTab('orders');
        void openOrderTracking(createdOrder.id);
        pushToast('success', `Order ${createdOrder.orderNumber} placed!`);
      }
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Checkout failed');
    } finally {
      setPlacingOrder(false);
    }
  };

  const confirmOnlinePayment = async (outcome: 'confirmed' | 'failed') => {
    if (!pendingGatewayOrder) return;
    try {
      await apiFetch('/api/payments/confirm', {
        method: 'POST',
        body: JSON.stringify({ orderId: pendingGatewayOrder.id, outcome }),
      });
      const ordId = pendingGatewayOrder.id;
      setPendingGatewayOrder(null);
      setCartOpen(false);
      setTab('orders');
      await loadOrders();
      void openOrderTracking(ordId);
      pushToast('success', 'Online payment verified and confirmed!');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Payment failed');
      setPendingGatewayOrder(null);
      await loadOrders();
    }
  };

  const openOrderTracking = async (orderId: number) => {
    setTrackedOrderId(orderId);
    setTrackingLoading(true);
    setTimeout(() => {
      trackingSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 60);
    try {
      const detail = await apiFetch<OrderDetailPayload>(`/api/orders/${orderId}`);
      if (!detail || !detail.order) return;
      setTrackedDetail(detail);
      if (
        detail.rider &&
        typeof detail.rider.lat === 'number' &&
        typeof detail.rider.lng === 'number' &&
        Number.isFinite(detail.rider.lat) &&
        Number.isFinite(detail.rider.lng)
      ) {
        setLiveRiderPos({ lat: detail.rider.lat, lng: detail.rider.lng });
      } else {
        setLiveRiderPos(null);
      }
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Unable to load order tracking');
    } finally {
      setTrackingLoading(false);
    }
  };

  const cartItemCount = cartData.items.reduce((acc, i) => acc + i.quantity, 0);
  const deliveryFee = Number(cartData.shop?.deliveryFee || 0);
  const taxEstimate = Math.round(cartData.subtotal * 0.05 * 100) / 100;
  const platformFee = cartData.items.length > 0 ? 25 : 0;
  const payableTotal = Math.max(
    0,
    cartData.subtotal + deliveryFee + taxEstimate + platformFee - (appliedDiscount?.amount || 0)
  );

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-20 md:pb-10">
      {/* Top Bar Contract: 3 Zones (Brand — 4 single-line links — Primary Action) */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 md:gap-8">
          <div className="flex items-center gap-4 min-w-0">
            <button
              type="button"
              onClick={() => {
                setTab('browse');
                setActiveShopId(null);
                setShopDetail(null);
              }}
              className="shrink-0"
            >
              <DelivooLogo />
            </button>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              type="button"
              onClick={() => {
                setTab('browse');
                setActiveShopId(null);
                setShopDetail(null);
              }}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                tab === 'browse' ? 'border-rose-600 text-slate-900' : 'border-transparent hover:text-slate-900'
              }`}
            >
              Marketplace
            </button>
            {user && (
              <>
                <button
                  type="button"
                  onClick={() => setTab('orders')}
                  className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                    tab === 'orders' ? 'border-rose-600 text-slate-900' : 'border-transparent hover:text-slate-900'
                  }`}
                >
                  My Orders
                </button>
                <button
                  type="button"
                  onClick={() => setTab('support')}
                  className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                    tab === 'support' ? 'border-rose-600 text-slate-900' : 'border-transparent hover:text-slate-900'
                  }`}
                >
                  Support
                </button>
                <button
                  type="button"
                  onClick={() => setTab('privacy')}
                  className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                    tab === 'privacy' ? 'border-rose-600 text-slate-900' : 'border-transparent hover:text-slate-900'
                  }`}
                >
                  Privacy &amp; Safety
                </button>
              </>
            )}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {user && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setNotifOpen((o) => !o);
                    void markNotificationsRead();
                  }}
                  aria-label="Notifications"
                  className="relative p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 min-h-[40px] min-w-[40px] flex items-center justify-center"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 h-4 min-w-[16px] px-1 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>
                {notifOpen && (
                  <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-200 bg-white shadow-xl p-3 z-50 max-h-80 overflow-y-auto space-y-2">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                      <span className="text-xs font-bold text-slate-900">Notifications</span>
                      <button type="button" onClick={() => setNotifOpen(false)} className="text-xs text-slate-400">
                        Close
                      </button>
                    </div>
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-500 py-4 text-center">No notifications yet.</p>
                    ) : (
                      notifications.map((n) => (
                        <div key={n.id} className="rounded-lg bg-slate-50 p-2.5 text-xs">
                          <p className="font-semibold text-slate-900">{n.title}</p>
                          <p className="text-slate-600 mt-0.5">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}

            <button
              type="button"
              onClick={() => setCartOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-sm font-semibold text-slate-900 min-h-[40px] whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="w-4 h-4 text-rose-600" />
              <span className="tabular-nums">{cartItemCount}</span>
            </button>

            {user ? (
              <button
                type="button"
                onClick={logout}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold min-h-[40px] whitespace-nowrap shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onOpenAuth('login')}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-semibold min-h-[40px] whitespace-nowrap shrink-0"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {user && <VerificationBanner />}

        {/* BROWSE TAB */}
        {tab === 'browse' && !activeShopId && (
          <div className="space-y-8">
            {/* Location & Search Toolbar */}
            <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between bg-white border border-slate-200 rounded-2xl p-3">
              <button
                type="button"
                onClick={() => setShowLocationModal(true)}
                className="flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-slate-50 text-left min-h-[44px]"
              >
                <MapPin className={`w-4 h-4 shrink-0 ${isLiveLocation ? 'text-emerald-600' : 'text-rose-600'}`} />
                <div className="min-w-0">
                  <p className="text-[11px] font-medium text-slate-500">
                    {detectingLocation
                      ? 'Detecting live location...'
                      : isLiveLocation
                      ? 'Current Live Location · Change on Map'
                      : 'Delivering to · Set Live Map'}
                  </p>
                  <p className="text-sm font-semibold text-slate-900 truncate max-w-[260px]">
                    {deliveryAddress}
                  </p>
                </div>
              </button>

              <div className="flex-1 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 min-h-[44px]">
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search restaurants, groceries, pharmacies, or items..."
                  className="w-full bg-transparent text-sm focus:outline-none text-slate-900"
                />
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  aria-label="Sort shops"
                  className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 min-h-[44px]"
                >
                  <option value="featured">Sort: Featured</option>
                  <option value="rating">Top Rated</option>
                  <option value="popular">Most Popular</option>
                  <option value="distance">Nearest First</option>
                  <option value="price_low">Lowest Price</option>
                </select>
              </div>
            </div>

            {/* Hero Banner */}
            {banners[0] && (
              <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
                <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-4">
                  <p className="text-xs font-semibold tracking-wide text-rose-600">
                    {banners[0].badgeText || 'DELIVOO Marketplace'} &middot; Live Delivery
                  </p>
                  <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 leading-tight [text-wrap:balance]">
                    {banners[0].title}
                  </h1>
                  <p className="text-sm sm:text-base text-slate-600 max-w-xl leading-relaxed">
                    {banners[0].subtitle}
                  </p>
                  {coupons.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 pt-1">
                      <span className="font-semibold text-slate-900">Active Offers:</span>
                      {coupons.slice(0, 3).map((c, idx) => (
                        <React.Fragment key={c.code}>
                          {idx > 0 && <span className="text-slate-300">&middot;</span>}
                          <span className="font-mono font-semibold text-rose-600">{c.code}</span>
                          <span>({c.title})</span>
                        </React.Fragment>
                      ))}
                    </div>
                  )}
                </div>
                <div className="lg:col-span-5 min-h-[220px] bg-slate-100">
                  {banners[0].imageUrl && (
                    <img
                      src={banners[0].imageUrl}
                      alt={banners[0].title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
              </section>
            )}

            {/* Interactive Category & Quality Tier Filter Bar */}
            <section className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="font-display text-lg font-bold text-slate-900">Categories</h2>
                <div className="flex items-center gap-1.5 overflow-x-auto">
                  {(
                    [
                      { id: 'all', label: 'All Tiers' },
                      { id: 'premium', label: 'Premium Craft' },
                      { id: 'mid', label: 'Everyday Dining' },
                      { id: 'street', label: 'Street & Value' },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelectedTier(t.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors min-h-[36px] ${
                        selectedTier === t.id
                          ? 'bg-rose-600 text-white'
                          : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pb-2">
                <button
                  type="button"
                  onClick={() => setSelectedCategory('all')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors min-h-[40px] ${
                    selectedCategory === 'all'
                      ? 'bg-slate-900 text-white'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  All Stores
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.slug)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors min-h-[40px] ${
                      selectedCategory === cat.slug
                        ? 'bg-slate-900 text-white'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </section>

            {/* Empty State when nothing matches */}
            {filteredCatalog.restaurants.length === 0 &&
              filteredCatalog.retailStores.length === 0 &&
              filteredCatalog.recommendedProducts.length === 0 && (
                <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
                  No restaurants, stores, or items match your current search or tier filter.
                </div>
              )}

            {/* SECTION 1: Restaurants (Strictly Separated from Retail Stores & Products) */}
            {filteredCatalog.restaurants.length > 0 && (
              <section className="space-y-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div>
                    <h2 className="font-display text-xl font-bold text-slate-900">
                      Restaurants &amp; Kitchens ({filteredCatalog.restaurants.length})
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Craft kitchens, casual dining, and street favorites categorized by culinary tier
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredCatalog.restaurants.map((shop) => (
                    <button
                      key={shop.id}
                      type="button"
                      onClick={() => void openShop(shop.id)}
                      className="text-left group rounded-2xl border border-slate-200 bg-white overflow-hidden hover:-translate-y-0.5 hover:shadow-md transition-all flex flex-col"
                    >
                      <div className="aspect-[4/3] w-full bg-slate-100 overflow-hidden relative">
                        {shop.bannerUrl ? (
                          <img
                            src={shop.bannerUrl}
                            alt={shop.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">
                            {shop.name}
                          </div>
                        )}
                      </div>
                      <div className="p-4 space-y-1.5 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="font-display text-base font-bold text-slate-900 truncate">
                              {shop.name}
                            </h3>
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-900 tabular-nums shrink-0">
                              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                              {shop.rating.toFixed(1)}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 truncate">
                            {shop.cuisineStyle || shop.categoryName} &middot;{' '}
                            <span
                              className={
                                shop.priceTier === 'premium'
                                  ? 'text-rose-600 font-semibold'
                                  : shop.priceTier === 'street'
                                  ? 'text-amber-700 font-semibold'
                                  : 'text-slate-700 font-semibold'
                              }
                            >
                              {shop.priceTierLabel || 'Everyday Dining'}
                            </span>{' '}
                            &middot; {shop.isOpen ? 'Open now' : 'Closed'}
                          </p>
                          <p className="text-xs text-slate-600 mt-2 line-clamp-2">{shop.description}</p>
                        </div>
                        <div className="pt-3 mt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600 tabular-nums">
                          <span className="inline-flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            {shop.estimatedTotalMins} mins &middot; {shop.distanceKm} km
                          </span>
                          <span className="font-semibold text-slate-900">
                            Rs {Number(shop.deliveryFee).toFixed(0)} delivery
                          </span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {/* SECTION 2: Recommended Items (Tier-Matched & Separated from Restaurants) */}
            {filteredCatalog.recommendedProducts.length > 0 && (
              <section className="space-y-4">
                <div>
                  <h2 className="font-display text-xl font-bold text-slate-900">
                    Recommended Items ({filteredCatalog.recommendedProducts.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Strictly matched to your active dining tier &amp; search intent so gourmet orders stay separate from street food
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {filteredCatalog.recommendedProducts.slice(0, 8).map((prod) => (
                    <div
                      key={prod.id}
                      className="rounded-2xl border border-slate-200 bg-white overflow-hidden flex flex-col justify-between"
                    >
                      <div>
                        <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                          {prod.imageUrl ? (
                            <img
                              src={prod.imageUrl}
                              alt={prod.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                              {prod.name}
                            </div>
                          )}
                        </div>
                        <div className="p-4 space-y-1">
                          <p className="text-[11px] font-medium text-slate-500 truncate">
                            {prod.shopName} &middot; {prod.priceTierLabel || 'Everyday'} &middot; {prod.unitLabel || '1 item'}
                          </p>
                          <h3 className="text-sm font-bold text-slate-900 line-clamp-1">{prod.name}</h3>
                          <p className="text-xs text-slate-600 line-clamp-2">{prod.description}</p>
                        </div>
                      </div>
                      <div className="px-4 pb-4 flex items-center justify-between gap-2">
                        <div className="tabular-nums">
                          <span className="text-sm font-bold text-slate-900">
                            Rs {Number(prod.discountedPrice || prod.price).toFixed(0)}
                          </span>
                          {prod.discountedPrice && (
                            <span className="ml-1.5 text-xs text-slate-400 line-through">
                              Rs {Number(prod.price).toFixed(0)}
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => void addToCart(prod)}
                          className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold min-h-[36px]"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* SECTION 3: Retail Stores & Essentials (Grocery, Bakery, Pharmacy, Tech) */}
            {filteredCatalog.retailStores.length > 0 && (
              <section className="space-y-4">
                <div>
                  <h2 className="font-display text-xl font-bold text-slate-900">
                    Stores &amp; Essentials ({filteredCatalog.retailStores.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Groceries, artisan bakeries, licensed pharmacies, and electronics hubs
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredCatalog.retailStores.map((shop) => (
                    <button
                      key={shop.id}
                      type="button"
                      onClick={() => void openShop(shop.id)}
                      className="text-left group rounded-2xl border border-slate-200 bg-white overflow-hidden hover:-translate-y-0.5 hover:shadow-md transition-all flex flex-col"
                    >
                      <div className="aspect-[4/3] w-full bg-slate-100 overflow-hidden relative">
                        {shop.bannerUrl ? (
                          <img
                            src={shop.bannerUrl}
                            alt={shop.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">
                            {shop.name}
                          </div>
                        )}
                      </div>
                      <div className="p-4 space-y-1.5 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="font-display text-base font-bold text-slate-900 truncate">
                              {shop.name}
                            </h3>
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-900 tabular-nums shrink-0">
                              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                              {shop.rating.toFixed(1)}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 truncate">
                            {shop.categoryName} &middot; {shop.priceTierLabel || 'Curated'} &middot; {shop.isOpen ? 'Open now' : 'Closed'}
                          </p>
                          <p className="text-xs text-slate-600 mt-2 line-clamp-2">{shop.description}</p>
                        </div>
                        <div className="pt-3 mt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600 tabular-nums">
                          <span className="inline-flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            {shop.estimatedTotalMins} mins &middot; {shop.distanceKm} km
                          </span>
                          <span className="font-semibold text-slate-900">
                            Rs {Number(shop.deliveryFee).toFixed(0)} delivery
                          </span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}

        {/* SHOP DETAIL VIEW */}
        {tab === 'browse' && activeShopId && shopDetail && (
          <div className="space-y-6">
            <button
              type="button"
              onClick={() => {
                setActiveShopId(null);
                setShopDetail(null);
              }}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-700 hover:text-slate-900 min-h-[40px]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>All Stores</span>
            </button>

            <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 md:grid-cols-12">
              <div className="md:col-span-4 aspect-[4/3] md:aspect-auto bg-slate-100">
                {shopDetail.shop.bannerUrl && (
                  <img
                    src={shopDetail.shop.bannerUrl}
                    alt={shopDetail.shop.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
              <div className="md:col-span-8 p-6 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h1 className="font-display text-2xl font-bold text-slate-900">
                      {shopDetail.shop.name}
                    </h1>
                    {(shopDetail.shop.cuisineStyle || shopDetail.shop.priceTierLabel) && (
                      <p className="text-xs font-semibold text-rose-600 mt-0.5">
                        {shopDetail.shop.cuisineStyle || shopDetail.shop.categoryName} &middot; {shopDetail.shop.priceTierLabel}
                      </p>
                    )}
                  </div>
                  <span className="inline-flex items-center gap-1 text-sm font-bold text-slate-900 tabular-nums">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    {shopDetail.shop.rating.toFixed(1)} ({shopDetail.shop.totalReviews} reviews)
                  </span>
                </div>
                <p className="text-sm text-slate-600">{shopDetail.shop.description}</p>
                <div className="text-xs text-slate-500 flex flex-wrap gap-2 pt-1">
                  <span>{shopDetail.shop.address}</span>
                  <span>&middot;</span>
                  <span>Hours: {shopDetail.shop.openingHours}</span>
                  <span>&middot;</span>
                  <span className="tabular-nums">Delivery Rs {Number(shopDetail.shop.deliveryFee).toFixed(0)}</span>
                  <span>&middot;</span>
                  <span>Prep ~{shopDetail.shop.estimatedPrepMins} mins</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {shopDetail.products.map((prod) => (
                <div
                  key={prod.id}
                  className="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-2.5">
                    <div className="aspect-[4/3] rounded-xl bg-slate-100 overflow-hidden">
                      {prod.imageUrl && (
                        <img
                          src={prod.imageUrl}
                          alt={prod.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-base font-bold text-slate-900">{prod.name}</h3>
                        <span className="text-xs font-medium text-slate-500 shrink-0">
                          {prod.inStock ? `${prod.stockQuantity} left` : 'Out of stock'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">{prod.description}</p>
                      {(prod.freshnessInfo || prod.expiryDate || prod.manufacturingDate) && (
                        <p className="text-[11px] text-emerald-700 mt-1.5">
                          {[
                            prod.freshnessInfo,
                            prod.manufacturingDate ? `Mfg: ${prod.manufacturingDate}` : '',
                            prod.expiryDate ? `Exp: ${prod.expiryDate}` : '',
                          ]
                            .filter(Boolean)
                            .join(' · ')}
                        </p>
                      )}
                    </div>

                    {prod.variants && prod.variants.length > 0 && (
                      <div className="pt-1">
                        <select
                          value={variantChoice[prod.id] || prod.variants[0].name}
                          onChange={(e) =>
                            setVariantChoice((prev) => ({ ...prev, [prod.id]: e.target.value }))
                          }
                          className="w-full rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs bg-white"
                        >
                          {prod.variants.map((v) => (
                            <option key={v.name} value={v.name}>
                              {v.name} {v.priceDelta !== 0 ? `(${v.priceDelta > 0 ? '+' : ''}Rs ${v.priceDelta})` : ''}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                    <div className="tabular-nums">
                      <span className="text-base font-bold text-slate-900">
                        Rs {Number(prod.discountedPrice || prod.price).toFixed(0)}
                      </span>
                      {prod.discountedPrice && (
                        <span className="ml-1.5 text-xs text-slate-400 line-through">
                          Rs {Number(prod.price).toFixed(0)}
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      disabled={!prod.inStock}
                      onClick={() => void addToCart(prod)}
                      className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold disabled:opacity-40 min-h-[40px]"
                    >
                      {prod.inStock ? 'Add to Cart' : 'Unavailable'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {shopDetail.similarShops && shopDetail.similarShops.length > 0 && (
              <div className="space-y-3 pt-2">
                <h3 className="font-display text-lg font-bold text-slate-900">
                  Similar {shopDetail.shop.priceTierLabel || 'Matching'} Spots
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {shopDetail.similarShops.map((peer) => (
                    <button
                      key={peer.id}
                      type="button"
                      onClick={() => void openShop(peer.id)}
                      className="text-left rounded-xl border border-slate-200 bg-white p-4 hover:border-rose-400 transition-colors flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="font-display text-sm font-bold text-slate-900 truncate">{peer.name}</p>
                        <p className="text-xs text-slate-500 truncate mt-0.5">
                          {peer.cuisineStyle || peer.categoryName} &middot; {peer.priceTierLabel}
                        </p>
                      </div>
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-900 tabular-nums shrink-0">
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        {peer.rating.toFixed(1)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {shopDetail.reviews.length > 0 && (
              <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
                <h3 className="font-display text-lg font-bold text-slate-900">Customer Reviews</h3>
                <div className="divide-y divide-slate-100">
                  {shopDetail.reviews.map((r) => (
                    <div key={r.id} className="py-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-900">{r.customerName}</span>
                        <span className="text-xs font-semibold text-amber-600 tabular-nums">
                          {r.shopRating} / 5 Stars
                        </span>
                      </div>
                      {r.comment && <p className="text-xs text-slate-600 mt-1">{r.comment}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ORDERS & LIVE TRACKING TAB */}
        {tab === 'orders' && user && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 space-y-4">
              <h2 className="font-display text-2xl font-bold text-slate-900">Your Orders</h2>
              {orders.length === 0 ? (
                <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
                  You have not placed any orders yet.
                </div>
              ) : (
                orders.map((ord) => (
                  <div
                    key={ord.id}
                    className={`rounded-2xl border bg-white p-5 space-y-3 transition-colors ${
                      trackedOrderId === ord.id ? 'border-rose-500' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="font-mono text-xs font-semibold text-slate-500">
                          {ord.orderNumber}
                        </p>
                        <h3 className="font-display text-base font-bold text-slate-900">
                          {ord.shopName}
                        </h3>
                      </div>
                      <span className="text-xs font-semibold text-rose-700 capitalize">
                        {ord.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 space-y-1">
                      {(ord.items || []).map((item, i) => (
                        <p key={i}>
                          {item.quantity}x {item.productName} ({item.variantLabel})
                        </p>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 text-xs">
                      <span className="font-bold text-slate-900 tabular-nums">
                        Total: Rs {Number(ord.totalAmount).toFixed(0)} &middot; {ord.paymentMethod.toUpperCase()} ({ord.paymentStatus})
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void openOrderTracking(ord.id)}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 text-white font-semibold"
                        >
                          Track &amp; Timeline
                        </button>
                        {['placed', 'accepted'].includes(ord.status) && (
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await apiFetch(`/api/orders/${ord.id}/cancel`, {
                                  method: 'POST',
                                  body: JSON.stringify({ reason: 'Cancelled by customer' }),
                                });
                                await loadOrders();
                                pushToast('info', 'Order cancelled.');
                              } catch (err) {
                                pushToast('error', err instanceof Error ? err.message : 'Cannot cancel');
                              }
                            }}
                            className="px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 font-semibold"
                          >
                            Cancel
                          </button>
                        )}
                        {ord.status === 'delivered' && (
                          <>
                            <button
                              type="button"
                              onClick={async () => {
                                await apiFetch(`/api/orders/${ord.id}/reorder`, { method: 'POST' });
                                await loadCart();
                                setCartOpen(true);
                              }}
                              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 font-semibold inline-flex items-center gap-1"
                            >
                              <RotateCcw className="w-3 h-3" />
                              Reorder
                            </button>
                            <button
                              type="button"
                              onClick={() => setReviewOrderId(ord.id)}
                              className="px-3 py-1.5 rounded-lg border border-amber-300 text-amber-800 font-semibold"
                            >
                              Rate
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div ref={trackingSectionRef} className="lg:col-span-6">
              {trackingLoading && (!trackedDetail || trackedDetail.order?.id !== trackedOrderId) ? (
                <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center space-y-2">
                  <Loader2 className="w-5 h-5 animate-spin text-rose-600 mx-auto" />
                  <p className="text-sm font-semibold text-slate-800">Loading live tracking &amp; timeline...</p>
                </div>
              ) : trackedDetail && trackedDetail.order ? (
                (() => {
                  const safeShopLat =
                    typeof trackedDetail.shop?.lat === 'number' && Number.isFinite(trackedDetail.shop.lat)
                      ? trackedDetail.shop.lat
                      : typeof trackedDetail.order.shopLat === 'number' && Number.isFinite(trackedDetail.order.shopLat)
                      ? trackedDetail.order.shopLat
                      : 24.8615;
                  const safeShopLng =
                    typeof trackedDetail.shop?.lng === 'number' && Number.isFinite(trackedDetail.shop.lng)
                      ? trackedDetail.shop.lng
                      : typeof trackedDetail.order.shopLng === 'number' && Number.isFinite(trackedDetail.order.shopLng)
                      ? trackedDetail.order.shopLng
                      : 67.0099;
                  const safeCustLat =
                    typeof trackedDetail.order.deliveryLat === 'number' && Number.isFinite(trackedDetail.order.deliveryLat)
                      ? trackedDetail.order.deliveryLat
                      : deliveryLat;
                  const safeCustLng =
                    typeof trackedDetail.order.deliveryLng === 'number' && Number.isFinite(trackedDetail.order.deliveryLng)
                      ? trackedDetail.order.deliveryLng
                      : deliveryLng;

                  const milestoneSteps = [
                    { key: 'placed', label: 'Placed' },
                    { key: 'accepted', label: 'Accepted' },
                    { key: 'preparing', label: 'Preparing' },
                    { key: 'rider_assigned', label: 'Rider Assigned' },
                    { key: 'on_the_way', label: 'On the Way' },
                    { key: 'delivered', label: 'Delivered' },
                  ];
                  const normalizedStatus =
                    trackedDetail.order.status === 'ready_for_pickup'
                      ? 'preparing'
                      : trackedDetail.order.status === 'picked_up'
                      ? 'on_the_way'
                      : trackedDetail.order.status;
                  const currentStepIdx = milestoneSteps.findIndex((s) => s.key === normalizedStatus);

                  return (
                    <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-mono text-xs text-slate-500">{trackedDetail.order.orderNumber}</p>
                          <h3 className="font-display text-lg font-bold text-slate-900">
                            Live Tracking &amp; Status
                          </h3>
                        </div>
                        <span className="text-xs font-semibold text-emerald-700 capitalize">
                          {trackedDetail.order.status.replace(/_/g, ' ')}
                        </span>
                      </div>

                      {trackedDetail.order.status !== 'cancelled' && trackedDetail.order.status !== 'rejected' && (
                        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-1">
                          {milestoneSteps.map((step, idx) => {
                            const done = currentStepIdx >= idx;
                            return (
                              <div key={step.key} className="space-y-1">
                                <div className={`h-1.5 rounded-full ${done ? 'bg-emerald-600' : 'bg-slate-200'}`} />
                                <p className={`text-[10px] font-semibold truncate ${done ? 'text-slate-900' : 'text-slate-400'}`}>
                                  {step.label}
                                </p>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      <MapErrorBoundary key={trackedDetail.order.id}>
                        <DeliveryMap
                          center={[safeShopLat, safeShopLng]}
                          markers={[
                            {
                              lat: safeShopLat,
                              lng: safeShopLng,
                              label: trackedDetail.shop?.name || trackedDetail.order.shopName || 'Pickup Shop',
                              kind: 'shop',
                            },
                            {
                              lat: safeCustLat,
                              lng: safeCustLng,
                              label: 'Delivery Drop-off',
                              kind: 'customer',
                            },
                            ...(liveRiderPos
                              ? [
                                  {
                                    lat: liveRiderPos.lat,
                                    lng: liveRiderPos.lng,
                                    label: `Rider: ${trackedDetail.rider?.fullName || 'Live Rider'}`,
                                    kind: 'rider' as const,
                                  },
                                ]
                              : []),
                          ]}
                          routePoints={[
                            [safeShopLat, safeShopLng],
                            ...(liveRiderPos ? [[liveRiderPos.lat, liveRiderPos.lng] as [number, number]] : []),
                            [safeCustLat, safeCustLng],
                          ]}
                          heightClass="h-56"
                        />
                      </MapErrorBoundary>

                      {trackedDetail.rider && (
                        <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-bold text-slate-900">
                              Rider: {trackedDetail.rider.fullName}
                            </p>
                            <p className="text-slate-600 mt-0.5">
                              {trackedDetail.rider.vehicleType} &middot; {trackedDetail.rider.phone}
                            </p>
                          </div>
                          <span className="font-semibold text-slate-900 tabular-nums">
                            {Number(trackedDetail.rider.rating ?? 5).toFixed(1)} &#9733;
                          </span>
                        </div>
                      )}

                      <div className="space-y-3">
                        <h4 className="text-xs font-bold text-slate-700">Order Timeline</h4>
                        <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                          {(trackedDetail.events || []).map((ev) => (
                            <div key={ev.id} className="flex items-start gap-2.5 text-xs">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                              <div>
                                <p className="font-semibold text-slate-900 capitalize">
                                  {ev.status.replace(/_/g, ' ')}
                                  <span className="font-normal text-slate-400">
                                    {' '}
                                    &middot; {new Date(ev.createdAt).toLocaleTimeString()}
                                  </span>
                                </p>
                                {ev.notes && <p className="text-slate-600">{ev.notes}</p>}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
                  Select an order to inspect live map tracking and status history.
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUPPORT TAB */}
        {tab === 'support' && user && (
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="font-display text-2xl font-bold text-slate-900">Customer Support</h2>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await apiFetch('/api/support/tickets', {
                    method: 'POST',
                    body: JSON.stringify({
                      category: 'complaint',
                      subject: ticketSubject,
                      description: ticketDesc,
                    }),
                  });
                  setTicketSubject('');
                  setTicketDesc('');
                  const r = await apiFetch<{ tickets: typeof tickets }>('/api/support/tickets');
                  setTickets(r.tickets || []);
                  pushToast('success', 'Support ticket submitted.');
                } catch (err) {
                  pushToast('error', err instanceof Error ? err.message : 'Failed to submit ticket');
                }
              }}
              className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4"
            >
              <h3 className="text-base font-bold text-slate-900">Open a Support Ticket</h3>
              <input
                type="text"
                required
                value={ticketSubject}
                onChange={(e) => setTicketSubject(e.target.value)}
                placeholder="Subject (e.g. Missing item or refund inquiry)"
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
              />
              <textarea
                required
                rows={3}
                value={ticketDesc}
                onChange={(e) => setTicketDesc(e.target.value)}
                placeholder="Describe your issue..."
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-rose-600 text-white text-sm font-semibold hover:bg-rose-700"
              >
                Submit Ticket
              </button>
            </form>

            <div className="space-y-3">
              {tickets.map((t) => (
                <div key={t.id} className="rounded-xl border border-slate-200 bg-white p-4 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900">{t.subject}</span>
                    <span className="text-xs font-semibold text-slate-600 capitalize">{t.status}</span>
                  </div>
                  {t.resolutionNotes && (
                    <p className="text-xs text-emerald-700 mt-1.5">Resolution: {t.resolutionNotes}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* PRIVACY & SAFETY TAB */}
        {tab === 'privacy' && user && <PrivacySafetyPanel />}
      </main>

      <footer className="max-w-7xl mx-auto px-4 sm:px-6 pt-10 pb-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 border-t border-slate-200 mt-10">
        <p>DELIVOO Multi-Vendor Local Delivery Marketplace</p>
        {!user && (
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => onOpenAuth('login')}
              className="hover:text-slate-900 font-medium"
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('admin')}
              className="inline-flex items-center gap-1.5 font-semibold text-slate-700 hover:text-rose-600"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Portal</span>
            </button>
          </div>
        )}
      </footer>

      {/* Mobile Android-style Thumb-Zone Bottom Bar (<= 15% viewport height) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200 h-16 grid grid-cols-4 items-center">
        <button
          type="button"
          onClick={() => setTab('browse')}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'browse' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Home</span>
        </button>
        <button
          type="button"
          onClick={() => (user ? setTab('orders') : onOpenAuth('login'))}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'orders' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <Receipt className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Orders</span>
        </button>
        <button
          type="button"
          onClick={() => (user ? setTab('support') : onOpenAuth('login'))}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'support' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <LifeBuoy className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Support</span>
        </button>
        <button
          type="button"
          onClick={() => (user ? setTab('privacy') : onOpenAuth('login'))}
          className={`flex flex-col items-center justify-center h-full ${
            tab === 'privacy' ? 'text-rose-600' : 'text-slate-500'
          }`}
        >
          <Shield className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Privacy</span>
        </button>
      </nav>

      {/* Cart & Checkout Slide-Over Drawer */}
      {cartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-display text-lg font-bold text-slate-900">Your Bag</h3>
                {cartData.shop && <p className="text-xs text-slate-500">{cartData.shop.name}</p>}
              </div>
              <button type="button" onClick={() => setCartOpen(false)} className="p-2 rounded-lg hover:bg-slate-100">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {pendingGatewayOrder ? (
                <div className="rounded-2xl border border-slate-200 p-5 space-y-4 bg-slate-50">
                  <h4 className="font-display text-base font-bold text-slate-900">
                    Online Payment Gateway Verification
                  </h4>
                  <p className="text-xs text-slate-600">
                    Order <strong>{pendingGatewayOrder.orderNumber}</strong> &middot; Amount:{' '}
                    <strong className="tabular-nums">Rs {pendingGatewayOrder.totalAmount}</strong>. Payment status remains pending until confirmed by the gateway.
                  </p>
                  <div className="flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() => void confirmOnlinePayment('confirmed')}
                      className="w-full py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
                    >
                      Authorize &amp; Confirm Payment
                    </button>
                    <button
                      type="button"
                      onClick={() => void confirmOnlinePayment('failed')}
                      className="w-full py-2.5 rounded-xl border border-rose-200 bg-white text-rose-700 text-sm font-semibold hover:bg-rose-50"
                    >
                      Simulate Gateway Decline
                    </button>
                  </div>
                </div>
              ) : cartData.items.length === 0 ? (
                <div className="py-16 text-center text-sm text-slate-500">
                  Your bag is empty. Browse stores to add items.
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    {cartData.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-3"
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-slate-900 truncate">{item.productName}</p>
                          <p className="text-xs text-slate-500">
                            {item.selectedVariant} &middot; Rs {Number(item.unitPrice).toFixed(0)}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => void updateCartQty(item.id, item.quantity - 1)}
                            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50"
                          >
                            {item.quantity === 1 ? <Trash2 className="w-3.5 h-3.5 text-rose-600" /> : <Minus className="w-3.5 h-3.5" />}
                          </button>
                          <span className="w-6 text-center text-xs font-bold tabular-nums">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => void updateCartQty(item.id, item.quantity + 1)}
                            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Coupon */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="Promo code (e.g. WELCOME20)"
                      className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-xs font-mono uppercase"
                    />
                    <button
                      type="button"
                      onClick={() => void applyCoupon()}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                    >
                      Apply
                    </button>
                  </div>

                  {/* Address */}
                  <div className="rounded-xl border border-slate-200 p-3 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">Delivery Address</span>
                      <button
                        type="button"
                        onClick={() => setShowLocationModal(true)}
                        className="text-xs text-rose-600 font-semibold"
                      >
                        Change
                      </button>
                    </div>
                    <p className="text-xs text-slate-600">{deliveryAddress}</p>
                  </div>

                  {/* Payment Method */}
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-slate-700">Payment Method</p>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('cod')}
                        className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-semibold ${
                          paymentMethod === 'cod'
                            ? 'border-rose-600 bg-rose-50 text-rose-700'
                            : 'border-slate-200 text-slate-700'
                        }`}
                      >
                        <Banknote className="w-4 h-4" />
                        Cash on Delivery
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('online_card')}
                        className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-semibold ${
                          paymentMethod === 'online_card'
                            ? 'border-rose-600 bg-rose-50 text-rose-700'
                            : 'border-slate-200 text-slate-700'
                        }`}
                      >
                        <CreditCard className="w-4 h-4" />
                        Online Gateway
                      </button>
                    </div>
                  </div>

                  {/* Totals */}
                  <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 space-y-2 text-xs tabular-nums">
                    <div className="flex justify-between text-slate-600">
                      <span>Subtotal</span>
                      <span>Rs {cartData.subtotal.toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Delivery Fee</span>
                      <span>Rs {deliveryFee.toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Tax (5%)</span>
                      <span>Rs {taxEstimate.toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Platform Service Fee</span>
                      <span>Rs {platformFee}</span>
                    </div>
                    {appliedDiscount && (
                      <div className="flex justify-between text-emerald-700 font-semibold">
                        <span>Discount ({appliedDiscount.code})</span>
                        <span>-Rs {appliedDiscount.amount.toFixed(0)}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-bold text-slate-900">
                      <span>Total Payable</span>
                      <span>Rs {payableTotal.toFixed(0)}</span>
                    </div>
                  </div>
                </>
              )}
            </div>

            {cartData.items.length > 0 && !pendingGatewayOrder && (
              <div className="p-4 border-t border-slate-200">
                <button
                  type="button"
                  disabled={placingOrder}
                  onClick={() => void placeOrder()}
                  className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold disabled:opacity-50 min-h-[44px]"
                >
                  {placingOrder ? 'Placing Order...' : `Place Order · Rs ${payableTotal.toFixed(0)}`}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Full Interactive Map Location Picker Modal */}
      {showLocationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-2 sm:p-4">
          <div className="w-full max-w-5xl h-[92vh] sm:h-[88vh] rounded-2xl bg-white border border-slate-200 p-4 sm:p-6 flex flex-col gap-3 shadow-2xl overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 shrink-0">
              <div>
                <h3 className="font-display text-lg font-bold text-slate-900">
                  Set Your Live Delivery Location
                </h3>
                <p className="text-xs text-slate-500">
                  Use current GPS, search an address, or click &amp; drag the pin anywhere on the map
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={detectingLocation}
                  onClick={() => detectCurrentLiveLocation(false)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold min-h-[40px] disabled:opacity-60"
                >
                  {detectingLocation ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <LocateFixed className="w-3.5 h-3.5" />
                  )}
                  <span>{detectingLocation ? 'Locating...' : 'Use Current Live Location'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowLocationModal(false)}
                  aria-label="Close location map"
                  className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 min-h-[40px] min-w-[40px] flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Map Search Bar */}
            <div className="relative shrink-0">
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                  <Search className="w-4 h-4 text-slate-400 shrink-0" />
                  <input
                    type="text"
                    value={locationSearchQuery}
                    onChange={(e) => setLocationSearchQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        void searchMapLocation();
                      }
                    }}
                    placeholder="Search street, area, landmark, or city..."
                    className="w-full bg-transparent text-xs sm:text-sm focus:outline-none text-slate-900"
                  />
                </div>
                <button
                  type="button"
                  disabled={searchingLocation}
                  onClick={() => void searchMapLocation()}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shrink-0"
                >
                  {searchingLocation ? 'Searching...' : 'Find'}
                </button>
              </div>

              {locationSearchResults.length > 0 && (
                <div className="absolute left-0 right-0 mt-1 rounded-xl border border-slate-200 bg-white shadow-xl z-[500] max-h-48 overflow-y-auto divide-y divide-slate-100">
                  {locationSearchResults.map((item, idx) => (
                    <button
                      key={`${item.lat}-${item.lon}-${idx}`}
                      type="button"
                      onClick={() => {
                        const lat = Math.round(Number(item.lat) * 100000) / 100000;
                        const lng = Math.round(Number(item.lon) * 100000) / 100000;
                        const shortLabel = item.display_name.split(',').slice(0, 3).join(',').trim();
                        setDeliveryLat(lat);
                        setDeliveryLng(lng);
                        setDeliveryAddress(shortLabel);
                        setNewStreet(item.display_name.split(',')[0]?.trim() || '');
                        setNewArea(item.display_name.split(',').slice(1, 3).join(',').trim() || '');
                        setIsLiveLocation(false);
                        setLocationSearchResults([]);
                      }}
                      className="w-full text-left px-3 py-2.5 text-xs text-slate-700 hover:bg-rose-50 hover:text-slate-900"
                    >
                      {item.display_name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {savedAddresses.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 shrink-0">
                <span className="text-[11px] font-semibold text-slate-500 shrink-0">Saved:</span>
                {savedAddresses.map((addr) => (
                  <button
                    key={addr.id}
                    type="button"
                    onClick={() => {
                      setDeliveryAddress(`${addr.streetAddress}, ${addr.area}`);
                      setDeliveryLat(addr.lat);
                      setDeliveryLng(addr.lng);
                      setNewStreet(addr.streetAddress);
                      setNewArea(addr.area);
                      setIsLiveLocation(false);
                    }}
                    className="rounded-xl border border-slate-200 bg-slate-50 hover:border-rose-400 px-3 py-1.5 text-xs text-left whitespace-nowrap shrink-0"
                  >
                    <span className="font-bold text-slate-900">{addr.label}:</span>{' '}
                    <span className="text-slate-600">{addr.streetAddress}, {addr.area}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Full Interactive Map */}
            <div className="flex-1 min-h-[280px] flex flex-col">
              <DeliveryMap
                center={[deliveryLat, deliveryLng]}
                zoom={15}
                markers={[
                  ...shops.map((s) => ({ lat: s.lat, lng: s.lng, label: s.name, kind: 'shop' as const })),
                  { lat: deliveryLat, lng: deliveryLng, label: deliveryAddress, kind: 'pin' as const },
                ]}
                interactivePick
                onPickLocation={(lat, lng) => {
                  setIsLiveLocation(false);
                  void reverseGeocodeLocation(lat, lng, false);
                }}
                heightClass="h-full min-h-[280px]"
              />
            </div>

            {/* Bottom Address Confirmation Bar */}
            <div className="shrink-0 pt-1 space-y-2 border-t border-slate-100">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  value={newStreet}
                  onChange={(e) => setNewStreet(e.target.value)}
                  placeholder="Street / House / Flat"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  value={newArea}
                  onChange={(e) => setNewArea(e.target.value)}
                  placeholder="Area / Block / City"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-xs"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-[11px] font-mono text-slate-500 tabular-nums">
                  {isLiveLocation ? 'Live GPS' : 'Map Pin'} &middot; {deliveryLat.toFixed(5)}, {deliveryLng.toFixed(5)}
                </p>
                <button
                  type="button"
                  onClick={async () => {
                    const full =
                      [newStreet, newArea].filter(Boolean).join(', ') ||
                      deliveryAddress ||
                      `Pin (${deliveryLat.toFixed(4)}, ${deliveryLng.toFixed(4)})`;
                    setDeliveryAddress(full);
                    if (user && newStreet && newArea) {
                      try {
                        const r = await apiFetch<{ address: typeof savedAddresses[0] }>('/api/addresses', {
                          method: 'POST',
                          body: JSON.stringify({
                            label: isLiveLocation ? 'Live Location' : 'Saved Pin',
                            streetAddress: newStreet,
                            area: newArea,
                            lat: deliveryLat,
                            lng: deliveryLng,
                          }),
                        });
                        setSavedAddresses((prev) => [r.address, ...prev]);
                      } catch {
                        // Ignore
                      }
                    }
                    setShowLocationModal(false);
                    pushToast('success', `Delivery location set to ${full}`);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold min-h-[40px]"
                >
                  Confirm Delivery Location
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Rating & Review Modal */}
      {reviewOrderId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 space-y-4 shadow-2xl">
            <h3 className="font-display text-lg font-bold text-slate-900">Rate Your Experience</h3>
            <div className="space-y-3 text-sm">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Shop Rating (1-5)</label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  value={shopStars}
                  onChange={(e) => setShopStars(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Rider Rating (1-5)</label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  value={riderStars}
                  onChange={(e) => setRiderStars(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>
              <textarea
                rows={3}
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="Write a review..."
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReviewOrderId(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  try {
                    await apiFetch(`/api/orders/${reviewOrderId}/review`, {
                      method: 'POST',
                      body: JSON.stringify({
                        shopRating: shopStars,
                        riderRating: riderStars,
                        comment: reviewComment,
                      }),
                    });
                    setReviewOrderId(null);
                    setReviewComment('');
                    pushToast('success', 'Thank you for your review!');
                  } catch (err) {
                    pushToast('error', err instanceof Error ? err.message : 'Review failed');
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold"
              >
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Switch Store Confirmation Modal */}
      {switchShopProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-200 p-6 space-y-4 shadow-2xl">
            <h3 className="font-display text-lg font-bold text-slate-900">Start a new basket?</h3>
            <p className="text-sm text-slate-600">
              Your cart currently contains items from <span className="font-semibold text-slate-900">{cartData.shop?.name || 'another store'}</span>. Replace your cart with <span className="font-semibold text-slate-900">{switchShopProduct.name}</span>?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSwitchShopProduct(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Keep Current Bag
              </button>
              <button
                type="button"
                onClick={async () => {
                  const target = switchShopProduct;
                  setSwitchShopProduct(null);
                  await addToCart(target, true);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
              >
                Replace Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
