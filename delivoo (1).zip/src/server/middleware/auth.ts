import type { Request, Response, NextFunction } from 'express';
import { eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { users } from '../../db/schema.ts';
import { verifyAuthToken } from '../security.ts';

export interface AuthUser {
  id: number;
  uid: string;
  email: string;
  fullName: string;
  phone: string;
  role: 'customer' | 'shopkeeper' | 'rider' | 'admin';
  adminTier?: 'main' | 'sub' | null;
  accountStatus: string;
  emailVerified: boolean;
  phoneVerified: boolean;
}

export interface AuthedRequest extends Request {
  authUser?: AuthUser;
}

export function parseCookieValue(cookieHeader: string | undefined, name: string): string | null {
  if (!cookieHeader) return null;
  const parts = cookieHeader.split(';');
  for (const part of parts) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    if (key === name) {
      try {
        return decodeURIComponent(part.slice(idx + 1).trim());
      } catch {
        return part.slice(idx + 1).trim();
      }
    }
  }
  return null;
}

export function extractAuthToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (header && header.startsWith('Bearer ')) {
    const bearer = header.slice(7).trim();
    if (bearer) return bearer;
  }
  return parseCookieValue(req.headers.cookie, 'delivoo_session');
}

export async function optionalAuth(req: AuthedRequest, _res: Response, next: NextFunction) {
  const token = extractAuthToken(req);
  if (!token) {
    return next();
  }
  const decoded = verifyAuthToken(token);
  if (!decoded) {
    return next();
  }
  try {
    const [u] = await db.select().from(users).where(eq(users.id, decoded.userId));
    if (u && u.accountStatus !== 'deleted' && u.accountStatus !== 'suspended') {
      req.authUser = {
        id: u.id,
        uid: u.uid,
        email: u.email,
        fullName: u.fullName,
        phone: u.phone,
        role: u.role as AuthUser['role'],
        adminTier: (u.adminTier as AuthUser['adminTier']) ?? null,
        accountStatus: u.accountStatus,
        emailVerified: u.emailVerified,
        phoneVerified: u.phoneVerified,
      };
    }
  } catch {
    // Ignore optional auth failure
  }
  next();
}

export async function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const token = extractAuthToken(req);
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const decoded = verifyAuthToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }
  try {
    const [u] = await db.select().from(users).where(eq(users.id, decoded.userId));
    if (!u) {
      return res.status(401).json({ error: 'Account not found' });
    }
    if (u.accountStatus === 'deleted') {
      return res.status(403).json({ error: 'This account has been deleted' });
    }
    if (u.accountStatus === 'suspended') {
      return res.status(403).json({ error: 'This account is currently suspended. Contact support.' });
    }
    req.authUser = {
      id: u.id,
      uid: u.uid,
      email: u.email,
      fullName: u.fullName,
      phone: u.phone,
      role: u.role as AuthUser['role'],
      adminTier: (u.adminTier as AuthUser['adminTier']) ?? null,
      accountStatus: u.accountStatus,
      emailVerified: u.emailVerified,
      phoneVerified: u.phoneVerified,
    };
    next();
  } catch (error) {
    console.error('Auth lookup error:', error);
    return res.status(500).json({ error: 'Authentication verification failed' });
  }
}

export function requireRole(...roles: Array<AuthUser['role']>) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    if (!req.authUser) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    if (!roles.includes(req.authUser.role)) {
      return res.status(403).json({ error: 'You do not have permission to access this resource' });
    }
    next();
  };
}
