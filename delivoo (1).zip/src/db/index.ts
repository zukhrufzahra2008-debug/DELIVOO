import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema.ts';

declare global {
  var _postgresPool: Pool | undefined;
}

export const createPool = () => {
  if (!global._postgresPool) {
    global._postgresPool = new Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME,
      max: 15,
      connectionTimeoutMillis: 15000,
    });

    global._postgresPool.on('error', (err) => {
      console.error('Unexpected error on idle SQL pool client:', err);
    });
  }
  return global._postgresPool;
};

const pool = createPool();
export const db = drizzle(pool, { schema });

let adminColsEnsured = false;

export async function ensureAdminHierarchyColumns(): Promise<void> {
  if (adminColsEnsured) return;
  try {
    await pool.query(`
      UPDATE users
      SET admin_tier = 'main'
      WHERE id = (
        SELECT id FROM users
        WHERE role = 'admin' AND account_status != 'deleted'
        ORDER BY id ASC
        LIMIT 1
      )
      AND NOT EXISTS (
        SELECT 1 FROM users
        WHERE role = 'admin' AND admin_tier = 'main' AND account_status != 'deleted'
      );
    `);
    adminColsEnsured = true;
  } catch (err) {
    console.error('Failed to backfill admin hierarchy tier:', err);
  }
}

