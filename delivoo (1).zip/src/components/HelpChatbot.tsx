import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, Loader2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
}

const STARTER_PROMPTS = [
  'How do I track my active order?',
  'How do shop commissions & payouts work?',
  'How do I register as a rider?',
  'Where can I manage Privacy & delete my account?',
];

export const HelpChatbot: React.FC = () => {
  const { apiFetch, user } = useApp();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      text: `Hello${user ? ` ${user.fullName.split(' ')[0]}` : ''}! I am the DELIVOO Help Assistant. Ask me about orders, deliveries, shop onboarding, rider verification, payments, or privacy settings.`,
    },
  ]);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  const sendMessage = async (textToSend?: string) => {
    const query = (textToSend ?? input).trim();
    if (!query || loading) return;

    setErrorMsg(null);
    const nextHistory = [...messages, { role: 'user' as const, text: query }];
    setMessages(nextHistory);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const resp = await apiFetch<{ reply: string }>('/api/ai/help-chat', {
        method: 'POST',
        body: JSON.stringify({
          message: query,
          history: messages,
        }),
      });
      setMessages((prev) => [...prev, { role: 'assistant', text: resp.reply }]);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to reach Help Assistant');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label="Open DELIVOO Help Assistant"
        className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-40 inline-flex items-center gap-2 rounded-full bg-slate-900 hover:bg-slate-800 text-white px-4 py-3 shadow-lg shadow-slate-900/20 transition-transform active:scale-95 min-h-[44px]"
      >
        {open ? <X className="w-4 h-4" /> : <MessageCircle className="w-4 h-4 text-rose-400" />}
        <span className="text-sm font-medium whitespace-nowrap">Help Chat</span>
      </button>

      {open && (
        <div className="fixed bottom-36 md:bottom-20 right-4 md:right-6 z-40 w-[calc(100vw-2rem)] max-w-sm rounded-2xl border border-slate-200 bg-white shadow-2xl flex flex-col overflow-hidden max-h-[70vh]">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-900 text-white">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-rose-400" />
              <div>
                <h3 className="text-sm font-semibold">DELIVOO Help Assistant</h3>
                <p className="text-[11px] text-slate-300">Instant marketplace & order support</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white"
              aria-label="Close help chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#FAFAFA]">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-rose-600 text-white rounded-br-sm'
                      : 'bg-white border border-slate-200 text-slate-800 rounded-bl-sm'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}

            {messages.length <= 2 && (
              <div className="pt-2 space-y-1.5">
                <p className="text-[11px] font-medium text-slate-500">Suggested questions</p>
                <div className="flex flex-wrap gap-1.5">
                  {STARTER_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => sendMessage(prompt)}
                      className="text-left text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:border-rose-300 hover:text-rose-700 text-slate-700 transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {loading && (
              <div className="flex items-center gap-2 text-xs text-slate-500 px-1">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-600" />
                <span>Assistant is typing...</span>
              </div>
            )}

            {errorMsg && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
                {errorMsg}
              </div>
            )}
            <div ref={endRef} />
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void sendMessage();
            }}
            className="p-3 border-t border-slate-200 bg-white flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask DELIVOO anything..."
              className="flex-1 text-sm px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-rose-500"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-2.5 rounded-xl bg-rose-600 text-white hover:bg-rose-700 disabled:opacity-50 transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
