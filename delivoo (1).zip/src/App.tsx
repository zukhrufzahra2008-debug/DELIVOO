/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback } from 'react';
import { X, CheckCircle2, AlertCircle, Info, RotateCcw } from 'lucide-react';
import { AppProvider, useApp } from './context/AppContext';
import { StartupSplash } from './components/StartupSplash';
import { AuthView } from './components/AuthView';
import { CustomerPanel } from './components/CustomerPanel';
import { ShopkeeperPanel } from './components/ShopkeeperPanel';
import { RiderPanel } from './components/RiderPanel';
import { AdminPanel } from './components/AdminPanel';
import { HelpChatbot } from './components/HelpChatbot';
import { DelivooLogo } from './components/DelivooLogo';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

class AppErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, message: error?.message || 'Unexpected display error' };
  }

  componentDidCatch(error: Error) {
    console.error('DELIVOO UI boundary caught error:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#FAFAFA] flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-2xl border border-slate-200 bg-white p-6 text-center space-y-4 shadow-sm">
            <div className="flex justify-center">
              <DelivooLogo />
            </div>
            <h1 className="font-display text-lg font-bold text-slate-900">
              Something interrupted this view
            </h1>
            <p className="text-xs text-slate-600 leading-relaxed">
              Your order and session are safe. Refresh the view below to continue seamlessly.
            </p>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => this.setState({ hasError: false, message: '' })}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Recover View
              </button>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50"
              >
                Reload Page
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const ToastStack: React.FC = () => {
  const { toasts, dismissToast } = useApp();
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 w-[calc(100vw-2rem)] max-w-sm pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className={`pointer-events-auto flex items-start gap-2.5 rounded-xl border px-4 py-3 shadow-lg bg-white text-sm ${
            t.type === 'error'
              ? 'border-rose-200 text-rose-900'
              : t.type === 'success'
              ? 'border-emerald-200 text-emerald-900'
              : 'border-slate-200 text-slate-900'
          }`}
        >
          {t.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          ) : t.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <Info className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
          )}
          <span className="flex-1 text-xs font-medium leading-relaxed">{t.text}</span>
          <button
            type="button"
            onClick={() => dismissToast(t.id)}
            aria-label="Dismiss message"
            className="text-slate-400 hover:text-slate-700 shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};

const DelivooShell: React.FC = () => {
  const { user, authLoading } = useApp();
  const [showSplash, setShowSplash] = useState(() => {
    try {
      return window.sessionStorage.getItem('delivoo_splash_seen') !== '1';
    } catch {
      return true;
    }
  });
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'admin'>('login');

  const handleSplashComplete = useCallback(() => {
    setShowSplash(false);
  }, []);

  const renderPanel = () => {
    if (authLoading && !user) {
      return (
        <div className="min-h-screen bg-[#FAFAFA] flex flex-col items-center justify-center gap-3">
          <DelivooLogo />
          <p className="text-xs font-medium text-slate-500">Restoring your DELIVOO session...</p>
        </div>
      );
    }

    if (user) {
      if (user.role === 'admin') return <AdminPanel />;
      if (user.role === 'shopkeeper') return <ShopkeeperPanel />;
      if (user.role === 'rider') return <RiderPanel />;
      return (
        <CustomerPanel
          onOpenAuth={(mode) => {
            setAuthMode(mode);
            setAuthOpen(true);
          }}
        />
      );
    }

    if (authOpen) {
      return (
        <AuthView
          initialMode={authMode}
          onBackToMarketplace={() => setAuthOpen(false)}
        />
      );
    }

    return (
      <CustomerPanel
        onOpenAuth={(mode) => {
          setAuthMode(mode);
          setAuthOpen(true);
        }}
      />
    );
  };

  return (
    <>
      {showSplash && <StartupSplash onComplete={handleSplashComplete} />}
      <ToastStack />
      {renderPanel()}
      <HelpChatbot />
    </>
  );
};

export default function App() {
  return (
    <AppErrorBoundary>
      <AppProvider>
        <DelivooShell />
      </AppProvider>
    </AppErrorBoundary>
  );
}
