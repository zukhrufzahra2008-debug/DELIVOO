import { Router } from 'express';
import { eq, and, desc, inArray } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  riderProfiles,
  riderAssignments,
  riderLocations,
  riderEarnings,
  orders,
  orderItems,
  orderEvents,
  shopProfiles,
  notifications,
  users,
} from '../../db/schema.ts';
import { requireAuth, requireRole, type AuthedRequest } from '../middleware/auth.ts';
import { autoAssignNearestRider } from '../services/dispatch.ts';
import { emitToRole, emitToUser } from '../ws.ts';

const router = Router();
router.use('/rider', requireAuth, requireRole('rider'));

// Rider Dashboard
router.get('/rider/dashboard', async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const [profile] = await db.select().from(riderProfiles).where(eq(riderProfiles.userId, authUser.id));
    if (!profile) return res.status(404).json({ error: 'Rider profile not found' });

    const offers = await db
      .select()
      .from(riderAssignments)
      .where(and(eq(riderAssignments.riderId, authUser.id), eq(riderAssignments.status, 'offered')))
      .orderBy(desc(riderAssignments.offeredAt));

    const offerOrderIds = offers.map((o) => o.orderId);
    const offerOrders = offerOrderIds.length
      ? await db.select().from(orders).where(inArray(orders.id, offerOrderIds))
      : [];

    const assignedOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.riderId, authUser.id))
      .orderBy(desc(orders.createdAt));

    const allShops = await db.select().from(shopProfiles);
    const shopMap = new Map(allShops.map((s) => [s.id, s]));

    const allOrderIds = [...new Set([...offerOrderIds, ...assignedOrders.map((o) => o.id)])];
    const itemsList = allOrderIds.length
      ? await db.select().from(orderItems).where(inArray(orderItems.orderId, allOrderIds))
      : [];

    const earningsList = await db
      .select()
      .from(riderEarnings)
      .where(eq(riderEarnings.riderId, authUser.id))
      .orderBy(desc(riderEarnings.createdAt));

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const weekAgo = new Date(now.getTime() - 7 * 86400_000);
    const monthStr = now.toISOString().slice(0, 7);

    const todayEarnings = earningsList
      .filter((e) => e.createdAt.toISOString().slice(0, 10) === todayStr)
      .reduce((acc, e) => acc + Number(e.amount), 0);
    const weeklyEarnings = earningsList
      .filter((e) => e.createdAt >= weekAgo)
      .reduce((acc, e) => acc + Number(e.amount), 0);
    const monthlyEarnings = earningsList
      .filter((e) => e.createdAt.toISOString().slice(0, 7) === monthStr)
      .reduce((acc, e) => acc + Number(e.amount), 0);

    const pendingOffers = offers.map((offer) => {
      const ord = offerOrders.find((o) => o.id === offer.orderId);
      const shop = ord ? shopMap.get(ord.shopId) : undefined;
      return {
        ...offer,
        order: ord
          ? {
              ...ord,
              shopName: shop?.name || 'Shop',
              shopAddress: shop?.address || '',
              shopLat: shop?.lat || 24.8615,
              shopLng: shop?.lng || 67.0099,
              items: itemsList.filter((i) => i.orderId === ord.id),
            }
          : null,
      };
    });

    const enrichedOrders = assignedOrders.map((o) => {
      const shop = shopMap.get(o.shopId);
      return {
        ...o,
        shopName: shop?.name || 'Shop',
        shopAddress: shop?.address || '',
        shopPhone: shop?.contactNumber || '',
        shopLat: shop?.lat || 24.8615,
        shopLng: shop?.lng || 67.0099,
        items: itemsList.filter((i) => i.orderId === o.id),
      };
    });

    const activeDelivery = enrichedOrders.find((o) =>
      ['rider_assigned', 'picked_up', 'on_the_way'].includes(o.status)
    ) || null;

    res.json({
      profile,
      accountStatus: authUser.accountStatus,
      stats: {
        todayEarnings: Math.round(todayEarnings * 100) / 100,
        weeklyEarnings: Math.round(weeklyEarnings * 100) / 100,
        monthlyEarnings: Math.round(monthlyEarnings * 100) / 100,
        totalDeliveries: profile.totalDeliveries,
        totalEarnings: Number(profile.totalEarnings),
        rating: profile.rating,
      },
      pendingOffers,
      activeDelivery,
      orders: enrichedOrders,
      earnings: earningsList,
    });
  } catch (error) {
    console.error('Rider dashboard error:', error);
    res.status(500).json({ error: 'Failed to load rider dashboard' });
  }
});

// Toggle Online / Offline Status (Only approved riders!)
router.post('/rider/status', async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    if (authUser.accountStatus !== 'approved') {
      return res.status(403).json({
        error: 'Only verified and approved riders can go online to receive delivery requests.',
      });
    }
    const { isOnline, isAvailable } = req.body as { isOnline?: boolean; isAvailable?: boolean };
    const [updated] = await db
      .update(riderProfiles)
      .set({
        ...(typeof isOnline === 'boolean' ? { isOnline } : {}),
        ...(typeof isAvailable === 'boolean' ? { isAvailable } : {}),
      })
      .where(eq(riderProfiles.userId, authUser.id))
      .returning();

    emitToRole('admin', 'rider:status', {
      riderId: authUser.id,
      isOnline: updated.isOnline,
      isAvailable: updated.isAvailable,
    });
    res.json({ profile: updated });
  } catch (error) {
    console.error('Rider status toggle error:', error);
    res.status(500).json({ error: 'Failed to update online status' });
  }
});

// Live GPS Location Update
router.post('/rider/location', async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const { lat, lng, heading, speedKmh, orderId } = req.body as {
      lat?: number;
      lng?: number;
      heading?: number;
      speedKmh?: number;
      orderId?: number;
    };
    if (typeof lat !== 'number' || typeof lng !== 'number') {
      return res.status(400).json({ error: 'Valid lat and lng coordinates required' });
    }

    await db
      .update(riderProfiles)
      .set({
        currentLat: lat,
        currentLng: lng,
        lastLocationAt: new Date(),
      })
      .where(eq(riderProfiles.userId, authUser.id));

    await db.insert(riderLocations).values({
      riderId: authUser.id,
      orderId: orderId || null,
      lat,
      lng,
      heading: heading || 0,
      speedKmh: speedKmh || 0,
    });

    // Stream live coordinates to authorized active customer(s) and Admin
    const activeOrders = await db
      .select()
      .from(orders)
      .where(
        and(
          eq(orders.riderId, authUser.id),
          inArray(orders.status, ['rider_assigned', 'picked_up', 'on_the_way'])
        )
      );

    for (const ord of activeOrders) {
      emitToUser(ord.customerId, 'rider:location', {
        orderId: ord.id,
        riderId: authUser.id,
        lat,
        lng,
      });
    }
    emitToRole('admin', 'rider:location', { riderId: authUser.id, lat, lng });

    res.json({ updated: true, lat, lng });
  } catch (error) {
    console.error('Rider location error:', error);
    res.status(500).json({ error: 'Failed to update GPS location' });
  }
});

// Accept or Reject Delivery Offer
router.post('/rider/assignments/:id/respond', async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    if (authUser.accountStatus !== 'approved') {
      return res.status(403).json({ error: 'Only approved riders can respond to delivery offers' });
    }
    const assignmentId = Number(req.params.id);
    const { decision } = req.body as { decision?: 'accept' | 'reject' };

    const [assignment] = await db
      .select()
      .from(riderAssignments)
      .where(and(eq(riderAssignments.id, assignmentId), eq(riderAssignments.riderId, authUser.id)));

    if (!assignment || assignment.status !== 'offered') {
      return res.status(404).json({ error: 'Delivery offer is no longer available' });
    }

    const [order] = await db.select().from(orders).where(eq(orders.id, assignment.orderId));
    if (!order) return res.status(404).json({ error: 'Order not found' });

    if (decision === 'reject') {
      await db
        .update(riderAssignments)
        .set({ status: 'rejected', respondedAt: new Date() })
        .where(eq(riderAssignments.id, assignment.id));

      await db.insert(orderEvents).values({
        orderId: order.id,
        status: order.status,
        actorId: authUser.id,
        actorRole: 'rider',
        notes: 'Rider declined delivery offer — re-routing to next nearby rider',
      });

      const nextOffer = await autoAssignNearestRider(order.id);
      return res.json({ status: 'rejected', reassigned: nextOffer });
    }

    if (order.riderId && order.riderId !== authUser.id) {
      await db
        .update(riderAssignments)
        .set({ status: 'reassigned', respondedAt: new Date() })
        .where(eq(riderAssignments.id, assignment.id));
      return res.status(409).json({ error: 'This order was already assigned to another rider' });
    }

    await db.transaction(async (tx) => {
      await tx
        .update(riderAssignments)
        .set({ status: 'accepted', respondedAt: new Date() })
        .where(eq(riderAssignments.id, assignment.id));

      await tx
        .update(orders)
        .set({
          riderId: authUser.id,
          status: 'rider_assigned',
          updatedAt: new Date(),
        })
        .where(eq(orders.id, order.id));

      const [rp] = await tx.select().from(riderProfiles).where(eq(riderProfiles.userId, authUser.id));
      if (rp) {
        await tx
          .update(riderProfiles)
          .set({ activeOrdersCount: rp.activeOrdersCount + 1 })
          .where(eq(riderProfiles.userId, authUser.id));
      }

      await tx.insert(orderEvents).values({
        orderId: order.id,
        status: 'rider_assigned',
        actorId: authUser.id,
        actorRole: 'rider',
        notes: `Rider ${authUser.fullName} accepted delivery request`,
      });
    });

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, order.shopId));
    const [custNotif] = await db
      .insert(notifications)
      .values({
        userId: order.customerId,
        title: 'Rider Assigned',
        message: `${authUser.fullName} is heading to ${shop?.name || 'the shop'} to pick up your order.`,
        type: 'rider_assigned',
        referenceId: String(order.id),
      })
      .returning();
    emitToUser(order.customerId, 'notification:new', custNotif);
    emitToUser(order.customerId, 'order:updated', { orderId: order.id, status: 'rider_assigned', riderId: authUser.id });

    if (shop) {
      const [shopNotif] = await db
        .insert(notifications)
        .values({
          userId: shop.ownerId,
          title: 'Rider Assigned',
          message: `Rider ${authUser.fullName} assigned to order ${order.orderNumber}.`,
          type: 'rider_assigned',
          referenceId: String(order.id),
        })
        .returning();
      emitToUser(shop.ownerId, 'notification:new', shopNotif);
      emitToUser(shop.ownerId, 'order:updated', { orderId: order.id, status: 'rider_assigned', riderId: authUser.id });
    }
    emitToRole('admin', 'order:updated', { orderId: order.id, status: 'rider_assigned', riderId: authUser.id });

    res.json({ status: 'accepted', orderId: order.id });
  } catch (error) {
    console.error('Rider respond error:', error);
    res.status(500).json({ error: 'Failed to process delivery response' });
  }
});

// Rider Pickup & Delivery Confirmations
router.post('/rider/orders/:id/status', async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const orderId = Number(req.params.id);
    const { nextStatus } = req.body as { nextStatus?: 'picked_up' | 'on_the_way' | 'delivered' };

    const [order] = await db
      .select()
      .from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.riderId, authUser.id)));
    if (!order) return res.status(404).json({ error: 'Assigned order not found' });

    const validMap: Record<string, string[]> = {
      rider_assigned: ['picked_up'],
      ready_for_pickup: ['picked_up'],
      picked_up: ['on_the_way', 'delivered'],
      on_the_way: ['delivered'],
    };

    if (!nextStatus || !validMap[order.status]?.includes(nextStatus)) {
      return res.status(400).json({ error: `Cannot transition from ${order.status} to ${nextStatus}` });
    }

    let note = '';
    if (nextStatus === 'picked_up') note = 'Rider confirmed pickup from shop';
    else if (nextStatus === 'on_the_way') note = 'Rider is en route to customer';
    else if (nextStatus === 'delivered') note = 'Rider confirmed delivery to customer';

    const updatedOrder = await db.transaction(async (tx) => {
      const [upd] = await tx
        .update(orders)
        .set({
          status: nextStatus,
          ...(nextStatus === 'delivered' && order.paymentMethod === 'cod' ? { paymentStatus: 'paid' } : {}),
          updatedAt: new Date(),
        })
        .where(eq(orders.id, order.id))
        .returning();

      await tx.insert(orderEvents).values({
        orderId: order.id,
        status: nextStatus,
        actorId: authUser.id,
        actorRole: 'rider',
        notes: note,
      });

      if (nextStatus === 'delivered') {
        await tx
          .update(riderAssignments)
          .set({ status: 'completed' })
          .where(and(eq(riderAssignments.orderId, order.id), eq(riderAssignments.riderId, authUser.id)));

        const earningAmt = Number(order.riderEarning || 110);
        await tx.insert(riderEarnings).values({
          riderId: authUser.id,
          orderId: order.id,
          earningType: 'delivery_fee',
          amount: earningAmt.toFixed(2),
          status: 'available',
          note: `Delivery earning for ${order.orderNumber}`,
        });

        const [rp] = await tx.select().from(riderProfiles).where(eq(riderProfiles.userId, authUser.id));
        if (rp) {
          await tx
            .update(riderProfiles)
            .set({
              activeOrdersCount: Math.max(0, rp.activeOrdersCount - 1),
              totalDeliveries: rp.totalDeliveries + 1,
              totalEarnings: (Number(rp.totalEarnings) + earningAmt).toFixed(2),
            })
            .where(eq(riderProfiles.userId, authUser.id));
        }
      }
      return upd;
    });

    const [custNotif] = await db
      .insert(notifications)
      .values({
        userId: order.customerId,
        title: nextStatus === 'delivered' ? 'Order Delivered' : 'Delivery Update',
        message: `${order.orderNumber}: ${note}`,
        type: 'order_status',
        referenceId: String(order.id),
      })
      .returning();
    emitToUser(order.customerId, 'notification:new', custNotif);
    emitToUser(order.customerId, 'order:updated', updatedOrder);

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, order.shopId));
    if (shop) {
      emitToUser(shop.ownerId, 'order:updated', updatedOrder);
    }
    emitToRole('admin', 'order:updated', updatedOrder);

    res.json({ order: updatedOrder });
  } catch (error) {
    console.error('Rider order status error:', error);
    res.status(500).json({ error: 'Failed to update delivery status' });
  }
});

export default router;
