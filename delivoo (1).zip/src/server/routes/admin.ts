import { Router } from 'express';
import crypto from 'node:crypto';
import { eq, desc, asc, and, ne } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  users,
  shopProfiles,
  riderProfiles,
  verificationApplications,
  verificationDocuments,
  orders,
  orderEvents,
  riderAssignments,
  payments,
  refunds,
  shopSettlements,
  riderEarnings,
  categories,
  banners,
  coupons,
  deliveryZones,
  platformSettings,
  notifications,
  auditLogs,
  supportTickets,
} from '../../db/schema.ts';
import { requireAuth, requireRole, type AuthedRequest } from '../middleware/auth.ts';
import { hashPassword, sanitizePublicUser } from '../security.ts';
import { emitToUser } from '../ws.ts';

const router = Router();
router.use('/admin', requireAuth, requireRole('admin'));

const MAX_SUB_ADMINS = 3;

function requireMainAdmin(req: AuthedRequest, res: import('express').Response, next: import('express').NextFunction) {
  if (req.authUser?.adminTier !== 'main') {
    return res.status(403).json({ error: 'Only the Main Administrator can perform this action.' });
  }
  next();
}

// Sub-Admin Hierarchy Management (1 Main Admin + up to 3 Sub-Admins)
router.get('/admin/sub-admins', async (_req: AuthedRequest, res) => {
  try {
    const adminRows = await db
      .select()
      .from(users)
      .where(and(eq(users.role, 'admin'), ne(users.accountStatus, 'deleted')))
      .orderBy(asc(users.id));

    const mainAdmin = adminRows.find((a) => a.adminTier === 'main') || adminRows[0] || null;
    const subAdmins = adminRows.filter((a) => a.adminTier === 'sub');

    res.json({
      mainAdmin: mainAdmin ? sanitizePublicUser(mainAdmin, true) : null,
      subAdmins: subAdmins.map((s) => sanitizePublicUser(s, true)),
      maxSubAdmins: MAX_SUB_ADMINS,
      remainingSlots: Math.max(0, MAX_SUB_ADMINS - subAdmins.length),
    });
  } catch (error) {
    console.error('List sub-admins error:', error);
    res.status(500).json({ error: 'Failed to load admin hierarchy' });
  }
});

router.post('/admin/sub-admins', requireMainAdmin, async (req: AuthedRequest, res) => {
  try {
    const { fullName, email, phone, password } = req.body as {
      fullName?: string;
      email?: string;
      phone?: string;
      password?: string;
    };

    if (!fullName || !email || !phone || !password || password.length < 8) {
      return res.status(400).json({ error: 'Full name, email, phone, and password (min 8 chars) are required' });
    }

    const activeSubs = await db
      .select({ id: users.id })
      .from(users)
      .where(and(eq(users.role, 'admin'), eq(users.adminTier, 'sub'), ne(users.accountStatus, 'deleted')));

    if (activeSubs.length >= MAX_SUB_ADMINS) {
      return res.status(400).json({
        error: `Maximum limit of ${MAX_SUB_ADMINS} Sub-Admins reached. Remove an existing Sub-Admin before adding another.`,
      });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const dupEmail = await db.select({ id: users.id }).from(users).where(eq(users.email, normalizedEmail));
    if (dupEmail.length > 0) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }
    const dupPhone = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone.trim()));
    if (dupPhone.length > 0) {
      return res.status(409).json({ error: 'An account with this phone number already exists' });
    }

    const [created] = await db
      .insert(users)
      .values({
        uid: `subadmin-${crypto.randomUUID()}`,
        email: normalizedEmail,
        passwordHash: hashPassword(password),
        fullName: fullName.trim(),
        phone: phone.trim(),
        role: 'admin',
        adminTier: 'sub',
        createdByAdminId: req.authUser!.id,
        accountStatus: 'approved',
        emailVerified: true,
        phoneVerified: true,
      })
      .returning();

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: 'sub_admin_created',
      targetType: 'user',
      targetId: String(created.id),
      details: { email: created.email },
      ipAddress: req.ip,
    });

    res.status(201).json({ subAdmin: sanitizePublicUser(created, true) });
  } catch (error) {
    console.error('Create sub-admin error:', error);
    res.status(500).json({ error: 'Failed to create Sub-Admin' });
  }
});

router.patch('/admin/sub-admins/:id', requireMainAdmin, async (req: AuthedRequest, res) => {
  try {
    const targetId = Number(req.params.id);
    const { accountStatus } = req.body as { accountStatus?: 'approved' | 'suspended' };
    if (!accountStatus || !['approved', 'suspended'].includes(accountStatus)) {
      return res.status(400).json({ error: 'Status must be approved or suspended' });
    }

    const [target] = await db.select().from(users).where(eq(users.id, targetId));
    if (!target || target.role !== 'admin' || target.adminTier !== 'sub') {
      return res.status(404).json({ error: 'Sub-Admin not found' });
    }

    const [updated] = await db
      .update(users)
      .set({ accountStatus, updatedAt: new Date() })
      .where(eq(users.id, targetId))
      .returning();

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: `sub_admin_${accountStatus}`,
      targetType: 'user',
      targetId: String(targetId),
      ipAddress: req.ip,
    });

    res.json({ subAdmin: sanitizePublicUser(updated, true) });
  } catch (error) {
    console.error('Update sub-admin error:', error);
    res.status(500).json({ error: 'Failed to update Sub-Admin status' });
  }
});

router.delete('/admin/sub-admins/:id', requireMainAdmin, async (req: AuthedRequest, res) => {
  try {
    const targetId = Number(req.params.id);
    const [target] = await db.select().from(users).where(eq(users.id, targetId));
    if (!target || target.role !== 'admin' || target.adminTier !== 'sub') {
      return res.status(404).json({ error: 'Sub-Admin not found' });
    }

    await db
      .update(users)
      .set({
        email: `removed-subadmin-${targetId}-${Date.now()}@deleted.delivoo.local`,
        phone: `0000-sub-${targetId}-${Date.now()}`,
        passwordHash: null,
        accountStatus: 'deleted',
        deletedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, targetId));

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: 'sub_admin_removed',
      targetType: 'user',
      targetId: String(targetId),
      ipAddress: req.ip,
    });

    res.json({ deleted: true });
  } catch (error) {
    console.error('Delete sub-admin error:', error);
    res.status(500).json({ error: 'Failed to remove Sub-Admin' });
  }
});

// Admin Analytics Dashboard + Time Series Charts
router.get('/admin/analytics', async (_req: AuthedRequest, res) => {
  try {
    const allUsers = await db.select().from(users).where(ne(users.accountStatus, 'deleted'));
    const allShops = await db.select().from(shopProfiles);
    const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt));
    const pendingApps = await db
      .select()
      .from(verificationApplications)
      .where(eq(verificationApplications.status, 'under_review'));

    const deliveredOrders = allOrders.filter((o) => o.status === 'delivered');
    const gmv = allOrders
      .filter((o) => !['cancelled', 'rejected'].includes(o.status))
      .reduce((acc, o) => acc + Number(o.totalAmount), 0);
    const commission = deliveredOrders.reduce((acc, o) => acc + Number(o.commissionAmount), 0);
    const platformFees = deliveredOrders.reduce((acc, o) => acc + Number(o.platformFee), 0);

    // Build 7-day daily chart series
    const dailyMap = new Map<string, { label: string; orders: number; gmv: number; revenue: number }>();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400_000);
      const key = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString('en-US', { weekday: 'short' });
      dailyMap.set(key, { label, orders: 0, gmv: 0, revenue: 0 });
    }
    for (const o of allOrders) {
      const key = o.createdAt.toISOString().slice(0, 10);
      const bucket = dailyMap.get(key);
      if (bucket) {
        bucket.orders += 1;
        bucket.gmv += Number(o.totalAmount);
        if (o.status === 'delivered') {
          bucket.revenue += Number(o.commissionAmount) + Number(o.platformFee);
        }
      }
    }

    res.json({
      kpis: {
        totalCustomers: allUsers.filter((u) => u.role === 'customer').length,
        totalShopkeepers: allUsers.filter((u) => u.role === 'shopkeeper').length,
        totalRiders: allUsers.filter((u) => u.role === 'rider').length,
        activeShops: allShops.filter((s) => s.approvalStatus === 'approved').length,
        pendingRegistrations: pendingApps.length,
        totalOrders: allOrders.length,
        completedOrders: deliveredOrders.length,
        cancelledOrders: allOrders.filter((o) => ['cancelled', 'rejected'].includes(o.status)).length,
        grossOrderValue: Math.round(gmv * 100) / 100,
        platformRevenue: Math.round((commission + platformFees) * 100) / 100,
        totalCommission: Math.round(commission * 100) / 100,
      },
      dailySeries: Array.from(dailyMap.values()),
    });
  } catch (error) {
    console.error('Admin analytics error:', error);
    res.status(500).json({ error: 'Failed to load analytics' });
  }
});

// User Management (CNIC masked by default)
router.get('/admin/users', async (req: AuthedRequest, res) => {
  try {
    const { role, status, q } = req.query as Record<string, string | undefined>;
    let list = await db.select().from(users).where(ne(users.accountStatus, 'deleted')).orderBy(desc(users.createdAt));

    if (role && role !== 'all') list = list.filter((u) => u.role === role);
    if (status && status !== 'all') list = list.filter((u) => u.accountStatus === status);
    if (q && q.trim()) {
      const term = q.trim().toLowerCase();
      list = list.filter(
        (u) =>
          u.fullName.toLowerCase().includes(term) ||
          u.email.toLowerCase().includes(term) ||
          u.phone.toLowerCase().includes(term)
      );
    }

    res.json({ users: list.map((u) => sanitizePublicUser(u, true)) });
  } catch (error) {
    console.error('Admin users error:', error);
    res.status(500).json({ error: 'Failed to list users' });
  }
});

router.patch('/admin/users/:id/status', async (req: AuthedRequest, res) => {
  try {
    const targetId = Number(req.params.id);
    const { accountStatus, reason } = req.body as { accountStatus?: string; reason?: string };
    if (!accountStatus || !['approved', 'rejected', 'suspended', 'under_review'].includes(accountStatus)) {
      return res.status(400).json({ error: 'Invalid accountStatus' });
    }

    const [existingTarget] = await db.select().from(users).where(eq(users.id, targetId));
    if (!existingTarget) return res.status(404).json({ error: 'User not found' });

    if (existingTarget.role === 'admin') {
      if (existingTarget.adminTier === 'main') {
        return res.status(403).json({ error: 'The Main Administrator account cannot be suspended or modified.' });
      }
      if (req.authUser!.adminTier !== 'main') {
        return res.status(403).json({ error: 'Only the Main Administrator can modify Sub-Admin accounts.' });
      }
    }

    const [updated] = await db
      .update(users)
      .set({
        accountStatus,
        rejectionReason: accountStatus === 'rejected' ? reason || 'Application rejected by administrator' : null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, targetId))
      .returning();

    if (!updated) return res.status(404).json({ error: 'User not found' });

    if (updated.role === 'shopkeeper') {
      await db
        .update(shopProfiles)
        .set({
          approvalStatus: accountStatus,
          rejectionReason: accountStatus === 'rejected' ? reason || null : null,
        })
        .where(eq(shopProfiles.ownerId, updated.id));
    }

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: `user_status_${accountStatus}`,
      targetType: 'user',
      targetId: String(targetId),
      details: { reason: reason || null },
      ipAddress: req.ip,
    });

    const [notif] = await db
      .insert(notifications)
      .values({
        userId: updated.id,
        title: `Account Status: ${accountStatus.replace('_', ' ')}`,
        message:
          accountStatus === 'approved'
            ? 'Your DELIVOO account has been approved by an administrator.'
            : reason || `Your account status was updated to ${accountStatus}.`,
        type: 'account_status',
      })
      .returning();
    emitToUser(updated.id, 'notification:new', notif);

    res.json({ user: sanitizePublicUser(updated, true) });
  } catch (error) {
    console.error('Admin update user status error:', error);
    res.status(500).json({ error: 'Failed to update account status' });
  }
});

// Verification Queue & Documents
router.get('/admin/verifications', async (_req: AuthedRequest, res) => {
  try {
    const apps = await db
      .select()
      .from(verificationApplications)
      .orderBy(desc(verificationApplications.submittedAt));

    const allUsers = await db.select().from(users);
    const allDocs = await db.select().from(verificationDocuments);
    const userMap = new Map(allUsers.map((u) => [u.id, sanitizePublicUser(u, true)]));

    const payload = apps.map((app) => ({
      ...app,
      user: userMap.get(app.userId) || null,
      documents: allDocs.filter((d) => d.applicationId === app.id),
    }));

    res.json({ applications: payload });
  } catch (error) {
    console.error('Admin verifications error:', error);
    res.status(500).json({ error: 'Failed to load verification applications' });
  }
});

router.post('/admin/verifications/:id/decide', async (req: AuthedRequest, res) => {
  try {
    const appId = Number(req.params.id);
    const { decision, notes } = req.body as { decision?: 'approved' | 'rejected'; notes?: string };
    if (!decision || !['approved', 'rejected'].includes(decision)) {
      return res.status(400).json({ error: 'Decision must be approved or rejected' });
    }

    const [app] = await db
      .update(verificationApplications)
      .set({
        status: decision,
        reviewNotes: notes || `Marked ${decision} by Admin`,
        reviewedBy: req.authUser!.id,
        reviewedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(verificationApplications.id, appId))
      .returning();

    if (!app) return res.status(404).json({ error: 'Verification application not found' });

    await db
      .update(users)
      .set({
        accountStatus: decision,
        rejectionReason: decision === 'rejected' ? notes || 'Document verification failed' : null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, app.userId));

    if (app.targetRole === 'shopkeeper') {
      await db
        .update(shopProfiles)
        .set({
          approvalStatus: decision,
          rejectionReason: decision === 'rejected' ? notes || 'Shop verification rejected' : null,
        })
        .where(eq(shopProfiles.ownerId, app.userId));
    }

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: `verification_${decision}`,
      targetType: 'verification_application',
      targetId: String(appId),
      details: { userId: app.userId, notes },
      ipAddress: req.ip,
    });

    const [notif] = await db
      .insert(notifications)
      .values({
        userId: app.userId,
        title: decision === 'approved' ? 'Verification Approved' : 'Verification Rejected',
        message:
          decision === 'approved'
            ? 'Welcome to DELIVOO! Your verification application was approved.'
            : notes || 'Your application was rejected. You may update your documents and resubmit.',
        type: 'verification',
        referenceId: String(app.id),
      })
      .returning();
    emitToUser(app.userId, 'notification:new', notif);

    res.json({ application: app });
  } catch (error) {
    console.error('Admin verification decide error:', error);
    res.status(500).json({ error: 'Failed to process verification decision' });
  }
});

// Audit-logged CNIC inspection for authorized admin compliance review
router.post('/admin/verifications/:id/unmask-cnic', async (req: AuthedRequest, res) => {
  try {
    const appId = Number(req.params.id);
    const [app] = await db.select().from(verificationApplications).where(eq(verificationApplications.id, appId));
    if (!app) return res.status(404).json({ error: 'Application not found' });

    const [u] = await db.select().from(users).where(eq(users.id, app.userId));
    if (!u) return res.status(404).json({ error: 'Applicant not found' });

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: 'cnic_unmasked_for_compliance_review',
      targetType: 'user',
      targetId: String(u.id),
      details: { applicationId: appId },
      ipAddress: req.ip,
    });

    res.json({ cnicNumber: u.cnicNumber || 'Not provided' });
  } catch (error) {
    console.error('Unmask CNIC error:', error);
    res.status(500).json({ error: 'Failed to retrieve CNIC' });
  }
});

// Shops Management
router.get('/admin/shops', async (_req: AuthedRequest, res) => {
  try {
    const shops = await db.select().from(shopProfiles).orderBy(desc(shopProfiles.createdAt));
    const cats = await db.select().from(categories);
    const catMap = new Map(cats.map((c) => [c.id, c.name]));
    res.json({
      shops: shops.map((s) => ({ ...s, categoryName: catMap.get(s.categoryId) || 'Store' })),
    });
  } catch (error) {
    console.error('Admin shops error:', error);
    res.status(500).json({ error: 'Failed to load shops' });
  }
});

router.patch('/admin/shops/:id/status', async (req: AuthedRequest, res) => {
  try {
    const shopId = Number(req.params.id);
    const { approvalStatus, commissionRate, isFeatured, rejectionReason } = req.body as Record<string, unknown>;

    const [updated] = await db
      .update(shopProfiles)
      .set({
        ...(typeof approvalStatus === 'string' ? { approvalStatus } : {}),
        ...(typeof commissionRate === 'number' ? { commissionRate: commissionRate.toFixed(2) } : {}),
        ...(typeof isFeatured === 'boolean' ? { isFeatured } : {}),
        ...(typeof rejectionReason === 'string' ? { rejectionReason } : {}),
      })
      .where(eq(shopProfiles.id, shopId))
      .returning();

    if (!updated) return res.status(404).json({ error: 'Shop not found' });

    if (typeof approvalStatus === 'string') {
      await db
        .update(users)
        .set({ accountStatus: approvalStatus })
        .where(eq(users.id, updated.ownerId));
    }

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: 'admin_shop_updated',
      targetType: 'shop',
      targetId: String(shopId),
      details: { approvalStatus, commissionRate, isFeatured },
      ipAddress: req.ip,
    });

    res.json({ shop: updated });
  } catch (error) {
    console.error('Admin shop status error:', error);
    res.status(500).json({ error: 'Failed to update shop' });
  }
});

// Riders Fleet & Manual Order Assignment
router.get('/admin/riders', async (_req: AuthedRequest, res) => {
  try {
    const list = await db
      .select({
        userId: users.id,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone,
        accountStatus: users.accountStatus,
        vehicleType: riderProfiles.vehicleType,
        vehicleRegistration: riderProfiles.vehicleRegistration,
        isOnline: riderProfiles.isOnline,
        isAvailable: riderProfiles.isAvailable,
        currentLat: riderProfiles.currentLat,
        currentLng: riderProfiles.currentLng,
        activeOrdersCount: riderProfiles.activeOrdersCount,
        rating: riderProfiles.rating,
        totalDeliveries: riderProfiles.totalDeliveries,
        totalEarnings: riderProfiles.totalEarnings,
        zoneName: riderProfiles.zoneName,
      })
      .from(riderProfiles)
      .innerJoin(users, eq(riderProfiles.userId, users.id));

    res.json({ riders: list });
  } catch (error) {
    console.error('Admin riders error:', error);
    res.status(500).json({ error: 'Failed to load riders' });
  }
});

router.post('/admin/orders/:id/assign-rider', async (req: AuthedRequest, res) => {
  try {
    const orderId = Number(req.params.id);
    const { riderId } = req.body as { riderId?: number };
    if (!riderId) return res.status(400).json({ error: 'riderId is required' });

    const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const [rider] = await db.select().from(users).where(eq(users.id, Number(riderId)));
    if (!rider || rider.role !== 'rider' || rider.accountStatus !== 'approved') {
      return res.status(400).json({ error: 'Selected rider must be approved' });
    }

    await db.transaction(async (tx) => {
      await tx
        .update(orders)
        .set({ riderId: rider.id, status: 'rider_assigned', updatedAt: new Date() })
        .where(eq(orders.id, order.id));

      await tx.insert(riderAssignments).values({
        orderId: order.id,
        riderId: rider.id,
        assignmentType: 'manual',
        status: 'accepted',
        respondedAt: new Date(),
      });

      await tx.insert(orderEvents).values({
        orderId: order.id,
        status: 'rider_assigned',
        actorId: req.authUser!.id,
        actorRole: 'admin',
        notes: `Manually assigned to rider ${rider.fullName} by Admin`,
      });
    });

    const [notif] = await db
      .insert(notifications)
      .values({
        userId: rider.id,
        title: 'Order Assigned by Dispatch',
        message: `You have been assigned order ${order.orderNumber}.`,
        type: 'assignment',
        referenceId: String(order.id),
      })
      .returning();
    emitToUser(rider.id, 'notification:new', notif);
    emitToUser(order.customerId, 'order:updated', { orderId: order.id, status: 'rider_assigned', riderId: rider.id });

    res.json({ assigned: true, riderId: rider.id });
  } catch (error) {
    console.error('Admin manual assign error:', error);
    res.status(500).json({ error: 'Failed to assign rider' });
  }
});

// Orders, Payments, Refunds, Settlements
router.get('/admin/orders', async (_req: AuthedRequest, res) => {
  try {
    const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt));
    const shops = await db.select().from(shopProfiles);
    const allUsers = await db.select().from(users);
    const shopMap = new Map(shops.map((s) => [s.id, s.name]));
    const userMap = new Map(allUsers.map((u) => [u.id, u.fullName]));

    res.json({
      orders: allOrders.map((o) => ({
        ...o,
        shopName: shopMap.get(o.shopId) || 'Shop',
        customerName: userMap.get(o.customerId) || 'Customer',
        riderName: o.riderId ? userMap.get(o.riderId) || 'Rider' : null,
      })),
    });
  } catch (error) {
    console.error('Admin orders error:', error);
    res.status(500).json({ error: 'Failed to load orders' });
  }
});

router.get('/admin/finance', async (_req: AuthedRequest, res) => {
  try {
    const allPayments = await db.select().from(payments).orderBy(desc(payments.createdAt));
    const allRefunds = await db.select().from(refunds).orderBy(desc(refunds.createdAt));
    const settlements = await db.select().from(shopSettlements).orderBy(desc(shopSettlements.createdAt));
    const riderPayouts = await db.select().from(riderEarnings).orderBy(desc(riderEarnings.createdAt));
    res.json({
      payments: allPayments,
      refunds: allRefunds,
      settlements,
      riderPayouts,
    });
  } catch (error) {
    console.error('Admin finance error:', error);
    res.status(500).json({ error: 'Failed to load financial records' });
  }
});

router.post('/admin/refunds/:id/process', async (req: AuthedRequest, res) => {
  try {
    const refundId = Number(req.params.id);
    const { action } = req.body as { action?: 'processed' | 'rejected' };
    if (!action || !['processed', 'rejected'].includes(action)) {
      return res.status(400).json({ error: 'Invalid refund action' });
    }

    const [refund] = await db
      .update(refunds)
      .set({
        status: action,
        processedBy: req.authUser!.id,
        processedAt: new Date(),
      })
      .where(eq(refunds.id, refundId))
      .returning();

    if (!refund) return res.status(404).json({ error: 'Refund not found' });

    if (action === 'processed') {
      await db.update(orders).set({ paymentStatus: 'refunded' }).where(eq(orders.id, refund.orderId));
      if (refund.paymentId) {
        await db.update(payments).set({ status: 'refunded' }).where(eq(payments.id, refund.paymentId));
      }
    }

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: `refund_${action}`,
      targetType: 'refund',
      targetId: String(refundId),
      ipAddress: req.ip,
    });

    res.json({ refund });
  } catch (error) {
    console.error('Process refund error:', error);
    res.status(500).json({ error: 'Failed to process refund' });
  }
});

router.post('/admin/settlements', async (req: AuthedRequest, res) => {
  try {
    const { shopId, periodLabel, grossAmount, commissionAmount, netAmount, referenceNo } = req.body as {
      shopId?: number;
      periodLabel?: string;
      grossAmount?: number;
      commissionAmount?: number;
      netAmount?: number;
      referenceNo?: string;
    };
    if (!shopId || !periodLabel || netAmount === undefined) {
      return res.status(400).json({ error: 'shopId, periodLabel, and netAmount are required' });
    }

    const [created] = await db
      .insert(shopSettlements)
      .values({
        shopId: Number(shopId),
        periodLabel: periodLabel.trim(),
        grossAmount: Number(grossAmount || netAmount).toFixed(2),
        commissionAmount: Number(commissionAmount || 0).toFixed(2),
        netAmount: Number(netAmount).toFixed(2),
        status: 'settled',
        referenceNo: referenceNo?.trim() || `SET-${Date.now().toString(36).toUpperCase()}`,
        settledAt: new Date(),
      })
      .returning();

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, Number(shopId)));
    if (shop) {
      const [notif] = await db
        .insert(notifications)
        .values({
          userId: shop.ownerId,
          title: 'Settlement Processed',
          message: `Payout of Rs ${created.netAmount} (${created.periodLabel}) settled · Ref ${created.referenceNo}.`,
          type: 'settlement',
        })
        .returning();
      emitToUser(shop.ownerId, 'notification:new', notif);
    }

    res.status(201).json({ settlement: created });
  } catch (error) {
    console.error('Create settlement error:', error);
    res.status(500).json({ error: 'Failed to record settlement' });
  }
});

// Platform Settings, Categories, Banners, Coupons, Delivery Zones
router.get('/admin/settings', async (_req: AuthedRequest, res) => {
  try {
    const settings = await db.select().from(platformSettings);
    const cats = await db.select().from(categories).orderBy(asc(categories.sortOrder));
    const banns = await db.select().from(banners).orderBy(asc(banners.sortOrder));
    const coups = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
    const zones = await db.select().from(deliveryZones).orderBy(asc(deliveryZones.id));
    res.json({ settings, categories: cats, banners: banns, coupons: coups, zones });
  } catch (error) {
    console.error('Admin settings load error:', error);
    res.status(500).json({ error: 'Failed to load platform settings' });
  }
});

router.patch('/admin/settings', async (req: AuthedRequest, res) => {
  try {
    const { key, value } = req.body as { key?: string; value?: Record<string, unknown> };
    if (!key || !value) return res.status(400).json({ error: 'Setting key and value required' });

    const [updated] = await db
      .insert(platformSettings)
      .values({ key, value, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: platformSettings.key,
        set: { value, updatedAt: new Date() },
      })
      .returning();

    await db.insert(auditLogs).values({
      actorId: req.authUser!.id,
      actorRole: 'admin',
      action: 'platform_settings_updated',
      targetType: 'platform_settings',
      targetId: key,
      details: value,
      ipAddress: req.ip,
    });

    res.json({ setting: updated });
  } catch (error) {
    console.error('Admin settings update error:', error);
    res.status(500).json({ error: 'Failed to update setting' });
  }
});

router.post('/admin/categories', async (req: AuthedRequest, res) => {
  try {
    const { name, description, iconName } = req.body as { name?: string; description?: string; iconName?: string };
    if (!name) return res.status(400).json({ error: 'Category name is required' });
    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const [created] = await db
      .insert(categories)
      .values({
        name: name.trim(),
        slug,
        description: description?.trim() || null,
        iconName: iconName?.trim() || 'Store',
      })
      .returning();
    res.status(201).json({ category: created });
  } catch (error) {
    console.error('Add category error:', error);
    res.status(500).json({ error: 'Failed to add category' });
  }
});

router.delete('/admin/categories/:id', async (req: AuthedRequest, res) => {
  try {
    const id = Number(req.params.id);
    await db.update(categories).set({ isActive: false }).where(eq(categories.id, id));
    res.json({ deactivated: true });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ error: 'Failed to remove category' });
  }
});

router.post('/admin/coupons', async (req: AuthedRequest, res) => {
  try {
    const { code, title, discountType, discountValue, minOrderAmount, maxDiscount } = req.body as Record<string, unknown>;
    if (!code || !title || !discountValue) return res.status(400).json({ error: 'Code, title, and value required' });
    const [created] = await db
      .insert(coupons)
      .values({
        code: String(code).trim().toUpperCase(),
        title: String(title).trim(),
        discountType: discountType === 'fixed' ? 'fixed' : 'percent',
        discountValue: Number(discountValue).toFixed(2),
        minOrderAmount: Number(minOrderAmount || 0).toFixed(2),
        maxDiscount: Number(maxDiscount || 500).toFixed(2),
      })
      .returning();
    res.status(201).json({ coupon: created });
  } catch (error) {
    console.error('Add coupon error:', error);
    res.status(500).json({ error: 'Failed to create coupon' });
  }
});

router.delete('/admin/coupons/:id', async (req: AuthedRequest, res) => {
  try {
    await db.delete(coupons).where(eq(coupons.id, Number(req.params.id)));
    res.json({ deleted: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete coupon' });
  }
});

router.post('/admin/zones', async (req: AuthedRequest, res) => {
  try {
    const { name, city, centerLat, centerLng, radiusKm, baseDeliveryFee } = req.body as Record<string, unknown>;
    if (!name) return res.status(400).json({ error: 'Zone name required' });
    const [created] = await db
      .insert(deliveryZones)
      .values({
        name: String(name).trim(),
        city: String(city || 'Karachi').trim(),
        centerLat: Number(centerLat || 24.8607),
        centerLng: Number(centerLng || 67.0011),
        radiusKm: Number(radiusKm || 10),
        baseDeliveryFee: Number(baseDeliveryFee || 110).toFixed(2),
      })
      .returning();
    res.status(201).json({ zone: created });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create zone' });
  }
});

router.get('/admin/audit-logs', async (_req: AuthedRequest, res) => {
  try {
    const logs = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(100);
    const tickets = await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
    res.json({ auditLogs: logs, supportTickets: tickets });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load audit logs' });
  }
});

export default router;
