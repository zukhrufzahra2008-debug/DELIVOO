import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export interface MapMarker {
  lat: number;
  lng: number;
  label: string;
  kind: 'shop' | 'customer' | 'rider' | 'pin';
}

interface DeliveryMapProps {
  center?: [number, number];
  zoom?: number;
  markers?: MapMarker[];
  routePoints?: Array<[number, number]>;
  interactivePick?: boolean;
  onPickLocation?: (lat: number, lng: number) => void;
  heightClass?: string;
}

const DEFAULT_CENTER: [number, number] = [24.855, 67.025];

const COLOR_MAP: Record<MapMarker['kind'], string> = {
  shop: '#0F172A',
  customer: '#E11D48',
  rider: '#059669',
  pin: '#E11D48',
};

function isValidCoord(lat: unknown, lng: unknown): boolean {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    Math.abs(lat) <= 90 &&
    Math.abs(lng) <= 180
  );
}

export const DeliveryMap: React.FC<DeliveryMapProps> = ({
  center = DEFAULT_CENTER,
  zoom = 13,
  markers = [],
  routePoints = [],
  interactivePick = false,
  onPickLocation,
  heightClass = 'h-64',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const lastFingerprintRef = useRef<string>('');
  const onPickRef = useRef(onPickLocation);
  onPickRef.current = onPickLocation;

  const safeCenter: [number, number] = isValidCoord(center?.[0], center?.[1])
    ? [center[0], center[1]]
    : DEFAULT_CENTER;
  const safeMarkers = markers.filter((m) => isValidCoord(m?.lat, m?.lng));
  const safeRoute = routePoints.filter((pt) => isValidCoord(pt?.[0], pt?.[1]));

  const fingerprint = JSON.stringify({
    center: safeCenter,
    zoom,
    interactivePick,
    markers: safeMarkers.map((m) => [m.lat, m.lng, m.kind, m.label]),
    route: safeRoute,
  });

  useEffect(() => {
    const el = containerRef.current;
    if (!el || !el.isConnected || mapRef.current) return;

    let map: L.Map | null = null;
    try {
      map = L.map(el, {
        center: safeCenter,
        zoom,
        zoomControl: true,
        fadeAnimation: false,
        zoomAnimation: false,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(map);

      const group = L.layerGroup().addTo(map);
      mapRef.current = map;
      layerRef.current = group;
      lastFingerprintRef.current = '';

      if (interactivePick) {
        map.on('click', (e: L.LeafletMouseEvent) => {
          onPickRef.current?.(
            Math.round(e.latlng.lat * 100000) / 100000,
            Math.round(e.latlng.lng * 100000) / 100000
          );
        });
      }
    } catch (err) {
      console.error('DeliveryMap init error:', err);
      return;
    }

    const resizeTimer = setTimeout(() => {
      try {
        if (mapRef.current && containerRef.current?.isConnected) {
          mapRef.current.invalidateSize();
        }
      } catch {
        // Ignore post-unmount resize
      }
    }, 140);

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        try {
          if (mapRef.current && containerRef.current?.isConnected) {
            mapRef.current.invalidateSize();
          }
        } catch {
          // Ignore resize observer errors
        }
      });
      observer.observe(el);
    }

    return () => {
      clearTimeout(resizeTimer);
      observer?.disconnect();
      try {
        map?.remove();
      } catch {
        // Ignore teardown errors
      }
      mapRef.current = null;
      layerRef.current = null;
      lastFingerprintRef.current = '';
    };
  }, [interactivePick]);

  useEffect(() => {
    const map = mapRef.current;
    const group = layerRef.current;
    if (!map || !group || !containerRef.current?.isConnected) return;
    if (lastFingerprintRef.current === fingerprint) return;
    lastFingerprintRef.current = fingerprint;

    try {
      group.clearLayers();

      const bounds: L.LatLngExpression[] = [];

      for (const m of safeMarkers) {
        const color = COLOR_MAP[m.kind] || '#0F172A';
        const isInteractivePin = interactivePick && m.kind === 'pin';
        const size = isInteractivePin ? 22 : 16;
        const icon = L.divIcon({
          className: 'delivoo-map-marker',
          html: `<div style="display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%);">
            <div style="width:${size}px;height:${size}px;border-radius:9999px;background:${color};border:3px solid #FFFFFF;box-shadow:0 3px 10px rgba(15,23,42,0.4);"></div>
          </div>`,
          iconSize: [size, size],
        });
        const marker = L.marker([m.lat, m.lng], {
          icon,
          draggable: isInteractivePin,
        }).addTo(group);

        if (isInteractivePin) {
          marker.on('dragend', () => {
            const pos = marker.getLatLng();
            onPickRef.current?.(
              Math.round(pos.lat * 100000) / 100000,
              Math.round(pos.lng * 100000) / 100000
            );
          });
        }

        marker.bindTooltip(String(m.label || 'Location'), { direction: 'top', offset: [0, -10] });
        bounds.push([m.lat, m.lng]);
      }

      if (safeRoute.length >= 2) {
        L.polyline(safeRoute, {
          color: '#E11D48',
          weight: 3.5,
          dashArray: '6, 6',
          opacity: 0.85,
        }).addTo(group);
      }

      if (interactivePick) {
        map.setView(safeCenter, Math.max(map.getZoom(), zoom), { animate: false });
      } else if (bounds.length > 1) {
        const latLngBounds = L.latLngBounds(bounds);
        if (latLngBounds.isValid()) {
          map.fitBounds(latLngBounds, { padding: [36, 36], maxZoom: 15, animate: false });
        } else {
          map.setView(safeCenter, zoom, { animate: false });
        }
      } else if (bounds.length === 1) {
        map.setView(bounds[0], zoom, { animate: false });
      } else {
        map.setView(safeCenter, zoom, { animate: false });
      }
      map.invalidateSize();
    } catch (err) {
      console.error('DeliveryMap update error:', err);
    }
  }, [fingerprint]);

  return (
    <div
      style={{ backgroundColor: '#F1F5F9', isolation: 'isolate' }}
      className={`relative w-full ${heightClass} rounded-xl overflow-hidden border border-slate-200 bg-slate-100`}
    >
      <div ref={containerRef} style={{ backgroundColor: '#F1F5F9' }} className="w-full h-full" />
      {interactivePick && (
        <div className="pointer-events-none absolute bottom-3 left-3 z-[400] rounded-lg bg-white/95 px-3 py-1.5 text-xs font-medium text-slate-700 shadow-sm border border-slate-200">
          Click anywhere or drag the red pin to set your delivery location
        </div>
      )}
    </div>
  );
};
