import { Router } from 'express';
import { eq, and, desc, ne, inArray } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  shopProfiles,
  products,
  orders,
  orderItems,
  orderEvents,
  categories,
  shopSettlements,
  notifications,
  users,
  cartItems,
} from '../../db/schema.ts';
import { requireAuth, requireRole, type AuthedRequest } from '../middleware/auth.ts';
import { autoAssignNearestRider } from '../services/dispatch.ts';
import { emitToRole, emitToUser } from '../ws.ts';
import { isSafeExternalHttpUrl } from '../security.ts';

const router = Router();
router.use('/shopkeeper', requireAuth, requireRole('shopkeeper'));

async function getMyShop(ownerId: number) {
  const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.ownerId, ownerId));
  return shop || null;
}

type DbTx = Parameters<Parameters<typeof db.transaction>[0]>[0];

async function replaceShopSeedDefaults(tx: DbTx, shopId: number): Promise<number> {
  const seedRows = await tx
    .select({ id: products.id })
    .from(products)
    .where(and(eq(products.shopId, shopId), eq(products.importSource, 'seed_default')));

  if (seedRows.length === 0) return 0;

  const seedIds = seedRows.map((r) => r.id);
  const referencedRows = await tx
    .select({ productId: orderItems.productId })
    .from(orderItems)
    .where(inArray(orderItems.productId, seedIds));
  const referencedSet = new Set(referencedRows.map((r) => r.productId));

  const deletableIds = seedIds.filter((id) => !referencedSet.has(id));
  const archiveIds = seedIds.filter((id) => referencedSet.has(id));

  if (deletableIds.length > 0) {
    await tx.delete(products).where(inArray(products.id, deletableIds));
  }
  if (archiveIds.length > 0) {
    await tx.delete(cartItems).where(inArray(cartItems.productId, archiveIds));
    await tx
      .update(products)
      .set({ importSource: 'seed_replaced', inStock: false, stockQuantity: 0 })
      .where(inArray(products.id, archiveIds));
  }

  return seedIds.length;
}

// Shopkeeper Dashboard Metrics & Finance
router.get('/shopkeeper/dashboard', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop profile not found' });

    const shopOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.shopId, shop.id))
      .orderBy(desc(orders.createdAt));

    const shopProducts = await db
      .select()
      .from(products)
      .where(and(eq(products.shopId, shop.id), ne(products.importSource, 'seed_replaced')))
      .orderBy(desc(products.salesCount));

    const settlements = await db
      .select()
      .from(shopSettlements)
      .where(eq(shopSettlements.shopId, shop.id))
      .orderBy(desc(shopSettlements.createdAt));

    const allItems = shopOrders.length
      ? await db.select().from(orderItems)
      : [];
    const orderItemsByOrder = new Map<number, typeof allItems>();
    for (const item of allItems) {
      if (!orderItemsByOrder.has(item.orderId)) orderItemsByOrder.set(item.orderId, []);
      orderItemsByOrder.get(item.orderId)!.push(item);
    }

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const monthStr = now.toISOString().slice(0, 7);

    const delivered = shopOrders.filter((o) => o.status === 'delivered');
    const dailySales = delivered
      .filter((o) => o.createdAt.toISOString().slice(0, 10) === todayStr)
      .reduce((sum, o) => sum + Number(o.subtotal), 0);
    const monthlyRevenue = delivered
      .filter((o) => o.createdAt.toISOString().slice(0, 7) === monthStr)
      .reduce((sum, o) => sum + Number(o.subtotal), 0);

    const grossSales = delivered.reduce((sum, o) => sum + Number(o.subtotal), 0);
    const totalCommission = delivered.reduce((sum, o) => sum + Number(o.commissionAmount), 0);
    const totalDiscounts = delivered.reduce((sum, o) => sum + Number(o.discountAmount), 0);
    const netEarnings = delivered.reduce((sum, o) => sum + Number(o.shopNetEarning), 0);

    const riderIds = [...new Set(shopOrders.map((o) => o.riderId).filter(Boolean) as number[])];
    const riderUsers = riderIds.length ? await db.select().from(users) : [];
    const riderNameMap = new Map(riderUsers.map((u) => [u.id, { fullName: u.fullName, phone: u.phone }]));

    res.json({
      shop,
      metrics: {
        totalOrders: shopOrders.length,
        newOrders: shopOrders.filter((o) => o.status === 'placed').length,
        preparingOrders: shopOrders.filter((o) => ['accepted', 'preparing'].includes(o.status)).length,
        readyOrders: shopOrders.filter((o) => ['ready_for_pickup', 'rider_assigned'].includes(o.status)).length,
        completedOrders: delivered.length,
        cancelledOrders: shopOrders.filter((o) => ['cancelled', 'rejected'].includes(o.status)).length,
        dailySales: Math.round(dailySales * 100) / 100,
        monthlyRevenue: Math.round(monthlyRevenue * 100) / 100,
      },
      finance: {
        grossSales: Math.round(grossSales * 100) / 100,
        commission: Math.round(totalCommission * 100) / 100,
        discounts: Math.round(totalDiscounts * 100) / 100,
        netEarnings: Math.round(netEarnings * 100) / 100,
      },
      bestSellers: shopProducts.slice(0, 5),
      inventoryAlerts: shopProducts.filter((p) => !p.inStock || p.stockQuantity <= 5),
      orders: shopOrders.map((o) => ({
        ...o,
        items: orderItemsByOrder.get(o.id) || [],
        riderInfo: o.riderId ? riderNameMap.get(o.riderId) || null : null,
      })),
      products: shopProducts,
      settlements,
    });
  } catch (error) {
    console.error('Shopkeeper dashboard error:', error);
    res.status(500).json({ error: 'Failed to load shop dashboard' });
  }
});

// Update Shop Delivery & Store Settings
router.patch('/shopkeeper/settings', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });

    const {
      isOpen,
      deliveryMode,
      ownRiderName,
      ownRiderPhone,
      openingHours,
      estimatedPrepMins,
      deliveryFee,
      bankName,
      bankAccountTitle,
      bankAccountNumber,
    } = req.body as Record<string, unknown>;

    const [updated] = await db
      .update(shopProfiles)
      .set({
        ...(typeof isOpen === 'boolean' ? { isOpen } : {}),
        ...(deliveryMode === 'own_rider' || deliveryMode === 'shared_rider' ? { deliveryMode } : {}),
        ...(typeof ownRiderName === 'string' ? { ownRiderName: ownRiderName.trim() } : {}),
        ...(typeof ownRiderPhone === 'string' ? { ownRiderPhone: ownRiderPhone.trim() } : {}),
        ...(typeof openingHours === 'string' ? { openingHours: openingHours.trim() } : {}),
        ...(typeof estimatedPrepMins === 'number' ? { estimatedPrepMins } : {}),
        ...(typeof deliveryFee === 'number' ? { deliveryFee: deliveryFee.toFixed(2) } : {}),
        ...(typeof bankName === 'string' ? { bankName: bankName.trim() } : {}),
        ...(typeof bankAccountTitle === 'string' ? { bankAccountTitle: bankAccountTitle.trim() } : {}),
        ...(typeof bankAccountNumber === 'string' ? { bankAccountNumber: bankAccountNumber.trim() } : {}),
      })
      .where(eq(shopProfiles.id, shop.id))
      .returning();

    res.json({ shop: updated });
  } catch (error) {
    console.error('Shopkeeper settings error:', error);
    res.status(500).json({ error: 'Failed to update shop settings' });
  }
});

// Shopkeeper Order Workflow Transitions
router.post('/shopkeeper/orders/:id/status', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });
    if (shop.approvalStatus !== 'approved') {
      return res.status(403).json({ error: 'Only approved shops can process orders' });
    }

    const orderId = Number(req.params.id);
    const { action, prepMins, reason } = req.body as {
      action?: 'accept' | 'reject' | 'preparing' | 'ready_for_pickup' | 'handover' | 'own_rider_delivered';
      prepMins?: number;
      reason?: string;
    };

    const [order] = await db
      .select()
      .from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.shopId, shop.id)));
    if (!order) return res.status(404).json({ error: 'Order not found for your shop' });

    let nextStatus = order.status;
    let note = '';

    if (action === 'accept' && order.status === 'placed') {
      nextStatus = 'accepted';
      note = `Accepted by ${shop.name}${prepMins ? ` (Prep ~${prepMins} mins)` : ''}`;
    } else if (action === 'reject' && order.status === 'placed') {
      nextStatus = 'rejected';
      note = reason?.trim() || 'Rejected by shopkeeper';
    } else if (action === 'preparing' && ['accepted', 'placed'].includes(order.status)) {
      nextStatus = 'preparing';
      note = 'Kitchen/store started preparing order';
    } else if (action === 'ready_for_pickup' && ['accepted', 'preparing'].includes(order.status)) {
      nextStatus = 'ready_for_pickup';
      note = 'Order packed and ready for pickup';
    } else if (action === 'handover' && ['ready_for_pickup', 'rider_assigned'].includes(order.status)) {
      nextStatus = order.deliveryMode === 'own_rider' ? 'on_the_way' : 'picked_up';
      note =
        order.deliveryMode === 'own_rider'
          ? `Dispatched with shop own rider (${shop.ownRiderName || 'Store Rider'})`
          : 'Handed over to DELIVOO rider';
    } else if (action === 'own_rider_delivered' && order.deliveryMode === 'own_rider' && ['on_the_way', 'picked_up', 'ready_for_pickup'].includes(order.status)) {
      nextStatus = 'delivered';
      note = 'Delivered by shop own rider';
    } else {
      return res.status(400).json({ error: `Invalid transition from ${order.status} via ${action}` });
    }

    const [updated] = await db
      .update(orders)
      .set({
        status: nextStatus,
        ...(prepMins ? { estimatedPrepMins: prepMins } : {}),
        ...(nextStatus === 'rejected' ? { cancellationReason: note } : {}),
        ...(nextStatus === 'delivered' && order.paymentMethod === 'cod' ? { paymentStatus: 'paid' } : {}),
        updatedAt: new Date(),
      })
      .where(eq(orders.id, order.id))
      .returning();

    await db.insert(orderEvents).values({
      orderId: order.id,
      status: nextStatus,
      actorId: req.authUser!.id,
      actorRole: 'shopkeeper',
      notes: note,
    });

    // Notify customer
    const [custNotif] = await db
      .insert(notifications)
      .values({
        userId: order.customerId,
        title: `Order ${order.orderNumber} Update`,
        message: note,
        type: 'order_status',
        referenceId: String(order.id),
      })
      .returning();
    emitToUser(order.customerId, 'notification:new', custNotif);
    emitToUser(order.customerId, 'order:updated', updated);
    emitToRole('admin', 'order:updated', updated);

    // Trigger intelligent automatic rider assignment for shared rider mode when ready_for_pickup or accepted
    let dispatchResult = null;
    if (shop.deliveryMode === 'shared_rider' && (nextStatus === 'ready_for_pickup' || nextStatus === 'accepted') && !updated.riderId) {
      dispatchResult = await autoAssignNearestRider(order.id);
    }

    res.json({ order: updated, dispatchResult });
  } catch (error) {
    console.error('Shopkeeper order status error:', error);
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

// Product CRUD
router.get('/shopkeeper/products', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });
    const list = await db
      .select()
      .from(products)
      .where(and(eq(products.shopId, shop.id), ne(products.importSource, 'seed_replaced')))
      .orderBy(desc(products.id));
    res.json({ products: list });
  } catch (error) {
    console.error('Get shop products error:', error);
    res.status(500).json({ error: 'Failed to load products' });
  }
});

router.post('/shopkeeper/products', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });

    const {
      name,
      description,
      price,
      discountedPrice,
      stockQuantity,
      categoryId,
      unitLabel,
      imageUrl,
      barcode,
      expiryDate,
      manufacturingDate,
      freshnessInfo,
      variants,
    } = req.body as Record<string, unknown>;

    if (!name || !price) {
      return res.status(400).json({ error: 'Product name and price are required' });
    }

    const qty = Number(stockQuantity ?? 20);
    const result = await db.transaction(async (tx) => {
      const replacedDefaultsCount = await replaceShopSeedDefaults(tx, shop.id);
      const [created] = await tx
        .insert(products)
        .values({
          shopId: shop.id,
          categoryId: Number(categoryId || shop.categoryId),
          name: String(name).trim(),
          description: String(description || 'Fresh quality product').trim(),
          price: Number(price).toFixed(2),
          discountedPrice: discountedPrice ? Number(discountedPrice).toFixed(2) : null,
          stockQuantity: qty,
          inStock: qty > 0,
          unitLabel: unitLabel ? String(unitLabel) : '1 item',
          imageUrl: imageUrl ? String(imageUrl) : shop.logoUrl,
          barcode: barcode ? String(barcode).trim() : null,
          expiryDate: expiryDate ? String(expiryDate) : null,
          manufacturingDate: manufacturingDate ? String(manufacturingDate) : null,
          freshnessInfo: freshnessInfo ? String(freshnessInfo) : null,
          variants: Array.isArray(variants) ? (variants as Array<{ name: string; priceDelta: number }>) : [],
          importSource: 'manual',
        })
        .returning();
      return { created, replacedDefaultsCount };
    });

    res.status(201).json({ product: result.created, replacedDefaultsCount: result.replacedDefaultsCount });
  } catch (error) {
    console.error('Add product error:', error);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

router.patch('/shopkeeper/products/:id', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });

    const prodId = Number(req.params.id);
    const {
      name,
      description,
      price,
      discountedPrice,
      stockQuantity,
      inStock,
      imageUrl,
      expiryDate,
      manufacturingDate,
      freshnessInfo,
    } = req.body as Record<string, unknown>;

    const [updated] = await db
      .update(products)
      .set({
        ...(typeof name === 'string' ? { name: name.trim() } : {}),
        ...(typeof description === 'string' ? { description: description.trim() } : {}),
        ...(price !== undefined ? { price: Number(price).toFixed(2) } : {}),
        ...(discountedPrice !== undefined
          ? { discountedPrice: discountedPrice ? Number(discountedPrice).toFixed(2) : null }
          : {}),
        ...(typeof stockQuantity === 'number' ? { stockQuantity } : {}),
        ...(typeof inStock === 'boolean' ? { inStock } : {}),
        ...(typeof imageUrl === 'string' ? { imageUrl } : {}),
        ...(typeof expiryDate === 'string' ? { expiryDate: expiryDate || null } : {}),
        ...(typeof manufacturingDate === 'string' ? { manufacturingDate: manufacturingDate || null } : {}),
        ...(typeof freshnessInfo === 'string' ? { freshnessInfo: freshnessInfo || null } : {}),
      })
      .where(and(eq(products.id, prodId), eq(products.shopId, shop.id)))
      .returning();

    if (!updated) return res.status(404).json({ error: 'Product not found' });
    res.json({ product: updated });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

router.delete('/shopkeeper/products/:id', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });
    const prodId = Number(req.params.id);
    await db.delete(products).where(and(eq(products.id, prodId), eq(products.shopId, shop.id)));
    res.json({ deleted: true });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// 5-Method Product Import System
// Method 1 & 3: Website URL or Online Catalog Link Import (SSRF-safe + robots/access respectful)
async function extractProductsFromExternalUrl(rawUrl: string, source: 'url' | 'catalog_link') {
  const check = isSafeExternalHttpUrl(rawUrl);
  if (!check.safe || !check.url) {
    throw new Error(check.reason || 'Unsafe or invalid URL');
  }

  const resp = await fetch(check.url.toString(), {
    headers: { 'User-Agent': 'DELIVOO-CatalogImporter/1.0 (+https://delivoo.app)' },
    signal: AbortSignal.timeout(8000),
  });

  if (!resp.ok) {
    return {
      accessible: false,
      statusCode: resp.status,
      message: `Target site returned HTTP ${resp.status}. Please review and complete fields manually in the preview below.`,
      items: [
        {
          name: check.url.hostname.replace(/^www\./, '') + ' Item',
          price: '500',
          description: `Imported from ${check.url.toString()} (manual verification required)`,
          stockQuantity: 15,
          imageUrl: '',
          expiryDate: '',
          manufacturingDate: '',
          freshnessInfo: '',
          importSource: source,
        },
      ],
    };
  }

  const contentType = resp.headers.get('content-type') || '';
  const bodyText = await resp.text();
  const extracted: Array<Record<string, unknown>> = [];

  if (contentType.includes('application/json')) {
    try {
      const parsed = JSON.parse(bodyText);
      const list = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.products) ? parsed.products : [parsed];
      for (const p of list.slice(0, 25)) {
        if (p && typeof p === 'object') {
          extracted.push({
            name: String(p.name || p.title || 'Catalog Item'),
            price: String(p.price || p.amount || '500'),
            description: String(p.description || 'Imported from online catalog link'),
            stockQuantity: Number(p.stock || p.stockQuantity || 20),
            imageUrl: String(p.image || p.imageUrl || ''),
            expiryDate: String(p.expiryDate || ''),
            manufacturingDate: String(p.manufacturingDate || ''),
            freshnessInfo: String(p.freshnessInfo || ''),
            importSource: source,
          });
        }
      }
    } catch {
      // Fallback below
    }
  } else {
    // Parse JSON-LD Schema.org Product or OpenGraph tags from HTML safely
    const ldMatches = bodyText.matchAll(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi);
    for (const match of ldMatches) {
      try {
        const jsonLd = JSON.parse(match[1]);
        const nodes = Array.isArray(jsonLd) ? jsonLd : [jsonLd];
        for (const node of nodes) {
          if (node?.['@type'] === 'Product' && node.name) {
            const offer = Array.isArray(node.offers) ? node.offers[0] : node.offers;
            extracted.push({
              name: String(node.name).slice(0, 120),
              price: String(offer?.price || '500'),
              description: String(node.description || '').slice(0, 300),
              stockQuantity: 20,
              imageUrl: Array.isArray(node.image) ? String(node.image[0] || '') : String(node.image || ''),
              expiryDate: '',
              manufacturingDate: '',
              freshnessInfo: '',
              importSource: source,
            });
          }
        }
      } catch {
        // Ignore malformed JSON-LD block
      }
    }

    if (extracted.length === 0) {
      const ogTitle = bodyText.match(/<meta[^>]*property=["']og:title["'][^>]*content=["']([^"']+)["']/i)?.[1]
        || bodyText.match(/<title>([^<]+)<\/title>/i)?.[1];
      const ogDesc = bodyText.match(/<meta[^>]*property=["']og:description["'][^>]*content=["']([^"']+)["']/i)?.[1];
      const ogImg = bodyText.match(/<meta[^>]*property=["']og:image["'][^>]*content=["']([^"']+)["']/i)?.[1];
      const priceMeta = bodyText.match(/<meta[^>]*property=["']product:price:amount["'][^>]*content=["']([^"']+)["']/i)?.[1];

      extracted.push({
        name: (ogTitle || 'Imported Web Product').trim().slice(0, 120),
        price: priceMeta || '500',
        description: (ogDesc || `Extracted from ${check.url.hostname}. Please verify price and stock before saving.`).trim().slice(0, 300),
        stockQuantity: 20,
        imageUrl: ogImg || '',
        expiryDate: '',
        manufacturingDate: '',
        freshnessInfo: '',
        importSource: source,
      });
    }
  }

  return {
    accessible: true,
    statusCode: resp.status,
    message: `Extracted ${extracted.length} item(s). Review and adjust before saving.`,
    items: extracted,
  };
}

router.post('/shopkeeper/import/url', async (req: AuthedRequest, res) => {
  try {
    const { url } = req.body as { url?: string };
    if (!url) return res.status(400).json({ error: 'Website URL is required' });
    const result = await extractProductsFromExternalUrl(url, 'url');
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Unable to extract URL' });
  }
});

router.post('/shopkeeper/import/catalog-link', async (req: AuthedRequest, res) => {
  try {
    const { url } = req.body as { url?: string };
    if (!url) return res.status(400).json({ error: 'Catalog link is required' });
    const result = await extractProductsFromExternalUrl(url, 'catalog_link');
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Unable to import catalog link' });
  }
});

// Method 2: CSV / Excel-compatible table parser
router.post('/shopkeeper/import/csv', async (req: AuthedRequest, res) => {
  try {
    const { csvText } = req.body as { csvText?: string };
    if (!csvText || !csvText.trim()) {
      return res.status(400).json({ error: 'CSV content is empty' });
    }

    const lines = csvText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length < 2) {
      return res.status(400).json({ error: 'CSV must include a header row and at least one product row' });
    }

    const splitCsvLine = (line: string): string[] => {
      const cols: string[] = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
          inQuotes = !inQuotes;
        } else if ((ch === ',' || ch === '\t') && !inQuotes) {
          cols.push(current.trim());
          current = '';
        } else {
          current += ch;
        }
      }
      cols.push(current.trim());
      return cols;
    };

    const headers = splitCsvLine(lines[0]).map((h) => h.toLowerCase());
    const idx = (names: string[]) => headers.findIndex((h) => names.some((n) => h.includes(n)));

    const nameIdx = idx(['name', 'title', 'product']);
    const priceIdx = idx(['price', 'amount', 'cost']);
    const descIdx = idx(['desc', 'detail']);
    const stockIdx = idx(['stock', 'qty', 'quantity']);
    const imgIdx = idx(['image', 'img', 'photo', 'url']);
    const expIdx = idx(['expir', 'exp']);
    const mfgIdx = idx(['mfg', 'manufactur']);
    const freshIdx = idx(['fresh']);
    const barcodeIdx = idx(['barcode', 'ean', 'upc']);

    const items = lines.slice(1, 101).map((line) => {
      const cols = splitCsvLine(line);
      return {
        name: cols[nameIdx >= 0 ? nameIdx : 0] || 'Imported Item',
        price: cols[priceIdx >= 0 ? priceIdx : 1]?.replace(/[^0-9.]/g, '') || '0',
        description: cols[descIdx >= 0 ? descIdx : 2] || 'Imported via spreadsheet',
        stockQuantity: Number(cols[stockIdx >= 0 ? stockIdx : 3] || 20) || 20,
        imageUrl: imgIdx >= 0 ? cols[imgIdx] || '' : '',
        expiryDate: expIdx >= 0 ? cols[expIdx] || '' : '',
        manufacturingDate: mfgIdx >= 0 ? cols[mfgIdx] || '' : '',
        freshnessInfo: freshIdx >= 0 ? cols[freshIdx] || '' : '',
        barcode: barcodeIdx >= 0 ? cols[barcodeIdx] || '' : '',
        importSource: 'csv',
      };
    });

    res.json({ items });
  } catch (error) {
    console.error('CSV parse error:', error);
    res.status(400).json({ error: 'Failed to parse CSV file' });
  }
});

// Method 4: Barcode Lookup using Open Food Facts Public Database
router.get('/shopkeeper/import/barcode/:code', async (req: AuthedRequest, res) => {
  try {
    const code = req.params.code.replace(/[^0-9A-Za-z]/g, '');
    if (!code || code.length < 4) {
      return res.status(400).json({ error: 'Enter a valid barcode number' });
    }

    // Check internal DB first
    const [existing] = await db.select().from(products).where(eq(products.barcode, code)).limit(1);
    if (existing) {
      return res.json({
        found: true,
        source: 'delivoo_catalog',
        item: {
          name: existing.name,
          price: existing.price,
          description: existing.description,
          stockQuantity: 20,
          imageUrl: existing.imageUrl || '',
          expiryDate: existing.expiryDate || '',
          manufacturingDate: existing.manufacturingDate || '',
          freshnessInfo: existing.freshnessInfo || '',
          barcode: code,
          importSource: 'barcode',
        },
      });
    }

    const resp = await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json`, {
      headers: { 'User-Agent': 'DELIVOO-Marketplace/1.0' },
      signal: AbortSignal.timeout(7000),
    });

    if (resp.ok) {
      const json = (await resp.json()) as {
        status?: number;
        product?: {
          product_name?: string;
          generic_name?: string;
          brands?: string;
          image_front_url?: string;
          quantity?: string;
          expiration_date?: string;
        };
      };
      if (json.status === 1 && json.product) {
        return res.json({
          found: true,
          source: 'openfoodfacts',
          item: {
            name: json.product.product_name || `Product ${code}`,
            price: '450',
            description: [json.product.brands, json.product.generic_name, json.product.quantity].filter(Boolean).join(' · ') || 'Verified barcode item',
            stockQuantity: 25,
            imageUrl: json.product.image_front_url || '',
            expiryDate: json.product.expiration_date || '',
            manufacturingDate: '',
            freshnessInfo: 'Lookup via Open Food Facts',
            barcode: code,
            importSource: 'barcode',
          },
        });
      }
    }

    res.json({
      found: false,
      source: 'manual_fallback',
      message: 'Barcode not found in public registry. Complete details manually below.',
      item: {
        name: `Barcode Item ${code}`,
        price: '0',
        description: '',
        stockQuantity: 20,
        imageUrl: '',
        expiryDate: '',
        manufacturingDate: '',
        freshnessInfo: '',
        barcode: code,
        importSource: 'barcode',
      },
    });
  } catch (error) {
    console.error('Barcode lookup error:', error);
    res.status(500).json({ error: 'Barcode lookup failed' });
  }
});

// Commit previewed imported products into DB
router.post('/shopkeeper/import/commit', async (req: AuthedRequest, res) => {
  try {
    const shop = await getMyShop(req.authUser!.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });

    const { items } = req.body as {
      items?: Array<{
        name: string;
        price: string | number;
        description?: string;
        stockQuantity?: number;
        imageUrl?: string;
        expiryDate?: string;
        manufacturingDate?: string;
        freshnessInfo?: string;
        barcode?: string;
        importSource?: string;
        categoryId?: number;
      }>;
    };

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'No items to import' });
    }

    const toInsert = items
      .filter((i) => i.name && Number(i.price) > 0)
      .map((i) => ({
        shopId: shop.id,
        categoryId: Number(i.categoryId || shop.categoryId),
        name: i.name.trim(),
        description: (i.description || 'Quality imported product').trim(),
        price: Number(i.price).toFixed(2),
        stockQuantity: Number(i.stockQuantity ?? 20),
        inStock: Number(i.stockQuantity ?? 20) > 0,
        imageUrl: i.imageUrl?.trim() || shop.logoUrl,
        expiryDate: i.expiryDate?.trim() || null,
        manufacturingDate: i.manufacturingDate?.trim() || null,
        freshnessInfo: i.freshnessInfo?.trim() || null,
        barcode: i.barcode?.trim() || null,
        importSource: i.importSource || 'manual',
      }));

    if (toInsert.length === 0) {
      return res.status(400).json({ error: 'Each imported product needs a name and price > 0' });
    }

    const result = await db.transaction(async (tx) => {
      const replacedDefaultsCount = await replaceShopSeedDefaults(tx, shop.id);
      const inserted = await tx.insert(products).values(toInsert).returning();
      return { inserted, replacedDefaultsCount };
    });
    res.status(201).json({
      importedCount: result.inserted.length,
      products: result.inserted,
      replacedDefaultsCount: result.replacedDefaultsCount,
    });
  } catch (error) {
    console.error('Import commit error:', error);
    res.status(500).json({ error: 'Failed to save imported products' });
  }
});

export default router;
