import { Router } from 'express';
import { GoogleGenAI } from '@google/genai';
import { eq, desc } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  notifications,
  supportTickets,
  categories,
  orders,
  shopProfiles,
} from '../../db/schema.ts';
import { optionalAuth, requireAuth, type AuthedRequest } from '../middleware/auth.ts';
import { emitToRole, emitToUser } from '../ws.ts';
import { createRateLimiter } from '../security.ts';

const router = Router();
const aiRateLimiter = createRateLimiter(20, 60_000);

// Notifications
router.get('/notifications', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const list = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, req.authUser!.id))
      .orderBy(desc(notifications.createdAt))
      .limit(40);
    res.json({ notifications: list });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ error: 'Failed to load notifications' });
  }
});

router.patch('/notifications/read-all', requireAuth, async (req: AuthedRequest, res) => {
  try {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, req.authUser!.id));
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to mark notifications read' });
  }
});

// Support Tickets
router.get('/support/tickets', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const list =
      authUser.role === 'admin'
        ? await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt))
        : await db
            .select()
            .from(supportTickets)
            .where(eq(supportTickets.userId, authUser.id))
            .orderBy(desc(supportTickets.createdAt));
    res.json({ tickets: list });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load support tickets' });
  }
});

router.post('/support/tickets', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const authUser = req.authUser!;
    const { category, subject, description, orderId } = req.body as {
      category?: string;
      subject?: string;
      description?: string;
      orderId?: number;
    };
    if (!subject || !description) {
      return res.status(400).json({ error: 'Subject and description are required' });
    }

    const [ticket] = await db
      .insert(supportTickets)
      .values({
        userId: authUser.id,
        userRole: authUser.role,
        orderId: orderId ? Number(orderId) : null,
        category: category || 'general',
        subject: subject.trim(),
        description: description.trim(),
      })
      .returning();

    emitToRole('admin', 'support:new_ticket', ticket);
    res.status(201).json({ ticket });
  } catch (error) {
    console.error('Create ticket error:', error);
    res.status(500).json({ error: 'Failed to create support ticket' });
  }
});

router.patch('/support/tickets/:id', requireAuth, async (req: AuthedRequest, res) => {
  try {
    if (req.authUser!.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can resolve support tickets' });
    }
    const id = Number(req.params.id);
    const { status, resolutionNotes } = req.body as { status?: string; resolutionNotes?: string };
    const [updated] = await db
      .update(supportTickets)
      .set({
        ...(status ? { status } : {}),
        ...(resolutionNotes ? { resolutionNotes } : {}),
        resolvedBy: req.authUser!.id,
        updatedAt: new Date(),
      })
      .where(eq(supportTickets.id, id))
      .returning();

    if (!updated) return res.status(404).json({ error: 'Ticket not found' });

    const [notif] = await db
      .insert(notifications)
      .values({
        userId: updated.userId,
        title: 'Support Ticket Updated',
        message: `Ticket "${updated.subject}" is now ${updated.status}.`,
        type: 'support',
        referenceId: String(updated.id),
      })
      .returning();
    emitToUser(updated.userId, 'notification:new', notif);

    res.json({ ticket: updated });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update support ticket' });
  }
});

// AI Help Chatbot (Gemini 4 Hydrogen via server-side @google/genai SDK)
router.post('/ai/help-chat', optionalAuth, aiRateLimiter, async (req: AuthedRequest, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      return res.status(503).json({
        error: 'Gemini AI Help service is not configured. Please set GEMINI_API_KEY in Settings > Secrets.',
      });
    }

    const { message, history } = req.body as {
      message?: string;
      history?: Array<{ role: 'user' | 'assistant'; text: string }>;
    };

    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Please type a question for the DELIVOO Help Assistant.' });
    }

    // Build safe non-PII marketplace context
    const activeCats = await db.select({ name: categories.name }).from(categories).where(eq(categories.isActive, true));
    const catList = activeCats.map((c) => c.name).join(', ');

    let userContext = 'Visitor (not signed in).';
    if (req.authUser) {
      const recentOrders = await db
        .select({
          orderNumber: orders.orderNumber,
          status: orders.status,
          totalAmount: orders.totalAmount,
          paymentStatus: orders.paymentStatus,
        })
        .from(orders)
        .where(eq(orders.customerId, req.authUser.id))
        .orderBy(desc(orders.createdAt))
        .limit(3);

      const shopCount =
        req.authUser.role === 'shopkeeper'
          ? (await db.select({ name: shopProfiles.name }).from(shopProfiles).where(eq(shopProfiles.ownerId, req.authUser.id))).length
          : 0;

      userContext = `Signed-in user role: ${req.authUser.role}, accountStatus: ${req.authUser.accountStatus}, shopCount: ${shopCount}. Recent orders: ${
        recentOrders.length
          ? recentOrders.map((o) => `${o.orderNumber} (${o.status}, Rs ${o.totalAmount}, payment: ${o.paymentStatus})`).join('; ')
          : 'none'
      }.`;
    }

    const systemInstruction = [
      'You are the DELIVOO Marketplace Help Assistant. Answer concisely, warmly, and accurately in 2-5 sentences unless steps are needed.',
      `Marketplace categories: ${catList}.`,
      'DELIVOO supports 4 roles: Customer (browse shops, cart, checkout with Cash on Delivery or Online Payment, live tracking, reviews, cancellations before preparation), Shopkeeper (manage orders, Own Rider vs DELIVOO Shared Rider delivery mode, 5-method product import: URL, CSV, Catalog Link, Barcode, Manual), Rider (go online when approved, accept/reject offers, live GPS tracking, earnings), and Admin (verifications, shop/rider/order/finance/support management).',
      'Privacy & Safety: CNIC numbers are masked automatically, raw card details are never stored, and users can permanently delete their account inside Privacy & Safety > Danger Zone.',
      `Current user context: ${userContext}`,
      'Never invent fake order statuses or ask for passwords, full CNIC, or API keys.',
    ].join(' ');

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const conversationLines = (Array.isArray(history) ? history.slice(-6) : [])
      .map((h) => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.text}`)
      .join('\n');

    const prompt = conversationLines
      ? `${conversationLines}\nUser: ${message.trim()}`
      : message.trim();

    let replyText = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          systemInstruction,
        },
      });
      replyText = response.text || '';
    } catch (primaryErr) {
      const msg = primaryErr instanceof Error ? primaryErr.message : '';
      if (msg.includes('503') || msg.includes('UNAVAILABLE') || msg.includes('high demand')) {
        const fallbackResp = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: prompt,
          config: {
            systemInstruction,
          },
        });
        replyText = fallbackResp.text || '';
      } else {
        throw primaryErr;
      }
    }

    res.json({
      reply: replyText || 'I could not generate a response right now. Please try rephrasing your question.',
    });
  } catch (error) {
    console.error('AI help chat error:', error);
    const errMsg = error instanceof Error ? error.message : 'AI assistant error';
    res.status(502).json({
      error: `Unable to reach DELIVOO AI Help Assistant: ${errMsg}`,
    });
  }
});

export default router;
