import 'dotenv/config';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import authRoutes from './src/server/routes/auth.ts';
import marketplaceRoutes from './src/server/routes/marketplace.ts';
import orderRoutes from './src/server/routes/orders.ts';
import shopkeeperRoutes from './src/server/routes/shopkeeper.ts';
import riderRoutes from './src/server/routes/rider.ts';
import adminRoutes from './src/server/routes/admin.ts';
import supportAndAiRoutes from './src/server/routes/supportAndAi.ts';
import { initWebSocketServer } from './src/server/ws.ts';
import { ensureAdminHierarchyColumns } from './src/db/index.ts';

async function bootstrap() {
  await ensureAdminHierarchyColumns();
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  const isTrustedOrigin = (originHeader: string, hostHeader?: string): boolean => {
    const appUrl = process.env.APP_URL;
    if (
      (appUrl && originHeader === appUrl) ||
      originHeader.startsWith('http://localhost:') ||
      originHeader.startsWith('http://127.0.0.1:') ||
      originHeader.endsWith('.run.app')
    ) {
      return true;
    }
    if (hostHeader) {
      try {
        return new URL(originHeader).host === hostHeader;
      } catch {
        return false;
      }
    }
    return false;
  };

  // Scoped CORS policy + Origin enforcement on cookie-authenticated mutating calls
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    const hostHeader = req.headers.host;
    if (origin && isTrustedOrigin(origin, hostHeader)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    }
    if (req.method === 'OPTIONS') {
      return res.status(204).end();
    }

    const isMutating = ['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method);
    const hasCookie = Boolean(req.headers.cookie && req.headers.cookie.includes('delivoo_session='));
    const hasBearer = Boolean(req.headers.authorization?.startsWith('Bearer '));
    if (isMutating && req.path.startsWith('/api/') && hasCookie && !hasBearer) {
      if (origin && !isTrustedOrigin(origin, hostHeader)) {
        return res.status(403).json({ error: 'Cross-site request origin rejected' });
      }
    }
    next();
  });

  // Health Endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'delivoo-marketplace',
      timestamp: new Date().toISOString(),
    });
  });

  // API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api', authRoutes); // also exposes /api/verification/resubmit & /api/account/*
  app.use('/api', marketplaceRoutes);
  app.use('/api', orderRoutes);
  app.use('/api', shopkeeperRoutes);
  app.use('/api', riderRoutes);
  app.use('/api', adminRoutes);
  app.use('/api', supportAndAiRoutes);

  // Unknown API routes return clean JSON 404
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found' });
  });

  const server = http.createServer(app);
  initWebSocketServer(server);

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found. Run npm run build.');
      }
    });
  }

  const port = Number(process.env.PORT || 3000);
  server.listen(port, '0.0.0.0', () => {
    console.log(`DELIVOO server listening on http://0.0.0.0:${port}`);
  });
}

bootstrap().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
