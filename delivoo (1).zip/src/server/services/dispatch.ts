import { eq, and, notInArray } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  orders,
  orderEvents,
  riderProfiles,
  riderAssignments,
  shopProfiles,
  users,
  notifications,
} from '../../db/schema.ts';
import { emitToRole, emitToUser } from '../ws.ts';

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

export function estimateMinutesFromDistance(distanceKm: number, vehicleType = 'motorbike'): number {
  const speedKmh = vehicleType === 'bicycle' ? 14 : vehicleType === 'car' ? 28 : 30;
  const travelMins = Math.ceil((distanceKm / speedKmh) * 60);
  return Math.max(8, travelMins + 6);
}

export async function autoAssignNearestRider(orderId: number): Promise<{
  assigned: boolean;
  riderId?: number;
  assignmentId?: number;
  reason?: string;
}> {
  const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
  if (!order) return { assigned: false, reason: 'Order not found' };
  if (order.deliveryMode === 'own_rider') {
    return { assigned: false, reason: 'Shop uses its own rider' };
  }
  if (order.riderId) {
    return { assigned: true, riderId: order.riderId };
  }

  const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, order.shopId));
  if (!shop) return { assigned: false, reason: 'Shop not found' };

  // Find riders who already rejected or timed out for this order
  const previousOffers = await db
    .select({ riderId: riderAssignments.riderId })
    .from(riderAssignments)
    .where(eq(riderAssignments.orderId, orderId));
  const excludedIds = previousOffers.map((o) => o.riderId);

  const candidatesQuery = db
    .select({
      userId: users.id,
      fullName: users.fullName,
      vehicleType: riderProfiles.vehicleType,
      currentLat: riderProfiles.currentLat,
      currentLng: riderProfiles.currentLng,
      activeOrdersCount: riderProfiles.activeOrdersCount,
      rating: riderProfiles.rating,
    })
    .from(riderProfiles)
    .innerJoin(users, eq(riderProfiles.userId, users.id))
    .where(
      and(
        eq(users.role, 'rider'),
        eq(users.accountStatus, 'approved'),
        eq(riderProfiles.isOnline, true),
        eq(riderProfiles.isAvailable, true),
        excludedIds.length > 0 ? notInArray(users.id, excludedIds) : undefined
      )
    );

  const candidates = await candidatesQuery;
  const eligible = candidates.filter((c) => c.activeOrdersCount < 3);

  if (eligible.length === 0) {
    // Notify admins that manual assignment is needed
    const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, 'admin'));
    for (const adm of admins) {
      const [notif] = await db
        .insert(notifications)
        .values({
          userId: adm.id,
          title: 'Unassigned Delivery Needs Rider',
          message: `Order ${order.orderNumber} from ${shop.name} has no available nearby rider.`,
          type: 'unassigned_delivery',
          referenceId: String(order.id),
        })
        .returning();
      emitToUser(adm.id, 'notification:new', notif);
    }
    emitToRole('admin', 'order:unassigned', { orderId: order.id, orderNumber: order.orderNumber });
    return { assigned: false, reason: 'No approved online riders available right now' };
  }

  // Score riders by distance + workload penalty - rating bonus
  const scored = eligible
    .map((c) => {
      const dist = haversineKm(shop.lat, shop.lng, c.currentLat ?? shop.lat, c.currentLng ?? shop.lng);
      const score = dist * 2 + c.activeOrdersCount * 5 - c.rating;
      return { ...c, distanceKm: dist, score };
    })
    .sort((a, b) => a.score - b.score);

  const best = scored[0];
  const dropDist = haversineKm(shop.lat, shop.lng, order.deliveryLat, order.deliveryLng);
  const etaMins = estimateMinutesFromDistance(best.distanceKm + dropDist, best.vehicleType);

  const [assignment] = await db
    .insert(riderAssignments)
    .values({
      orderId: order.id,
      riderId: best.userId,
      assignmentType: 'auto',
      status: 'offered',
      distanceKm: Math.round((best.distanceKm + dropDist) * 100) / 100,
      estimatedMinutes: etaMins,
    })
    .returning();

  await db.insert(orderEvents).values({
    orderId: order.id,
    status: order.status,
    actorRole: 'system',
    notes: `Delivery request offered to nearby rider ${best.fullName} (${best.distanceKm} km away)`,
  });

  const [notif] = await db
    .insert(notifications)
    .values({
      userId: best.userId,
      title: 'New Delivery Request',
      message: `Pickup from ${shop.name} · Earn Rs ${order.riderEarning} · ${assignment.distanceKm} km`,
      type: 'delivery_request',
      referenceId: String(order.id),
    })
    .returning();

  emitToUser(best.userId, 'notification:new', notif);
  emitToUser(best.userId, 'rider:offer', {
    assignment,
    order: {
      id: order.id,
      orderNumber: order.orderNumber,
      shopName: shop.name,
      shopAddress: shop.address,
      shopLat: shop.lat,
      shopLng: shop.lng,
      deliveryAddress: order.deliveryAddress,
      deliveryLat: order.deliveryLat,
      deliveryLng: order.deliveryLng,
      riderEarning: order.riderEarning,
      totalAmount: order.totalAmount,
      paymentMethod: order.paymentMethod,
    },
  });

  return { assigned: true, riderId: best.userId, assignmentId: assignment.id };
}
