import nodemailer from 'nodemailer';
import { isSafeExternalHttpUrl } from '../security.ts';

export type OtpChannel = 'email' | 'phone' | 'password_reset';

export interface OtpDispatchResult {
  channel: OtpChannel;
  maskedTarget: string;
  delivered: boolean;
  provider: 'smtp' | 'resend' | 'twilio' | 'sms_webhook' | 'not_configured';
  expiresInMinutes: number;
  message: string;
}

export function maskEmailTarget(email: string): string {
  const trimmed = email.trim();
  const atIdx = trimmed.indexOf('@');
  if (atIdx <= 1) return '***@***';
  const local = trimmed.slice(0, atIdx);
  const domain = trimmed.slice(atIdx + 1);
  return `${local[0]}***${local.length > 2 ? local.slice(-1) : ''}@${domain}`;
}

export function maskPhoneTarget(phone: string): string {
  const trimmed = phone.trim();
  if (trimmed.length <= 4) return '****';
  return `${trimmed.slice(0, Math.min(4, trimmed.length - 2))}${'*'.repeat(Math.max(4, trimmed.length - 6))}${trimmed.slice(-2)}`;
}

async function sendEmailOtp(to: string, code: string, purpose: 'verification' | 'password_reset'): Promise<{ delivered: boolean; provider: 'smtp' | 'resend' | 'not_configured' }> {
  const subject =
    purpose === 'password_reset'
      ? 'DELIVOO Password Reset Code'
      : 'DELIVOO Email Verification Code';
  const text = `Your DELIVOO ${purpose === 'password_reset' ? 'password reset' : 'verification'} code is ${code}. It expires in 15 minutes. Do not share this code with anyone.`;
  const html = `
    <div style="font-family:system-ui,-apple-system,sans-serif;max-width:480px;margin:0 auto;padding:24px;border:1px solid #e2e8f0;border-radius:12px;">
      <h2 style="margin:0 0 8px;color:#0f172a;">DELIVOO Security Verification</h2>
      <p style="margin:0 0 16px;color:#475569;font-size:14px;">Use the 6-digit code below to complete your ${purpose === 'password_reset' ? 'password reset' : 'account verification'}:</p>
      <div style="font-size:28px;font-weight:700;letter-spacing:6px;color:#e11d48;background:#fff1f2;padding:14px 20px;border-radius:8px;text-align:center;">${code}</div>
      <p style="margin:16px 0 0;color:#64748b;font-size:12px;">This code expires in 15 minutes. If you did not request this, ignore this email.</p>
    </div>
  `;

  // 1. Try SMTP via Nodemailer
  const smtpHost = process.env.SMTP_HOST?.trim();
  const smtpUser = process.env.SMTP_USER?.trim();
  const smtpPass = process.env.SMTP_PASS?.trim();
  if (smtpHost && smtpUser && smtpPass) {
    try {
      const port = Number(process.env.SMTP_PORT || 587);
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port,
        secure: port === 465,
        auth: { user: smtpUser, pass: smtpPass },
      });
      await transporter.sendMail({
        from: process.env.SMTP_FROM?.trim() || `DELIVOO <${smtpUser}>`,
        to,
        subject,
        text,
        html,
      });
      return { delivered: true, provider: 'smtp' };
    } catch (err) {
      console.error('SMTP OTP delivery failed:', err);
    }
  }

  // 2. Try Resend HTTP API
  const resendKey = process.env.RESEND_API_KEY?.trim();
  if (resendKey) {
    try {
      const resp = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: process.env.EMAIL_FROM?.trim() || 'DELIVOO <no-reply@delivoo.app>',
          to: [to],
          subject,
          text,
          html,
        }),
        signal: AbortSignal.timeout(8000),
      });
      if (resp.ok) {
        return { delivered: true, provider: 'resend' };
      }
      console.error('Resend OTP delivery error status:', resp.status);
    } catch (err) {
      console.error('Resend OTP delivery failed:', err);
    }
  }

  return { delivered: false, provider: 'not_configured' };
}

async function sendPhoneOtp(to: string, code: string): Promise<{ delivered: boolean; provider: 'twilio' | 'sms_webhook' | 'not_configured' }> {
  const smsBody = `DELIVOO verification code: ${code}. Valid for 15 minutes. Never share this code.`;

  // 1. Try Twilio SMS REST API
  const sid = process.env.TWILIO_ACCOUNT_SID?.trim();
  const token = process.env.TWILIO_AUTH_TOKEN?.trim();
  const from = process.env.TWILIO_FROM_NUMBER?.trim();
  if (sid && token && from) {
    try {
      const form = new URLSearchParams({ To: to, From: from, Body: smsBody });
      const authHeader = Buffer.from(`${sid}:${token}`).toString('base64');
      const resp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Messages.json`, {
        method: 'POST',
        headers: {
          Authorization: `Basic ${authHeader}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: form.toString(),
        signal: AbortSignal.timeout(8000),
      });
      if (resp.ok) {
        return { delivered: true, provider: 'twilio' };
      }
      console.error('Twilio SMS error status:', resp.status);
    } catch (err) {
      console.error('Twilio SMS delivery failed:', err);
    }
  }

  // 2. Try configured external SMS Webhook gateway
  const webhookUrl = process.env.SMS_WEBHOOK_URL?.trim();
  if (webhookUrl) {
    const check = isSafeExternalHttpUrl(webhookUrl);
    if (check.safe && check.url) {
      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        const apiKey = process.env.SMS_WEBHOOK_API_KEY?.trim();
        if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
        const resp = await fetch(check.url.toString(), {
          method: 'POST',
          headers,
          body: JSON.stringify({ to, message: smsBody }),
          signal: AbortSignal.timeout(8000),
        });
        if (resp.ok) {
          return { delivered: true, provider: 'sms_webhook' };
        }
      } catch (err) {
        console.error('SMS webhook delivery failed:', err);
      }
    }
  }

  return { delivered: false, provider: 'not_configured' };
}

export async function dispatchExternalOtp(
  target: string,
  channel: OtpChannel,
  code: string
): Promise<OtpDispatchResult> {
  if (channel === 'phone') {
    const maskedTarget = maskPhoneTarget(target);
    const result = await sendPhoneOtp(target, code);
    return {
      channel,
      maskedTarget,
      delivered: result.delivered,
      provider: result.provider,
      expiresInMinutes: 15,
      message: result.delivered
        ? `A 6-digit SMS code was sent to ${maskedTarget}.`
        : `SMS delivery provider is not configured for ${maskedTarget}. Configure Twilio or SMS webhook credentials in Secrets to receive SMS codes.`,
    };
  }

  const maskedTarget = maskEmailTarget(target);
  const purpose = channel === 'password_reset' ? 'password_reset' : 'verification';
  const result = await sendEmailOtp(target, code, purpose);
  return {
    channel,
    maskedTarget,
    delivered: result.delivered,
    provider: result.provider,
    expiresInMinutes: 15,
    message: result.delivered
      ? `A 6-digit verification code was sent to ${maskedTarget}.`
      : `Email delivery provider is not configured for ${maskedTarget}. Configure SMTP or Resend credentials in Secrets to receive email codes.`,
  };
}
