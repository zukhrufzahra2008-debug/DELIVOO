import React, { useEffect, useState, useCallback } from 'react';
import {
  Store,
  Package,
  Upload,
  Link2,
  Barcode,
  FileSpreadsheet,
  Plus,
  Trash2,
  Wallet,
  Settings,
  Shield,
  LogOut,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DelivooLogo } from './DelivooLogo';
import { VerificationBanner } from './VerificationBanner';
import { PrivacySafetyPanel } from './PrivacySafetyPanel';

interface ShopOrder {
  id: number;
  orderNumber: string;
  status: string;
  deliveryMode: string;
  paymentMethod: string;
  paymentStatus: string;
  totalAmount: string;
  subtotal: string;
  deliveryAddress: string;
  createdAt: string;
  items: Array<{ productName: string; quantity: number; variantLabel: string; totalPrice: string }>;
  riderInfo: { fullName: string; phone: string } | null;
}

interface ShopProduct {
  id: number;
  name: string;
  description: string;
  price: string;
  discountedPrice: string | null;
  stockQuantity: number;
  inStock: boolean;
  imageUrl: string | null;
  barcode: string | null;
  expiryDate: string | null;
  manufacturingDate: string | null;
  freshnessInfo: string | null;
  salesCount: number;
}

interface ImportPreviewItem {
  name: string;
  price: string;
  description: string;
  stockQuantity: number;
  imageUrl: string;
  expiryDate: string;
  manufacturingDate: string;
  freshnessInfo: string;
  barcode?: string;
  importSource: string;
}

interface ShopDashboardData {
  shop: {
    id: number;
    name: string;
    approvalStatus: string;
    isOpen: boolean;
    deliveryMode: 'shared_rider' | 'own_rider';
    ownRiderName: string | null;
    ownRiderPhone: string | null;
    openingHours: string;
    estimatedPrepMins: number;
    deliveryFee: string;
    commissionRate: string;
    bankName: string | null;
    bankAccountTitle: string | null;
    bankAccountNumber: string | null;
  };
  metrics: {
    totalOrders: number;
    newOrders: number;
    preparingOrders: number;
    readyOrders: number;
    completedOrders: number;
    cancelledOrders: number;
    dailySales: number;
    monthlyRevenue: number;
  };
  finance: {
    grossSales: number;
    commission: number;
    discounts: number;
    netEarnings: number;
  };
  bestSellers: ShopProduct[];
  inventoryAlerts: ShopProduct[];
  orders: ShopOrder[];
  products: ShopProduct[];
  settlements: Array<{ id: number; periodLabel: string; netAmount: string; status: string; referenceNo: string | null; settledAt: string | null }>;
}

export const ShopkeeperPanel: React.FC = () => {
  const { lastWsEvent, apiFetch, logout, pushToast } = useApp();
  const [tab, setTab] = useState<'overview' | 'orders' | 'products' | 'import' | 'finance' | 'settings' | 'privacy'>('overview');
  const [data, setData] = useState<ShopDashboardData | null>(null);

  // Manual Product Form
  const [prodName, setProdName] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodDiscount, setProdDiscount] = useState('');
  const [prodStock, setProdStock] = useState('25');
  const [prodImage, setProdImage] = useState('');
  const [prodExpiry, setProdExpiry] = useState('');
  const [prodMfg, setProdMfg] = useState('');
  const [prodFresh, setProdFresh] = useState('');

  // 5-Method Import State
  const [importMethod, setImportMethod] = useState<'url' | 'csv' | 'catalog_link' | 'barcode' | 'manual'>('url');
  const [importUrl, setImportUrl] = useState('');
  const [catalogUrl, setCatalogUrl] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [csvText, setCsvText] = useState('name,price,description,stock,image,expiryDate,manufacturingDate,freshnessInfo\nArtisan Sourdough Loaf,650,Naturally fermented 24h loaf,20,,2026-11-29,2026-11-26,Baked fresh daily');
  const [previewItems, setPreviewItems] = useState<ImportPreviewItem[]>([]);
  const [importMsg, setImportMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Delivery & Shop Settings
  const [deliveryMode, setDeliveryMode] = useState<'shared_rider' | 'own_rider'>('shared_rider');
  const [ownRiderName, setOwnRiderName] = useState('');
  const [ownRiderPhone, setOwnRiderPhone] = useState('');
  const [openingHours, setOpeningHours] = useState('');
  const [prepMins, setPrepMins] = useState(20);
  const [deliveryFee, setDeliveryFee] = useState('120');

  const loadDashboard = useCallback(async () => {
    try {
      const resp = await apiFetch<ShopDashboardData>('/api/shopkeeper/dashboard');
      setData(resp);
      setDeliveryMode(resp.shop.deliveryMode);
      setOwnRiderName(resp.shop.ownRiderName || '');
      setOwnRiderPhone(resp.shop.ownRiderPhone || '');
      setOpeningHours(resp.shop.openingHours);
      setPrepMins(resp.shop.estimatedPrepMins);
      setDeliveryFee(resp.shop.deliveryFee);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to load shop dashboard');
    }
  }, [apiFetch, pushToast]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  useEffect(() => {
    if (!lastWsEvent) return;
    if (['order:created', 'order:updated'].includes(lastWsEvent.type)) {
      void loadDashboard();
    }
  }, [lastWsEvent, loadDashboard]);

  const handleOrderAction = async (
    orderId: number,
    action: 'accept' | 'reject' | 'preparing' | 'ready_for_pickup' | 'handover' | 'own_rider_delivered'
  ) => {
    setBusy(true);
    try {
      const resp = await apiFetch<{ dispatchResult?: { assigned: boolean; reason?: string } }>(
        `/api/shopkeeper/orders/${orderId}/status`,
        {
          method: 'POST',
          body: JSON.stringify({ action, prepMins }),
        }
      );
      await loadDashboard();
      if (resp.dispatchResult && !resp.dispatchResult.assigned) {
        pushToast('info', `Order updated. Dispatch notice: ${resp.dispatchResult.reason}`);
      } else {
        pushToast('success', `Order updated (${action.replace(/_/g, ' ')}).`);
      }
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Order update failed');
    } finally {
      setBusy(false);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const resp = await apiFetch<{ replacedDefaultsCount?: number }>('/api/shopkeeper/products', {
        method: 'POST',
        body: JSON.stringify({
          name: prodName,
          description: prodDesc,
          price: Number(prodPrice),
          discountedPrice: prodDiscount ? Number(prodDiscount) : null,
          stockQuantity: Number(prodStock),
          imageUrl: prodImage || undefined,
          expiryDate: prodExpiry || undefined,
          manufacturingDate: prodMfg || undefined,
          freshnessInfo: prodFresh || undefined,
        }),
      });
      setProdName('');
      setProdDesc('');
      setProdPrice('');
      setProdDiscount('');
      setProdImage('');
      await loadDashboard();
      const replacedNote =
        resp.replacedDefaultsCount && resp.replacedDefaultsCount > 0
          ? ` Replaced ${resp.replacedDefaultsCount} default catalog item(s) with your original product.`
          : '';
      pushToast('success', `Product added to store catalog.${replacedNote}`);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Failed to add product');
    } finally {
      setBusy(false);
    }
  };

  const runImportExtract = async () => {
    setBusy(true);
    setImportMsg(null);
    try {
      if (importMethod === 'url') {
        const r = await apiFetch<{ message: string; items: ImportPreviewItem[] }>('/api/shopkeeper/import/url', {
          method: 'POST',
          body: JSON.stringify({ url: importUrl }),
        });
        setPreviewItems(r.items || []);
        setImportMsg(r.message);
      } else if (importMethod === 'catalog_link') {
        const r = await apiFetch<{ message: string; items: ImportPreviewItem[] }>('/api/shopkeeper/import/catalog-link', {
          method: 'POST',
          body: JSON.stringify({ url: catalogUrl }),
        });
        setPreviewItems(r.items || []);
        setImportMsg(r.message);
      } else if (importMethod === 'csv') {
        const r = await apiFetch<{ items: ImportPreviewItem[] }>('/api/shopkeeper/import/csv', {
          method: 'POST',
          body: JSON.stringify({ csvText }),
        });
        setPreviewItems(r.items || []);
        setImportMsg(`Parsed ${r.items?.length || 0} row(s). Review before saving.`);
      } else if (importMethod === 'barcode') {
        const r = await apiFetch<{ found: boolean; source: string; message?: string; item: ImportPreviewItem }>(
          `/api/shopkeeper/import/barcode/${encodeURIComponent(barcodeInput)}`
        );
        setPreviewItems([r.item]);
        setImportMsg(r.message || `Loaded barcode item from ${r.source}`);
      } else {
        setPreviewItems([
          {
            name: '',
            price: '500',
            description: '',
            stockQuantity: 20,
            imageUrl: '',
            expiryDate: '',
            manufacturingDate: '',
            freshnessInfo: '',
            importSource: 'manual',
          },
        ]);
      }
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Import extraction failed');
    } finally {
      setBusy(false);
    }
  };

  const commitImport = async () => {
    setBusy(true);
    try {
      const r = await apiFetch<{ importedCount: number; replacedDefaultsCount?: number }>(
        '/api/shopkeeper/import/commit',
        {
          method: 'POST',
          body: JSON.stringify({ items: previewItems }),
        }
      );
      setPreviewItems([]);
      setImportMsg(null);
      await loadDashboard();
      setTab('products');
      const replacedNote =
        r.replacedDefaultsCount && r.replacedDefaultsCount > 0
          ? ` Replaced ${r.replacedDefaultsCount} default catalog item(s).`
          : '';
      pushToast('success', `Imported ${r.importedCount} original product(s) into catalog.${replacedNote}`);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Import save failed');
    } finally {
      setBusy(false);
    }
  };

  const navItems: Array<{ id: typeof tab; label: string }> = [
    { id: 'overview', label: 'Overview' },
    { id: 'orders', label: 'Orders' },
    { id: 'products', label: 'Products' },
    { id: 'import', label: 'Import Catalog' },
    { id: 'finance', label: 'Finance' },
    { id: 'settings', label: 'Delivery' },
    { id: 'privacy', label: 'Privacy' },
  ];

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-16">
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <DelivooLogo />
            {data && (
              <span className="text-xs font-semibold text-slate-500 truncate hidden sm:inline">
                &middot; {data.shop.name}
              </span>
            )}
          </div>

          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-slate-600">
            {navItems.map((n) => (
              <button
                key={n.id}
                type="button"
                onClick={() => setTab(n.id)}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 ${
                  tab === n.id ? 'border-rose-600 text-slate-900' : 'border-transparent hover:text-slate-900'
                }`}
              >
                {n.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2.5 shrink-0">
            {data && (
              <button
                type="button"
                onClick={async () => {
                  await apiFetch('/api/shopkeeper/settings', {
                    method: 'PATCH',
                    body: JSON.stringify({ isOpen: !data.shop.isOpen }),
                  });
                  await loadDashboard();
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold min-h-[40px] ${
                  data.shop.isOpen
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {data.shop.isOpen ? 'Store Open' : 'Store Closed'}
              </button>
            )}
            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold min-h-[40px]"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>

        {/* Mobile/Tablet horizontal tab strip */}
        <div className="lg:hidden flex items-center gap-1.5 overflow-x-auto px-4 py-2 border-t border-slate-100 bg-white">
          {navItems.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => setTab(n.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 ${
                tab === n.id ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {n.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 space-y-6">
        <VerificationBanner />

        {/* OVERVIEW */}
        {tab === 'overview' && data && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { label: 'Total Orders', value: data.metrics.totalOrders },
                { label: 'New Orders', value: data.metrics.newOrders },
                { label: 'Preparing', value: data.metrics.preparingOrders },
                { label: 'Ready for Pickup', value: data.metrics.readyOrders },
                { label: 'Completed', value: data.metrics.completedOrders },
                { label: 'Cancelled', value: data.metrics.cancelledOrders },
                { label: 'Daily Sales', value: `Rs ${data.metrics.dailySales.toFixed(0)}` },
                { label: 'Monthly Revenue', value: `Rs ${data.metrics.monthlyRevenue.toFixed(0)}` },
              ].map((k) => (
                <div key={k.label} className="rounded-2xl border border-slate-200 bg-white p-4">
                  <p className="text-xs text-slate-500">{k.label}</p>
                  <p className="font-display text-xl font-bold text-slate-900 mt-1 tabular-nums">
                    {k.value}
                  </p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-slate-900">Best-Selling Products</h3>
                {data.bestSellers.map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm py-2 border-b border-slate-100 last:border-0">
                    <span className="font-medium text-slate-800">{p.name}</span>
                    <span className="text-xs font-mono text-slate-500 tabular-nums">{p.salesCount} sold</span>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-slate-900 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  Inventory Alerts
                </h3>
                {data.inventoryAlerts.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4">All products have healthy stock levels.</p>
                ) : (
                  data.inventoryAlerts.map((p) => (
                    <div key={p.id} className="flex items-center justify-between text-sm py-2 border-b border-slate-100 last:border-0">
                      <span className="font-medium text-slate-800">{p.name}</span>
                      <span className="text-xs font-semibold text-rose-600 tabular-nums">
                        {p.inStock ? `${p.stockQuantity} left` : 'Out of Stock'}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ORDERS */}
        {tab === 'orders' && data && (
          <div className="space-y-4">
            <h2 className="font-display text-xl font-bold text-slate-900">Incoming &amp; Active Orders</h2>
            {data.orders.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
                No orders received yet.
              </div>
            ) : (
              data.orders.map((ord) => (
                <div key={ord.id} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="font-mono text-xs text-slate-500">{ord.orderNumber}</span>
                      <p className="text-sm font-bold text-slate-900 tabular-nums">
                        Rs {Number(ord.totalAmount).toFixed(0)} &middot; {ord.paymentMethod.toUpperCase()} ({ord.paymentStatus})
                      </p>
                    </div>
                    <span className="text-xs font-bold text-rose-600 capitalize">
                      {ord.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-0.5">
                    {ord.items.map((it, idx) => (
                      <p key={idx}>
                        {it.quantity}x {it.productName} ({it.variantLabel})
                      </p>
                    ))}
                    <p className="pt-1 text-slate-500">Drop-off: {ord.deliveryAddress}</p>
                    {ord.riderInfo && (
                      <p className="text-emerald-700 font-semibold">
                        Assigned Rider: {ord.riderInfo.fullName} ({ord.riderInfo.phone})
                      </p>
                    )}
                    {ord.deliveryMode === 'shared_rider' && !ord.riderInfo && ['accepted', 'preparing', 'ready_for_pickup'].includes(ord.status) && (
                      <p className="text-amber-700 font-medium">
                        Pending DELIVOO Rider Assignment (auto-dispatch active)
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                    {ord.status === 'placed' && (
                      <>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => void handleOrderAction(ord.id, 'accept')}
                          className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                        >
                          Accept Order
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => void handleOrderAction(ord.id, 'reject')}
                          className="px-4 py-2 rounded-xl border border-rose-200 text-rose-700 text-xs font-semibold hover:bg-rose-50"
                        >
                          Reject
                        </button>
                      </>
                    )}
                    {ord.status === 'accepted' && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleOrderAction(ord.id, 'preparing')}
                        className="px-4 py-2 rounded-xl bg-amber-600 text-white text-xs font-semibold"
                      >
                        Start Preparing
                      </button>
                    )}
                    {['accepted', 'preparing'].includes(ord.status) && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleOrderAction(ord.id, 'ready_for_pickup')}
                        className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                      >
                        Mark Ready for Pickup
                      </button>
                    )}
                    {['ready_for_pickup', 'rider_assigned'].includes(ord.status) && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleOrderAction(ord.id, 'handover')}
                        className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold"
                      >
                        Confirm Handover
                      </button>
                    )}
                    {ord.deliveryMode === 'own_rider' && ['on_the_way', 'picked_up', 'ready_for_pickup'].includes(ord.status) && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleOrderAction(ord.id, 'own_rider_delivered')}
                        className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
                      >
                        Mark Delivered (Own Rider)
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* PRODUCTS */}
        {tab === 'products' && data && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <form
              onSubmit={handleAddProduct}
              className="lg:col-span-4 rounded-2xl border border-slate-200 bg-white p-5 space-y-3 h-fit"
            >
              <h3 className="font-display text-base font-bold text-slate-900 flex items-center gap-2">
                <Plus className="w-4 h-4 text-rose-600" />
                Add Product Manually
              </h3>
              <input
                type="text"
                required
                value={prodName}
                onChange={(e) => setProdName(e.target.value)}
                placeholder="Product Name *"
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              />
              <textarea
                rows={2}
                value={prodDesc}
                onChange={(e) => setProdDesc(e.target.value)}
                placeholder="Description"
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  required
                  value={prodPrice}
                  onChange={(e) => setProdPrice(e.target.value)}
                  placeholder="Price (Rs) *"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
                <input
                  type="number"
                  value={prodDiscount}
                  onChange={(e) => setProdDiscount(e.target.value)}
                  placeholder="Discounted Rs"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  value={prodStock}
                  onChange={(e) => setProdStock(e.target.value)}
                  placeholder="Stock Qty"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
                <input
                  type="text"
                  value={prodFresh}
                  onChange={(e) => setProdFresh(e.target.value)}
                  placeholder="Freshness note"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-slate-500">Mfg Date</label>
                  <input
                    type="date"
                    value={prodMfg}
                    onChange={(e) => setProdMfg(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-2.5 py-1.5 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500">Expiry Date</label>
                  <input
                    type="date"
                    value={prodExpiry}
                    onChange={(e) => setProdExpiry(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-2.5 py-1.5 text-xs"
                  />
                </div>
              </div>
              <input
                type="text"
                value={prodImage}
                onChange={(e) => setProdImage(e.target.value)}
                placeholder="Image URL (optional)"
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              />
              <button
                type="submit"
                disabled={busy}
                className="w-full py-2.5 rounded-xl bg-rose-600 text-white text-sm font-semibold hover:bg-rose-700"
              >
                Add Product
              </button>
            </form>

            <div className="lg:col-span-8 space-y-3">
              {data.products.map((p) => (
                <div
                  key={p.id}
                  className="rounded-2xl border border-slate-200 bg-white p-4 flex flex-wrap items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-14 h-14 rounded-xl bg-slate-100 overflow-hidden shrink-0">
                      {p.imageUrl && (
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-sm text-slate-900 truncate">{p.name}</h4>
                      <p className="text-xs text-slate-500 tabular-nums">
                        Rs {Number(p.discountedPrice || p.price).toFixed(0)} &middot; Stock: {p.stockQuantity}
                        {p.expiryDate ? ` · Exp ${p.expiryDate}` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        await apiFetch(`/api/shopkeeper/products/${p.id}`, {
                          method: 'PATCH',
                          body: JSON.stringify({ inStock: !p.inStock }),
                        });
                        await loadDashboard();
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                        p.inStock ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {p.inStock ? 'In Stock' : 'Out of Stock'}
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await apiFetch(`/api/shopkeeper/products/${p.id}`, { method: 'DELETE' });
                        await loadDashboard();
                      }}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-600"
                      aria-label="Delete product"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5-METHOD PRODUCT IMPORT SYSTEM */}
        {tab === 'import' && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-xl font-bold text-slate-900">
                5-Method Product Import Center
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Import items from Website URLs, CSV/Excel spreadsheets, Online Catalog Links, Barcodes, or Manual Batch Entry with full preview before saving.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { id: 'url' as const, label: 'Website URL', icon: Link2 },
                { id: 'csv' as const, label: 'Excel / CSV', icon: FileSpreadsheet },
                { id: 'catalog_link' as const, label: 'Catalog Link', icon: Upload },
                { id: 'barcode' as const, label: 'Barcode Lookup', icon: Barcode },
                { id: 'manual' as const, label: 'Manual Batch', icon: Package },
              ].map((m) => {
                const Icon = m.icon;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setImportMethod(m.id)}
                    className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border text-xs font-semibold ${
                      importMethod === m.id
                        ? 'border-rose-600 bg-rose-50 text-rose-700'
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{m.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
              {importMethod === 'url' && (
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="url"
                    value={importUrl}
                    onChange={(e) => setImportUrl(e.target.value)}
                    placeholder="https://example.com/product-page"
                    className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
                  />
                  <button
                    type="button"
                    disabled={busy || !importUrl}
                    onClick={() => void runImportExtract()}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                  >
                    Fetch &amp; Preview
                  </button>
                </div>
              )}

              {importMethod === 'catalog_link' && (
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="url"
                    value={catalogUrl}
                    onChange={(e) => setCatalogUrl(e.target.value)}
                    placeholder="https://example.com/catalog.json"
                    className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm"
                  />
                  <button
                    type="button"
                    disabled={busy || !catalogUrl}
                    onClick={() => void runImportExtract()}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                  >
                    Import Catalog
                  </button>
                </div>
              )}

              {importMethod === 'csv' && (
                <div className="space-y-3">
                  <input
                    type="file"
                    accept=".csv,.tsv,.txt"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        file.text().then((t) => setCsvText(t));
                      }
                    }}
                    className="block text-xs text-slate-600"
                  />
                  <textarea
                    rows={4}
                    value={csvText}
                    onChange={(e) => setCsvText(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-3 text-xs font-mono"
                  />
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void runImportExtract()}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                  >
                    Parse CSV Preview
                  </button>
                </div>
              )}

              {importMethod === 'barcode' && (
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={barcodeInput}
                    onChange={(e) => setBarcodeInput(e.target.value)}
                    placeholder="Enter EAN / UPC barcode (e.g. 3017620422003)"
                    className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono"
                  />
                  <button
                    type="button"
                    disabled={busy || !barcodeInput}
                    onClick={() => void runImportExtract()}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                  >
                    Lookup Barcode
                  </button>
                </div>
              )}

              {importMethod === 'manual' && (
                <button
                  type="button"
                  onClick={() => void runImportExtract()}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold"
                >
                  + Add Manual Row to Preview
                </button>
              )}

              {importMsg && (
                <p className="text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  {importMsg}
                </p>
              )}
            </div>

            {previewItems.length > 0 && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-base font-bold text-slate-900">
                    Import Preview ({previewItems.length} items)
                  </h3>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void commitImport()}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 inline-flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Save All to Store
                  </button>
                </div>

                <div className="space-y-3">
                  {previewItems.map((item, idx) => (
                    <div
                      key={idx}
                      className="grid grid-cols-1 sm:grid-cols-6 gap-2 rounded-xl border border-slate-200 p-3 bg-slate-50/50"
                    >
                      <input
                        type="text"
                        value={item.name}
                        onChange={(e) => {
                          const copy = [...previewItems];
                          copy[idx].name = e.target.value;
                          setPreviewItems(copy);
                        }}
                        placeholder="Product Name"
                        className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs bg-white sm:col-span-2"
                      />
                      <input
                        type="number"
                        value={item.price}
                        onChange={(e) => {
                          const copy = [...previewItems];
                          copy[idx].price = e.target.value;
                          setPreviewItems(copy);
                        }}
                        placeholder="Price"
                        className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs bg-white"
                      />
                      <input
                        type="number"
                        value={item.stockQuantity}
                        onChange={(e) => {
                          const copy = [...previewItems];
                          copy[idx].stockQuantity = Number(e.target.value);
                          setPreviewItems(copy);
                        }}
                        placeholder="Stock"
                        className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs bg-white"
                      />
                      <input
                        type="text"
                        value={item.expiryDate}
                        onChange={(e) => {
                          const copy = [...previewItems];
                          copy[idx].expiryDate = e.target.value;
                          setPreviewItems(copy);
                        }}
                        placeholder="Expiry YYYY-MM-DD"
                        className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs bg-white"
                      />
                      <input
                        type="text"
                        value={item.freshnessInfo}
                        onChange={(e) => {
                          const copy = [...previewItems];
                          copy[idx].freshnessInfo = e.target.value;
                          setPreviewItems(copy);
                        }}
                        placeholder="Freshness / Desc"
                        className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs bg-white"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* FINANCE */}
        {tab === 'finance' && data && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="rounded-2xl border border-slate-200 bg-white p-4">
                <p className="text-xs text-slate-500">Gross Sales</p>
                <p className="font-display text-xl font-bold text-slate-900 mt-1 tabular-nums">
                  Rs {data.finance.grossSales.toFixed(0)}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-4">
                <p className="text-xs text-slate-500">DELIVOO Commission ({data.shop.commissionRate}%)</p>
                <p className="font-display text-xl font-bold text-rose-600 mt-1 tabular-nums">
                  -Rs {data.finance.commission.toFixed(0)}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-4">
                <p className="text-xs text-slate-500">Discounts</p>
                <p className="font-display text-xl font-bold text-slate-700 mt-1 tabular-nums">
                  Rs {data.finance.discounts.toFixed(0)}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-4">
                <p className="text-xs text-slate-500">Net Earnings</p>
                <p className="font-display text-xl font-bold text-emerald-700 mt-1 tabular-nums">
                  Rs {data.finance.netEarnings.toFixed(0)}
                </p>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                <Wallet className="w-4 h-4 text-slate-700" />
                <h3 className="font-display text-base font-bold text-slate-900">Settlements History</h3>
              </div>
              {data.settlements.length === 0 ? (
                <p className="p-8 text-center text-sm text-slate-500">No settlements processed yet.</p>
              ) : (
                <div className="divide-y divide-slate-100">
                  {data.settlements.map((s) => (
                    <div key={s.id} className="px-5 py-3.5 flex items-center justify-between text-sm">
                      <div>
                        <p className="font-semibold text-slate-900">{s.periodLabel}</p>
                        <p className="text-xs text-slate-500 font-mono">
                          Ref: {s.referenceNo || 'Pending'} &middot; {s.status}
                        </p>
                      </div>
                      <span className="font-mono font-bold text-emerald-700 tabular-nums">
                        Rs {Number(s.netAmount).toFixed(0)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* DELIVERY SETTINGS */}
        {tab === 'settings' && data && (
          <div className="max-w-2xl rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
            <div className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-slate-800" />
              <h2 className="font-display text-xl font-bold text-slate-900">
                Delivery Fleet &amp; Store Settings
              </h2>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-700">Delivery Fulfillment Mode</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDeliveryMode('shared_rider')}
                  className={`text-left rounded-xl border p-4 ${
                    deliveryMode === 'shared_rider'
                      ? 'border-rose-600 bg-rose-50/50'
                      : 'border-slate-200'
                  }`}
                >
                  <p className="text-sm font-bold text-slate-900">Option 2: DELIVOO Shared Rider</p>
                  <p className="text-xs text-slate-600 mt-1">
                    Automatically dispatches orders to nearby approved DELIVOO riders with live tracking.
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => setDeliveryMode('own_rider')}
                  className={`text-left rounded-xl border p-4 ${
                    deliveryMode === 'own_rider'
                      ? 'border-rose-600 bg-rose-50/50'
                      : 'border-slate-200'
                  }`}
                >
                  <p className="text-sm font-bold text-slate-900">Option 1: Own Rider</p>
                  <p className="text-xs text-slate-600 mt-1">
                    Your shop manages its own rider and marks deliveries directly.
                  </p>
                </button>
              </div>
            </div>

            {deliveryMode === 'own_rider' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  value={ownRiderName}
                  onChange={(e) => setOwnRiderName(e.target.value)}
                  placeholder="Own Rider Name"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
                <input
                  type="text"
                  value={ownRiderPhone}
                  onChange={(e) => setOwnRiderPhone(e.target.value)}
                  placeholder="Own Rider Phone"
                  className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono"
                />
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Opening Hours</label>
                <input
                  type="text"
                  value={openingHours}
                  onChange={(e) => setOpeningHours(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Prep Time (mins)</label>
                <input
                  type="number"
                  value={prepMins}
                  onChange={(e) => setPrepMins(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Delivery Fee (Rs)</label>
                <input
                  type="number"
                  value={deliveryFee}
                  onChange={(e) => setDeliveryFee(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={async () => {
                await apiFetch('/api/shopkeeper/settings', {
                  method: 'PATCH',
                  body: JSON.stringify({
                    deliveryMode,
                    ownRiderName,
                    ownRiderPhone,
                    openingHours,
                    estimatedPrepMins: prepMins,
                    deliveryFee: Number(deliveryFee),
                  }),
                });
                await loadDashboard();
                pushToast('success', 'Delivery & shop settings saved.');
              }}
              className="px-5 py-2.5 rounded-xl bg-rose-600 text-white text-sm font-semibold hover:bg-rose-700"
            >
              Save Settings
            </button>
          </div>
        )}

        {tab === 'privacy' && <PrivacySafetyPanel />}
      </main>
    </div>
  );
};
