import { Router } from 'express';
import { eq, and, desc, asc, ne } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  categories,
  shopProfiles,
  products,
  banners,
  coupons,
  deliveryZones,
  addresses,
  carts,
  cartItems,
  reviews,
  users,
} from '../../db/schema.ts';
import { requireAuth, type AuthedRequest } from '../middleware/auth.ts';
import { ensureMarketplaceSeeded } from '../services/seed.ts';
import { haversineKm } from '../services/dispatch.ts';

const router = Router();

export type PriceTier = 'premium' | 'mid' | 'street';

const TIER_LABEL: Record<PriceTier, string> = {
  premium: 'Premium Craft',
  mid: 'Everyday Dining',
  street: 'Street & Value',
};

const STREET_RE = /\b(street|bun kabab|shami|anda shami|dhaba|paratha|chaat|gol gappay|thela|roadside|tawa)\b/i;
const PREMIUM_RE = /\b(brim|brimcraft|wagyu|dry-aged|artisan|gourmet|craft|truffle|smash|patisserie|french|organic|studio|anc|botanical|sourdough)\b/i;

function classifyShopMeta(
  shop: typeof shopProfiles.$inferSelect,
  shopProds: Array<typeof products.$inferSelect>,
  categoryName: string,
  categorySlug: string
) {
  const isRestaurant = categorySlug === 'food-and-restaurants';
  const avgPrice =
    shopProds.length > 0
      ? Math.round(shopProds.reduce((acc, p) => acc + Number(p.discountedPrice || p.price), 0) / shopProds.length)
      : 0;
  const combinedText = `${shop.name} ${shop.description}`;

  let priceTier: PriceTier = 'mid';
  if (STREET_RE.test(combinedText) || (avgPrice > 0 && avgPrice < 480)) {
    priceTier = 'street';
  } else if (PREMIUM_RE.test(combinedText) || avgPrice >= 950) {
    priceTier = 'premium';
  }

  let cuisineStyle = categoryName;
  if (isRestaurant) {
    if (priceTier === 'street') {
      cuisineStyle = 'Desi Street Eats & Bun Kabab';
    } else if (/\b(burger|smash|brim|wagyu|slider)\b/i.test(combinedText)) {
      cuisineStyle = priceTier === 'premium' ? 'Gourmet Craft Burgers' : 'Burgers & Grill';
    } else if (/\b(tikka|bbq|charcoal|saffron|rice|karahi|biryani)\b/i.test(combinedText)) {
      cuisineStyle = 'Charcoal Grill & Bowls';
    } else {
      cuisineStyle = 'Kitchen & Dining';
    }
  }

  return {
    isRestaurant,
    priceTier,
    priceTierLabel: isRestaurant ? TIER_LABEL[priceTier] : priceTier === 'premium' ? 'Curated Flagship' : 'Neighborhood Store',
    cuisineStyle,
    avgPrice,
  };
}

function classifyProductTier(
  prod: typeof products.$inferSelect,
  shopTier: PriceTier
): PriceTier {
  const text = `${prod.name} ${prod.description}`;
  const effPrice = Number(prod.discountedPrice || prod.price);
  if (STREET_RE.test(text) || effPrice < 420) return 'street';
  if (PREMIUM_RE.test(text) || effPrice >= 1000) return 'premium';
  return shopTier;
}

// Public Marketplace Home (Banners, Categories, Restaurants, Retail Stores, Tier-Matched Products)
router.get('/marketplace/home', async (req, res) => {
  try {
    await ensureMarketplaceSeeded();
    const { category, q, sort, lat, lng, tier } = req.query as Record<string, string | undefined>;

    const [activeCategories, activeBanners, activeCoupons, zones, approvedShops, allProducts] =
      await Promise.all([
        db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.sortOrder)),
        db.select().from(banners).where(eq(banners.isActive, true)).orderBy(asc(banners.sortOrder)),
        db.select().from(coupons).where(eq(coupons.isActive, true)),
        db.select().from(deliveryZones).where(eq(deliveryZones.isActive, true)),
        db.select().from(shopProfiles).where(eq(shopProfiles.approvalStatus, 'approved')),
        db
          .select()
          .from(products)
          .where(and(eq(products.inStock, true), ne(products.importSource, 'seed_replaced'))),
      ]);

    const userLat = lat ? Number(lat) : 24.849;
    const userLng = lng ? Number(lng) : 67.022;
    const categoryMap = new Map(activeCategories.map((c) => [c.id, c]));

    const enrichedAllShops = approvedShops.map((shop) => {
      const distKm = haversineKm(userLat, userLng, shop.lat, shop.lng);
      const shopProds = allProducts.filter((p) => p.shopId === shop.id);
      const catName = categoryMap.get(shop.categoryId)?.name || 'Local Store';
      const catSlug = categoryMap.get(shop.categoryId)?.slug || 'other';
      const meta = classifyShopMeta(shop, shopProds, catName, catSlug);
      return {
        ...shop,
        categoryName: catName,
        categorySlug: catSlug,
        distanceKm: distKm,
        estimatedTotalMins: shop.estimatedPrepMins + Math.max(10, Math.round(distKm * 3.5)),
        productCount: shopProds.length,
        avgProductPrice: meta.avgPrice,
        isRestaurant: meta.isRestaurant,
        priceTier: meta.priceTier,
        priceTierLabel: meta.priceTierLabel,
        cuisineStyle: meta.cuisineStyle,
      };
    });

    const shopMetaMap = new Map(enrichedAllShops.map((s) => [s.id, s]));

    let filteredShops = [...enrichedAllShops];

    if (category && category !== 'all') {
      filteredShops = filteredShops.filter(
        (s) => s.categorySlug === category || String(s.categoryId) === category
      );
    }

    if (tier && tier !== 'all') {
      filteredShops = filteredShops.filter((s) => s.priceTier === tier);
    }

    const searchTerm = q?.trim().toLowerCase() || '';
    if (searchTerm) {
      const matchingProductShopIds = new Set(
        allProducts
          .filter(
            (p) =>
              p.name.toLowerCase().includes(searchTerm) ||
              p.description.toLowerCase().includes(searchTerm)
          )
          .map((p) => p.shopId)
      );
      filteredShops = filteredShops.filter(
        (s) =>
          s.name.toLowerCase().includes(searchTerm) ||
          s.description.toLowerCase().includes(searchTerm) ||
          s.categoryName.toLowerCase().includes(searchTerm) ||
          s.cuisineStyle.toLowerCase().includes(searchTerm) ||
          matchingProductShopIds.has(s.id)
      );
    }

    if (sort === 'rating') {
      filteredShops.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'popular') {
      filteredShops.sort((a, b) => b.totalReviews - a.totalReviews);
    } else if (sort === 'price_low') {
      filteredShops.sort((a, b) => a.avgProductPrice - b.avgProductPrice);
    } else if (sort === 'distance') {
      filteredShops.sort((a, b) => a.distanceKm - b.distanceKm);
    } else {
      filteredShops.sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || b.rating - a.rating);
    }

    const enrichedAllProducts = allProducts
      .filter((p) => shopMetaMap.has(p.shopId))
      .map((p) => {
        const s = shopMetaMap.get(p.shopId)!;
        const prodTier = classifyProductTier(p, s.priceTier);
        return {
          ...p,
          shopName: s.name,
          shopDeliveryFee: s.deliveryFee,
          categoryName: categoryMap.get(p.categoryId)?.name || 'General',
          shopCategorySlug: s.categorySlug,
          isShopOpen: s.isOpen,
          isRestaurant: s.isRestaurant,
          priceTier: prodTier,
          priceTierLabel: TIER_LABEL[prodTier],
          cuisineStyle: s.cuisineStyle,
        };
      });

    // Strict quality/tier matching for recommendations:
    // If search or name-intent targets gourmet/premium (e.g. "brim", "smash", "wagyu", "truffle"),
    // exclude street-food budget items (e.g. shami bun kabab) from Recommended Items.
    let matchingProducts = [...enrichedAllProducts];
    if (category && category !== 'all') {
      const catObj = activeCategories.find((c) => c.slug === category || String(c.id) === category);
      if (catObj) {
        matchingProducts = matchingProducts.filter((p) => p.categoryId === catObj.id);
      }
    }
    if (tier && tier !== 'all') {
      matchingProducts = matchingProducts.filter((p) => p.priceTier === tier);
    }
    if (searchTerm) {
      // Determine tier intent from directly named shops in search
      const nameMatchedShops = enrichedAllShops.filter((s) =>
        s.name.toLowerCase().includes(searchTerm) || s.cuisineStyle.toLowerCase().includes(searchTerm)
      );
      const explicitPremiumIntent =
        PREMIUM_RE.test(searchTerm) ||
        (nameMatchedShops.length > 0 && nameMatchedShops.every((s) => s.priceTier === 'premium'));
      const explicitStreetIntent =
        STREET_RE.test(searchTerm) ||
        (nameMatchedShops.length > 0 && nameMatchedShops.every((s) => s.priceTier === 'street'));

      matchingProducts = matchingProducts.filter((p) => {
        const textMatch =
          p.name.toLowerCase().includes(searchTerm) ||
          p.description.toLowerCase().includes(searchTerm) ||
          p.shopName.toLowerCase().includes(searchTerm) ||
          p.cuisineStyle.toLowerCase().includes(searchTerm);
        if (!textMatch) return false;
        if (explicitPremiumIntent && p.priceTier === 'street') return false;
        if (explicitStreetIntent && p.priceTier === 'premium') return false;
        return true;
      });
    }
    matchingProducts.sort((a, b) => b.salesCount - a.salesCount);

    res.json({
      banners: activeBanners,
      categories: activeCategories,
      shops: filteredShops,
      restaurants: filteredShops.filter((s) => s.isRestaurant),
      retailStores: filteredShops.filter((s) => !s.isRestaurant),
      recommendedProducts: matchingProducts.slice(0, 12),
      catalogProducts: enrichedAllProducts,
      coupons: activeCoupons,
      zones,
    });
  } catch (error) {
    console.error('Marketplace home error:', error);
    res.status(500).json({ error: 'Failed to load marketplace' });
  }
});

// Shop Detail + Products + Reviews + Same-Tier Similar Shops
router.get('/marketplace/shops/:id', async (req, res) => {
  try {
    await ensureMarketplaceSeeded();
    const shopId = Number(req.params.id);
    if (!Number.isFinite(shopId)) return res.status(400).json({ error: 'Invalid shop ID' });

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, shopId));
    if (!shop || shop.approvalStatus !== 'approved') {
      return res.status(404).json({ error: 'Shop not found or currently unavailable' });
    }

    const [[cat], shopProducts, shopReviews, categoryPeers, allApprovedProd] = await Promise.all([
      db.select().from(categories).where(eq(categories.id, shop.categoryId)),
      db
        .select()
        .from(products)
        .where(and(eq(products.shopId, shopId), ne(products.importSource, 'seed_replaced')))
        .orderBy(desc(products.inStock), desc(products.salesCount)),
      db
        .select({
          id: reviews.id,
          shopRating: reviews.shopRating,
          comment: reviews.comment,
          createdAt: reviews.createdAt,
          customerName: users.fullName,
        })
        .from(reviews)
        .innerJoin(users, eq(reviews.customerId, users.id))
        .where(eq(reviews.shopId, shopId))
        .orderBy(desc(reviews.createdAt))
        .limit(20),
      db
        .select()
        .from(shopProfiles)
        .where(and(eq(shopProfiles.categoryId, shop.categoryId), eq(shopProfiles.approvalStatus, 'approved'))),
      db.select().from(products).where(and(eq(products.inStock, true), ne(products.importSource, 'seed_replaced'))),
    ]);

    const catName = cat?.name || 'Local Store';
    const catSlug = cat?.slug || 'other';
    const shopMeta = classifyShopMeta(shop, shopProducts, catName, catSlug);

    // Strictly match similar shops by SAME category AND SAME priceTier
    const similarShops = categoryPeers
      .filter((peer) => peer.id !== shop.id)
      .map((peer) => {
        const peerProds = allApprovedProd.filter((p) => p.shopId === peer.id);
        const peerMeta = classifyShopMeta(peer, peerProds, catName, catSlug);
        return {
          ...peer,
          categoryName: catName,
          categorySlug: catSlug,
          ...peerMeta,
        };
      })
      .filter((peer) => peer.priceTier === shopMeta.priceTier);

    res.json({
      shop: {
        ...shop,
        categoryName: catName,
        categorySlug: catSlug,
        ...shopMeta,
      },
      products: shopProducts.map((p) => ({
        ...p,
        priceTier: classifyProductTier(p, shopMeta.priceTier),
      })),
      reviews: shopReviews,
      similarShops,
    });
  } catch (error) {
    console.error('Shop detail error:', error);
    res.status(500).json({ error: 'Failed to fetch shop details' });
  }
});

// Customer Addresses
router.get('/addresses', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const list = await db
      .select()
      .from(addresses)
      .where(eq(addresses.userId, req.authUser!.id))
      .orderBy(desc(addresses.isDefault), desc(addresses.id));
    res.json({ addresses: list });
  } catch (error) {
    console.error('Get addresses error:', error);
    res.status(500).json({ error: 'Failed to load addresses' });
  }
});

router.post('/addresses', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const { label, streetAddress, area, city, lat, lng, instructions, isDefault } = req.body as {
      label?: string;
      streetAddress?: string;
      area?: string;
      city?: string;
      lat?: number;
      lng?: number;
      instructions?: string;
      isDefault?: boolean;
    };
    if (!streetAddress || !area) {
      return res.status(400).json({ error: 'Street address and area are required' });
    }
    if (isDefault) {
      await db.update(addresses).set({ isDefault: false }).where(eq(addresses.userId, req.authUser!.id));
    }
    const [created] = await db
      .insert(addresses)
      .values({
        userId: req.authUser!.id,
        label: label?.trim() || 'Home',
        streetAddress: streetAddress.trim(),
        area: area.trim(),
        city: city?.trim() || 'Karachi',
        lat: typeof lat === 'number' ? lat : 24.849,
        lng: typeof lng === 'number' ? lng : 67.022,
        instructions: instructions?.trim() || null,
        isDefault: Boolean(isDefault),
      })
      .returning();
    res.status(201).json({ address: created });
  } catch (error) {
    console.error('Add address error:', error);
    res.status(500).json({ error: 'Failed to save address' });
  }
});

router.delete('/addresses/:id', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const id = Number(req.params.id);
    await db
      .delete(addresses)
      .where(and(eq(addresses.id, id), eq(addresses.userId, req.authUser!.id)));
    res.json({ deleted: true });
  } catch (error) {
    console.error('Delete address error:', error);
    res.status(500).json({ error: 'Failed to delete address' });
  }
});

// Cart Management
async function loadCartPayload(userId: number) {
  const [cart] = await db.select().from(carts).where(eq(carts.userId, userId));
  if (!cart) return { cart: null, shop: null, items: [], subtotal: 0 };

  const items = await db
    .select({
      id: cartItems.id,
      productId: cartItems.productId,
      quantity: cartItems.quantity,
      selectedVariant: cartItems.selectedVariant,
      unitPrice: cartItems.unitPrice,
      productName: products.name,
      imageUrl: products.imageUrl,
      inStock: products.inStock,
      stockQuantity: products.stockQuantity,
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(eq(cartItems.cartId, cart.id))
    .orderBy(asc(cartItems.id));

  let shop = null;
  if (cart.shopId) {
    const [s] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, cart.shopId));
    shop = s || null;
  }

  const subtotal = items.reduce((acc, item) => acc + Number(item.unitPrice) * item.quantity, 0);
  return { cart, shop, items, subtotal: Math.round(subtotal * 100) / 100 };
}

router.get('/cart', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const payload = await loadCartPayload(req.authUser!.id);
    res.json(payload);
  } catch (error) {
    console.error('Get cart error:', error);
    res.status(500).json({ error: 'Failed to load cart' });
  }
});

router.post('/cart/items', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const { productId, quantity = 1, selectedVariant = 'Standard', replaceShop = false } = req.body as {
      productId?: number;
      quantity?: number;
      selectedVariant?: string;
      replaceShop?: boolean;
    };
    if (!productId || quantity < 1) {
      return res.status(400).json({ error: 'Valid productId and quantity >= 1 are required' });
    }

    const [product] = await db.select().from(products).where(eq(products.id, Number(productId)));
    if (!product || !product.inStock || product.stockQuantity < quantity) {
      return res.status(400).json({ error: 'This product is currently out of stock' });
    }

    const [shop] = await db.select().from(shopProfiles).where(eq(shopProfiles.id, product.shopId));
    if (!shop || shop.approvalStatus !== 'approved' || !shop.isOpen) {
      return res.status(400).json({ error: 'This shop is not accepting orders right now' });
    }

    const variantDef = product.variants?.find((v) => v.name === selectedVariant);
    const basePrice = Number(product.discountedPrice || product.price);
    const unitPrice = Math.max(1, basePrice + (variantDef?.priceDelta || 0));

    let [cart] = await db.select().from(carts).where(eq(carts.userId, req.authUser!.id));
    if (!cart) {
      [cart] = await db.insert(carts).values({ userId: req.authUser!.id, shopId: shop.id }).returning();
    } else if (cart.shopId && cart.shopId !== shop.id) {
      const existingItems = await db.select().from(cartItems).where(eq(cartItems.cartId, cart.id));
      if (existingItems.length > 0 && !replaceShop) {
        return res.status(409).json({
          error: 'Your cart contains items from another shop. Clear cart to switch shops?',
          code: 'DIFFERENT_SHOP',
        });
      }
      await db.delete(cartItems).where(eq(cartItems.cartId, cart.id));
      await db.update(carts).set({ shopId: shop.id, updatedAt: new Date() }).where(eq(carts.id, cart.id));
    } else if (!cart.shopId) {
      await db.update(carts).set({ shopId: shop.id, updatedAt: new Date() }).where(eq(carts.id, cart.id));
    }

    const [existingItem] = await db
      .select()
      .from(cartItems)
      .where(
        and(
          eq(cartItems.cartId, cart.id),
          eq(cartItems.productId, product.id),
          eq(cartItems.selectedVariant, selectedVariant)
        )
      );

    if (existingItem) {
      const nextQty = existingItem.quantity + quantity;
      if (nextQty > product.stockQuantity) {
        return res.status(400).json({ error: `Only ${product.stockQuantity} units available in stock` });
      }
      await db
        .update(cartItems)
        .set({ quantity: nextQty, unitPrice: unitPrice.toFixed(2) })
        .where(eq(cartItems.id, existingItem.id));
    } else {
      await db.insert(cartItems).values({
        cartId: cart.id,
        productId: product.id,
        quantity,
        selectedVariant,
        unitPrice: unitPrice.toFixed(2),
      });
    }

    const payload = await loadCartPayload(req.authUser!.id);
    res.json(payload);
  } catch (error) {
    console.error('Add to cart error:', error);
    res.status(500).json({ error: 'Failed to add item to cart' });
  }
});

router.patch('/cart/items/:id', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const itemId = Number(req.params.id);
    const { quantity } = req.body as { quantity?: number };
    const [cart] = await db.select().from(carts).where(eq(carts.userId, req.authUser!.id));
    if (!cart) return res.status(404).json({ error: 'Cart not found' });

    if (typeof quantity !== 'number' || quantity <= 0) {
      await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)));
    } else {
      const [item] = await db
        .select()
        .from(cartItems)
        .where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)));
      if (!item) return res.status(404).json({ error: 'Item not found' });

      const [product] = await db.select().from(products).where(eq(products.id, item.productId));
      if (product && quantity > product.stockQuantity) {
        return res.status(400).json({ error: `Only ${product.stockQuantity} left in stock` });
      }
      await db.update(cartItems).set({ quantity }).where(eq(cartItems.id, itemId));
    }

    const remaining = await db.select().from(cartItems).where(eq(cartItems.cartId, cart.id));
    if (remaining.length === 0) {
      await db.update(carts).set({ shopId: null }).where(eq(carts.id, cart.id));
    }
    const payload = await loadCartPayload(req.authUser!.id);
    res.json(payload);
  } catch (error) {
    console.error('Update cart item error:', error);
    res.status(500).json({ error: 'Failed to update cart item' });
  }
});

router.delete('/cart', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const [cart] = await db.select().from(carts).where(eq(carts.userId, req.authUser!.id));
    if (cart) {
      await db.delete(cartItems).where(eq(cartItems.cartId, cart.id));
      await db.update(carts).set({ shopId: null }).where(eq(carts.id, cart.id));
    }
    res.json({ cart: null, shop: null, items: [], subtotal: 0 });
  } catch (error) {
    console.error('Clear cart error:', error);
    res.status(500).json({ error: 'Failed to clear cart' });
  }
});

router.post('/cart/validate-coupon', requireAuth, async (req: AuthedRequest, res) => {
  try {
    const { code, subtotal } = req.body as { code?: string; subtotal?: number };
    if (!code) return res.status(400).json({ error: 'Enter a coupon code' });

    const [coupon] = await db
      .select()
      .from(coupons)
      .where(and(eq(coupons.code, code.trim().toUpperCase()), eq(coupons.isActive, true)));

    if (!coupon) return res.status(404).json({ error: 'Coupon code is invalid or inactive' });
    if (coupon.expiresAt && coupon.expiresAt < new Date()) {
      return res.status(400).json({ error: 'Coupon has expired' });
    }
    if (coupon.usedCount >= coupon.usageLimit) {
      return res.status(400).json({ error: 'Coupon usage limit reached' });
    }
    const orderSub = Number(subtotal || 0);
    if (orderSub < Number(coupon.minOrderAmount)) {
      return res.status(400).json({
        error: `Minimum order amount Rs ${coupon.minOrderAmount} required for ${coupon.code}`,
      });
    }

    let discount =
      coupon.discountType === 'percent'
        ? (orderSub * Number(coupon.discountValue)) / 100
        : Number(coupon.discountValue);
    discount = Math.min(discount, Number(coupon.maxDiscount), orderSub);

    res.json({
      valid: true,
      coupon,
      discountAmount: Math.round(discount * 100) / 100,
    });
  } catch (error) {
    console.error('Validate coupon error:', error);
    res.status(500).json({ error: 'Could not validate coupon' });
  }
});

export default router;
